window.onload=function(){

	function init() {
	    var map = new qq.maps.Map(document.getElementById("map-area"), {
	        // 地图的中心地理坐标。
	        center: new qq.maps.LatLng(39.916527,116.397128)
	    });
	}
	init()
}

