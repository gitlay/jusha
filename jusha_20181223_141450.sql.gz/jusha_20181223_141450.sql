-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: localhost    Database: jusha
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clt_ad`
--

DROP TABLE IF EXISTS `clt_ad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_ad` (
  `ad_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '广告名称',
  `type_id` tinyint(5) NOT NULL COMMENT '所属位置',
  `pic` varchar(200) NOT NULL DEFAULT '' COMMENT '广告图片URL',
  `url` varchar(200) NOT NULL DEFAULT '' COMMENT '广告链接',
  `addtime` int(11) NOT NULL COMMENT '添加时间',
  `sort` int(11) NOT NULL COMMENT '排序',
  `open` tinyint(2) NOT NULL COMMENT '1=审核  0=未审核',
  `content` varchar(225) DEFAULT '' COMMENT '广告内容',
  PRIMARY KEY (`ad_id`),
  KEY `plug_ad_adtypeid` (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='广告表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_ad`
--

LOCK TABLES `clt_ad` WRITE;
/*!40000 ALTER TABLE `clt_ad` DISABLE KEYS */;
INSERT INTO `clt_ad` VALUES (36,'1',1,'/uploads/20181219/6d5236e90b8e84232b81a982645133f8.jpg','#',1545210402,50,1,''),(37,'2',1,'/uploads/20181219/ad0ed2542f3001a971b39f7a50e0a687.jpg','#',1545210425,50,1,''),(38,'1',5,'/uploads/20181219/7618c617abce9813d1225830475287ab.jpg','#',1545212936,50,1,''),(39,'2',5,'/uploads/20181219/652ed7c47471e4366c4ea8d1ea40382e.jpg','#',1545212949,50,1,'');
/*!40000 ALTER TABLE `clt_ad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_ad_type`
--

DROP TABLE IF EXISTS `clt_ad_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_ad_type` (
  `type_id` tinyint(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '广告位名称',
  `sort` int(11) NOT NULL COMMENT '广告位排序',
  PRIMARY KEY (`type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='广告分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_ad_type`
--

LOCK TABLES `clt_ad_type` WRITE;
/*!40000 ALTER TABLE `clt_ad_type` DISABLE KEYS */;
INSERT INTO `clt_ad_type` VALUES (5,'【首页】顶部轮播',1),(1,'【首页】底部轮播',2);
/*!40000 ALTER TABLE `clt_ad_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_address`
--

DROP TABLE IF EXISTS `clt_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_address` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `username` varchar(40) NOT NULL DEFAULT '' COMMENT '用户名',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `keywords` varchar(120) NOT NULL DEFAULT '' COMMENT '关键词',
  `description` mediumtext NOT NULL COMMENT '描述',
  `content` mediumtext NOT NULL COMMENT '内容',
  `template` varchar(40) NOT NULL DEFAULT '' COMMENT '模板',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '允许评论',
  `readgroup` varchar(100) NOT NULL DEFAULT '' COMMENT '访问权限',
  `readpoint` smallint(5) NOT NULL DEFAULT '0' COMMENT '阅读权限',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `hits` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点击',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `lon` varchar(255) DEFAULT '' COMMENT '经度',
  `lat` varchar(255) DEFAULT '' COMMENT '纬度',
  `address` varchar(255) DEFAULT '' COMMENT '地址',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`sort`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `sort` (`id`,`catid`,`status`,`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_address`
--

LOCK TABLES `clt_address` WRITE;
/*!40000 ALTER TABLE `clt_address` DISABLE KEYS */;
INSERT INTO `clt_address` VALUES (1,54,1,'admin','石家庄','','','','',0,1,0,'',0,1,0,1545464841,1545542413,'114.551303','38.063463','石家庄市长安区建华北大街138号百川大厦东塔22层'),(2,54,1,'admin','保定','','','','',0,1,0,'',0,2,0,1545465042,1545542474,'115.47319','38.914938','保定市朝阳北大街1898号电谷源盛商务大厦B座24层');
/*!40000 ALTER TABLE `clt_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_admin`
--

DROP TABLE IF EXISTS `clt_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_admin` (
  `admin_id` tinyint(4) NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `username` varchar(20) NOT NULL COMMENT '管理员用户名',
  `pwd` varchar(70) NOT NULL COMMENT '管理员密码',
  `group_id` mediumint(8) DEFAULT NULL COMMENT '分组ID',
  `email` varchar(30) DEFAULT NULL COMMENT '邮箱',
  `realname` varchar(10) DEFAULT NULL COMMENT '真实姓名',
  `tel` varchar(30) DEFAULT NULL COMMENT '电话号码',
  `ip` varchar(20) DEFAULT NULL COMMENT 'IP地址',
  `add_time` int(11) DEFAULT NULL COMMENT '添加时间',
  `mdemail` varchar(50) DEFAULT '0' COMMENT '传递修改密码参数加密',
  `is_open` tinyint(2) DEFAULT '0' COMMENT '审核状态',
  `avatar` varchar(120) DEFAULT '' COMMENT '头像',
  PRIMARY KEY (`admin_id`),
  KEY `admin_username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='后台管理员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_admin`
--

LOCK TABLES `clt_admin` WRITE;
/*!40000 ALTER TABLE `clt_admin` DISABLE KEYS */;
INSERT INTO `clt_admin` VALUES (1,'admin','0192023a7bbd73250516f069df18b500',1,'1109305454@qq.com','','18792402229','127.0.0.1',1482132862,'0',1,'/uploads/20180625/f266169c2956429d9aaea6cf6f1e51cb.jpg'),(11,'cltphp','2495caa2aa678121ccc248e530494639',2,'123@qq.com','','15896589568','127.0.0.1',1535512393,'0',1,'');
/*!40000 ALTER TABLE `clt_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_article`
--

DROP TABLE IF EXISTS `clt_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `description` text COMMENT 'SEO简介',
  `content` text COMMENT '内容',
  `template` varchar(40) NOT NULL DEFAULT '',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `status` varchar(255) NOT NULL DEFAULT '1',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `readpoint` smallint(5) NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `copyfrom` varchar(255) NOT NULL DEFAULT 'CLTPHP',
  `fromlink` varchar(255) NOT NULL DEFAULT 'http://www.cltphp.com/',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`sort`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_article`
--

LOCK TABLES `clt_article` WRITE;
/*!40000 ALTER TABLE `clt_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `clt_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_auth_group`
--

DROP TABLE IF EXISTS `clt_auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_auth_group` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '全新ID',
  `title` char(100) NOT NULL DEFAULT '' COMMENT '标题',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态',
  `rules` longtext COMMENT '规则',
  `addtime` int(11) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='管理员分组';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_auth_group`
--

LOCK TABLES `clt_auth_group` WRITE;
/*!40000 ALTER TABLE `clt_auth_group` DISABLE KEYS */;
INSERT INTO `clt_auth_group` VALUES (1,'超级管理员',1,'0,1,2,270,15,16,119,120,121,145,17,149,116,117,118,151,181,18,108,114,112,109,110,111,3,5,126,127,128,4,230,232,129,189,190,193,192,240,239,241,243,244,245,242,246,7,9,14,234,13,235,236,237,238,27,29,161,163,164,162,38,167,182,169,166,28,48,247,248,31,32,249,250,251,45,170,171,175,174,173,46,176,183,179,178,265,196,197,202,198,252,253,254,255,256,203,205,204,257,272,206,207,212,208,213,258,259,260,261,262,209,215,214,263,273,267,269,',1465114224);
/*!40000 ALTER TABLE `clt_auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_auth_rule`
--

DROP TABLE IF EXISTS `clt_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `href` char(80) NOT NULL DEFAULT '',
  `title` char(20) NOT NULL DEFAULT '',
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `authopen` tinyint(2) NOT NULL DEFAULT '1',
  `icon` varchar(20) DEFAULT NULL COMMENT '样式',
  `condition` char(100) DEFAULT '',
  `pid` int(5) NOT NULL DEFAULT '0' COMMENT '父栏目ID',
  `sort` int(11) DEFAULT '0' COMMENT '排序',
  `addtime` int(11) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `zt` int(1) DEFAULT NULL,
  `menustatus` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=280 DEFAULT CHARSET=utf8 COMMENT='权限节点';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_auth_rule`
--

LOCK TABLES `clt_auth_rule` WRITE;
/*!40000 ALTER TABLE `clt_auth_rule` DISABLE KEYS */;
INSERT INTO `clt_auth_rule` VALUES (1,'System','系统设置',1,1,0,'icon-cogs','',0,0,1446535750,1,1),(2,'System/system','系统设置',1,1,0,'','',1,1,1446535789,1,1),(3,'Database/database','数据库管理',1,1,0,'icon-database','',0,2,1446535805,1,0),(4,'Database/restore','还原数据库',1,1,0,'','',3,10,1446535750,1,1),(5,'Database/database','数据库备份',1,1,0,'','',3,1,1446535834,1,1),(7,'Category','栏目管理',1,1,0,'icon-list','',0,4,1446535875,1,1),(9,'Category/index','栏目列表',1,1,0,'','',7,0,1446535750,1,1),(13,'Category/edit','操作-修改',1,1,0,'','',9,3,1446535750,1,0),(14,'Category/add','操作-添加',1,1,0,'','',9,0,1446535750,1,0),(15,'Auth/adminList','权限管理',1,1,0,'icon-lifebuoy','',0,1,1446535750,1,1),(16,'Auth/adminList','管理员列表',1,1,0,'','',15,0,1446535750,1,1),(17,'Auth/adminGroup','用户组列表',1,1,0,'','',15,1,1446535750,1,1),(18,'Auth/adminRule','权限管理',1,1,0,'','',15,2,1446535750,1,1),(27,'Users','会员管理',1,1,0,'icon-user','',0,5,1447231507,1,0),(28,'Function','网站功能',1,1,0,'icon-cog','',0,6,1447231590,1,1),(29,'Users/index','会员列表',1,1,0,'','',27,10,1447232085,1,1),(31,'Link/index','友情链接',1,1,0,'','',28,2,1447232183,0,1),(32,'Link/add','操作-添加',1,1,0,'','',31,1,1447639935,0,0),(38,'Users/userGroup','会员组',1,1,0,'','',27,50,1448413248,1,1),(45,'Ad/index','广告管理',1,1,0,'','',28,3,1450314297,1,1),(46,'Ad/type','广告位管理',1,1,0,'','',28,4,1450314324,1,1),(48,'Message/index','留言管理',1,1,0,'','',28,1,1451267354,0,1),(108,'Auth/ruleAdd','操作-添加',1,1,0,'','',18,0,1461550835,1,0),(109,'Auth/ruleState','操作-状态',1,1,0,'','',18,5,1461550949,1,0),(110,'Auth/ruleTz','操作-验证',1,1,0,'','',18,6,1461551129,1,0),(111,'Auth/ruleorder','操作-排序',1,1,0,'','',18,7,1461551263,1,0),(112,'Auth/ruleDel','操作-删除',1,1,0,'','',18,4,1461551536,1,0),(114,'Auth/ruleEdit','操作-修改',1,1,0,'','',18,2,1461551913,1,0),(116,'Auth/groupEdit','操作-修改',1,1,0,'','',17,3,1461552326,1,0),(117,'Auth/groupDel','操作-删除',1,1,0,'','',17,30,1461552349,1,0),(118,'Auth/groupAccess','操作-权限',1,1,0,'','',17,40,1461552404,1,0),(119,'Auth/adminAdd','操作-添加',1,1,0,'','',16,0,1461553162,1,0),(120,'Auth/adminEdit','操作-修改',1,1,0,'','',16,2,1461554130,1,0),(121,'Auth/adminDel','操作-删除',1,1,0,'','',16,4,1461554152,1,0),(126,'Database/export','操作-备份',1,1,0,'','',5,1,1461550835,1,0),(127,'Database/optimize','操作-优化',1,1,0,'','',5,1,1461550835,1,0),(128,'Database/repair','操作-修复',1,1,0,'','',5,1,1461550835,1,0),(129,'Database/delSqlFiles','操作-删除',1,1,0,'','',4,3,1461550835,1,0),(236,'Category/del','操作-删除',1,1,0,'','',9,5,1497424900,0,0),(230,'Database/import','操作-还原',1,1,0,'','',4,1,1497423595,0,0),(145,'Auth/adminState','操作-状态',1,1,0,'','',16,5,1461550835,1,0),(149,'Auth/groupAdd','操作-添加',1,1,0,'','',17,1,1461550835,1,0),(151,'Auth/groupRunaccess','操作-权存',1,1,0,'','',17,50,1461550835,1,0),(234,'Category/insert','操作-添存',1,1,0,'','',9,2,1497424143,0,0),(240,'Module/del','操作-删除',1,1,0,'','',190,4,1497425850,0,0),(239,'Module/moduleState','操作-状态',1,1,0,'','',190,5,1497425764,0,0),(238,'page/edit','单页编辑',1,1,0,'','',7,2,1497425142,0,0),(237,'Category/cOrder','操作-排序',1,1,0,'','',9,6,1497424979,0,0),(161,'Users/usersState','操作-状态',1,1,0,'','',29,1,1461550835,1,0),(162,'Users/delall','操作-全部删除',1,1,0,'','',29,4,1461550835,1,0),(163,'Users/edit','操作-编辑',1,1,0,'','',29,2,1461550835,1,0),(164,'Users/usersDel','操作-删除',1,1,0,'','',29,3,1461550835,1,0),(247,'Message/del','操作-删除',1,1,0,'','',48,1,1497427449,0,0),(166,'Users/groupOrder','操作-排序',1,1,0,'','',38,50,1461550835,1,0),(167,'Users/groupAdd','操作-添加',1,1,0,'','',38,10,1461550835,1,0),(169,'Users/groupDel','操作-删除',1,1,0,'','',38,30,1461550835,1,0),(170,'Ad/add','操作-添加',1,1,0,'','',45,1,1461550835,1,0),(171,'Ad/edit','操作-修改',1,1,0,'','',45,2,1461550835,1,0),(173,'Ad/del','操作-删除',1,1,0,'','',45,5,1461550835,1,0),(174,'Ad/adOrder','操作-排序',1,1,0,'','',45,4,1461550835,1,0),(175,'Ad/editState','操作-状态',1,1,0,'','',45,3,1461550835,1,0),(176,'Ad/addType','操作-添加',1,1,0,'','',46,1,1461550835,1,0),(252,'Template/edit','操作-编辑',1,1,0,'','',197,3,1497428906,0,0),(178,'Ad/delType','操作-删除',1,1,0,'','',46,4,1461550835,1,0),(179,'Ad/typeOrder','操作-排序',1,1,0,'','',46,3,1461550835,1,0),(181,'Auth/groupState','操作-状态',1,1,0,'','',17,50,1461834340,1,0),(182,'Users/groupEdit','操作-修改',1,1,0,'','',38,15,1461834780,1,0),(183,'Ad/editType','操作-修改',1,1,0,'','',46,2,1461834988,1,0),(189,'Module','模型管理',1,1,0,'icon-ungroup','',0,3,1466825363,0,1),(190,'Module/index','模型列表',1,1,0,'','',189,1,1466826681,0,1),(192,'Module/edit','操作-修改',1,1,0,'','',190,2,1467007920,0,0),(193,'Module/add','操作-添加',1,1,0,'','',190,1,1467007955,0,0),(196,'Template','模版管理',1,1,0,'icon-embed2','',0,7,1481857304,0,0),(197,'Template/index','模版管理',1,1,0,'','',196,1,1481857540,0,1),(198,'Template/insert','操作-添存',1,1,0,'','',197,2,1481857587,0,0),(202,'Template/add','操作-添加',1,1,0,'','',197,1,1481859447,0,0),(203,'Debris/index','碎片管理',1,1,0,'','',196,2,1484797759,0,1),(204,'Debris/edit','操作-编辑',1,1,0,'','',203,2,1484797849,0,0),(205,'Debris/add','操作-添加',1,1,0,'','',203,1,1484797878,0,0),(206,'Wechat','微信管理',1,1,0,'icon-bubbles2','',0,8,1487063570,0,0),(207,'Wechat/config','公众号管理',1,1,0,'','',206,1,1487063705,0,1),(208,'Wechat/menu','菜单管理',1,1,0,'','',206,2,1487063765,0,1),(209,'Wechat/materialmessage','消息素材',1,1,0,'','',206,3,1487063834,0,1),(212,'Wechat/weixin','操作-设置',1,1,0,'','',207,1,1487064541,0,0),(213,'Wechat/addMenu','操作-添加',1,1,0,'','',208,1,1487149151,0,0),(214,'Wechat/editText','操作-编辑',1,1,0,'','',209,2,1487233984,0,0),(215,'Wechat/addText','操作-添加',1,1,0,'','',209,1,1487234062,0,0),(232,'Database/downFile','操作-下载',1,1,0,'','',4,2,1497423744,0,0),(235,'Category/catUpdate','操作-该存',1,1,0,'','',9,4,1497424301,0,0),(241,'Module/field','模型字段',1,1,0,'','',190,6,1497425972,0,0),(242,'Module/fieldStatus','操作-状态',1,1,0,'','',241,4,1497426044,0,0),(243,'Module/fieldAdd','操作-添加',1,1,0,'','',241,1,1497426089,0,0),(244,'Module/fieldEdit','操作-修改',1,1,0,'','',241,2,1497426134,0,0),(245,'Module/listOrder','操作-排序',1,1,0,'','',241,3,1497426179,0,0),(246,'Module/fieldDel','操作-删除',1,1,0,'','',241,5,1497426241,0,0),(248,'Message/delall','操作-删除全部',1,1,0,'','',48,2,1497427534,0,0),(249,'Link/edit','操作-编辑',1,1,0,'','',31,2,1497427694,0,0),(250,'Link/linkState','操作-状态',1,1,0,'','',31,3,1497427734,0,0),(251,'Link/del','操作-删除',1,1,0,'','',31,4,1497427780,0,0),(253,'Template/update','操作-改存',1,1,0,'','',197,4,1497428951,0,0),(254,'Template/delete','操作-删除',1,1,0,'','',197,5,1497429018,0,0),(255,'Template/images','媒体文件管理',1,1,0,'','',197,6,1497429157,0,0),(256,'Template/imgDel','操作-文件删除',1,1,0,'','',255,1,1497429217,0,0),(257,'Debris/del','操作-删除',1,1,0,'','',203,3,1497429416,0,0),(258,'Wechat/editMenu','操作-编辑',1,1,0,'','',208,2,1497429671,0,0),(259,'Wechat/menuOrder','操作-排序',1,1,0,'','',208,3,1497429707,0,0),(260,'Wechat/menuState','操作-状态',1,1,0,'','',208,4,1497429764,0,0),(261,'Wechat/delMenu','操作-删除',1,1,0,'','',208,5,1497429822,0,0),(262,'Wechat/createMenu','操作-生成菜单',1,1,0,'','',208,6,1497429886,0,0),(263,'Wechat/delText','操作-删除',1,1,0,'','',209,3,1497430020,0,0),(273,'Wechat/replay','回复设置',1,1,0,'','',206,4,1508215988,0,1),(267,'Plugin/index','插件管理',1,1,1,'icon-power-cord','',0,9,1501466560,0,0),(269,'Plugin/index','第三方',1,1,1,'','',267,1,1501466732,0,1),(270,'System/email','邮箱配置',1,1,0,'','',1,2,1502331829,0,0),(272,'Debris/type','碎片分类',1,1,1,'','',196,3,1504082720,0,1);
/*!40000 ALTER TABLE `clt_auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_cars`
--

DROP TABLE IF EXISTS `clt_cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_cars` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `username` varchar(40) NOT NULL DEFAULT '' COMMENT '用户名',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `keywords` varchar(120) NOT NULL DEFAULT '' COMMENT '关键词',
  `description` mediumtext NOT NULL COMMENT '描述',
  `content` mediumtext NOT NULL COMMENT '内容',
  `template` varchar(40) NOT NULL DEFAULT '' COMMENT '模板',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '允许评论',
  `readgroup` varchar(100) NOT NULL DEFAULT '' COMMENT '访问权限',
  `readpoint` smallint(5) NOT NULL DEFAULT '0' COMMENT '阅读权限',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `hits` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点击',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `type` varchar(255) NOT NULL DEFAULT '' COMMENT '类型',
  `tag` varchar(255) NOT NULL DEFAULT '快车' COMMENT '标签',
  `price` varchar(255) NOT NULL DEFAULT '' COMMENT '裸车价',
  `maxKw` varchar(255) DEFAULT '' COMMENT '最大功率(KW)',
  `maxNm` varchar(255) DEFAULT '' COMMENT '最大扭矩(N*M)',
  `engine` varchar(255) DEFAULT '' COMMENT '发动机',
  `bsx` varchar(255) DEFAULT '' COMMENT '变速箱',
  `size` varchar(255) DEFAULT '' COMMENT '长*宽*高(MM)',
  `zhyh` varchar(255) DEFAULT '' COMMENT '工信部综合油耗(L/100KM)',
  `zb` varchar(255) DEFAULT '' COMMENT '整车质保',
  `zj` varchar(255) DEFAULT '' COMMENT '轴距(MM)',
  `riTitle` varchar(255) NOT NULL DEFAULT '油箱容积（L）' COMMENT '容积类型',
  `rj` varchar(255) DEFAULT '' COMMENT '容积',
  `dc` varchar(255) DEFAULT '' COMMENT '电池类型',
  `lc` varchar(255) DEFAULT '' COMMENT '工信部续航里程(KM)',
  `dlcb` varchar(255) DEFAULT '' COMMENT '动力成本',
  `bycb` varchar(255) DEFAULT '' COMMENT '保养成本',
  `ys` varchar(255) DEFAULT '' COMMENT '优势',
  `ls` varchar(255) DEFAULT '' COMMENT '劣势',
  `address_id` varchar(255) NOT NULL DEFAULT '1' COMMENT '地区',
  `wgS` decimal(10,1) unsigned DEFAULT '5.0' COMMENT '外观',
  `cbS` decimal(10,1) unsigned DEFAULT '5.0' COMMENT '成本',
  `dlS` decimal(10,1) unsigned DEFAULT '5.0' COMMENT '动力',
  `zbS` decimal(10,1) unsigned DEFAULT '0.5' COMMENT '质保',
  `bgimg` varchar(80) DEFAULT '' COMMENT '背景图',
  `bg` varchar(80) DEFAULT '' COMMENT '大图',
  `simg` varchar(80) DEFAULT '' COMMENT '小图',
  `bimgs` mediumtext COMMENT '车辆细节',
  `bimgsTitle` mediumtext COMMENT '细节图名称（回车隔开）',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`sort`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `sort` (`id`,`catid`,`status`,`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_cars`
--

LOCK TABLES `clt_cars` WRITE;
/*!40000 ALTER TABLE `clt_cars` DISABLE KEYS */;
INSERT INTO `clt_cars` VALUES (1,55,1,'admin','1','','','','',0,1,0,'',0,1,0,1545480522,1545482580,'插电式混合','优享','15.28','168','622','1.0T 125马力 L3','2挡自动','4671*1835*1460','4.9','营运超长质保','2715','油箱容积（L）','30','三元锂电池','53','百公里1.5L','约0.07元/公里','外观时尚，免购置税，不受限行管控，比较受网约车司机青睐','动力及保养成本介于纯电动车和传统燃油车之间','1',5.0,5.0,5.0,0.5,'/uploads/20181222/5570b7428044535c74aa847a2509fb94.png','/uploads/20181222/1910b55afec0b37c848561ac4cf8c1e9.png','/uploads/20181222/6fb6523010a56b4b0aadcea987134153.png','/uploads/20181222/e5aef03f8abce4c023a363197127389e.png;/uploads/20181222/ab8cb0a2e164048c44e9928b73d9b9d5.png;/uploads/20181222/78a763d746aa322da975398d6b281666.png;/uploads/20181222/0bc314bffb224e5e7cd9c4579d0b2e81.png;/uploads/20181222/69876f16162848068847bab2c4c2867d.png;/uploads/20181222/8c8bd94d8df9cc65ae81e9e2745f84a6.png;/uploads/20181222/e8064da117378ef0e6d8f1a3c425b98f.png;/uploads/20181222/34e1783c11e4de439b7826c651cbadcb.png;/uploads/20181222/7c5172510839bcdcf5709891e7799c72.png','中控\n旋钮式换挡杆\n前舱\n轮胎\n后排空间\n后备厢\n发动机\n充电口\n车尾'),(2,55,1,'admin','2','','','','',0,1,0,'',0,2,0,1545484913,0,'油气混动','优享','12.18','118','193','2.0L 161马力 L4','6挡手动','4855*1860*1475','--','营运超长质保','2805','油箱容积（L）','60','--','--','用气百公里9.1立方米','约0.07元/公里','车价低，空间大，客户认可度较高','手动挡，油气车后备厢空间小，受限行管控','1',4.5,4.5,3.5,3.0,'/uploads/20181222/aba795cc3d3abf74f5ea6f82ceecbce3.png','/uploads/20181222/b793e260d84a11ac701fc8106eeee7d1.png','/uploads/20181222/2d40ec69268ef6f8040ef585efa17868.png','/uploads/20181222/aa9717ef81fb85b5b8a5e18f864031a3.png;/uploads/20181222/5720021a472135be3c393ceef27e0606.png;/uploads/20181222/0db339d32c21c49a6166c4c2145341a0.png;/uploads/20181222/81f2c52d6d13c3bf50ba482c398d028e.png;/uploads/20181222/56b5e427c1b61e95200c81f4cb2603a6.png','中控\n轮胎\n后备厢\n发动机\n车尾'),(3,55,1,'admin','3','','','','',0,1,0,'',0,3,0,1545486794,1545488397,'油电混动','优享','14.18','--','--','1.8L 99马力 L4','无级变速','4630*1775*1485','4.2','营运超长质保','2700','油箱容积（L）','45','镍氢电池','--','综合油耗百公里4.2L','约0.1元/公里','市场占有率高，车辆保值，质量可靠，安全稳定，客户认可','保养成本高于新能源汽车，受限行管控','1',4.0,4.0,3.5,3.5,'/uploads/20181222/8bb0dda2896e469325e473a3665e063d.png','/uploads/20181222/0bc48c6d687c30929b438105c0acdfe3.png','/uploads/20181222/8dbc763de004a069b1b7d38c5d5ab93b.png','/uploads/20181222/e1f41f294cbf9c56d057c92f22c76236.png;/uploads/20181222/7c96446491844d20fafad64eb20deb55.png;/uploads/20181222/ab41ac1c4a7d4ebaf23c85ac6473eb13.png;/uploads/20181222/86e45484c089c085a71bd35a9cede482.png;/uploads/20181222/04efc283a93559f26c2de353b9512753.png;/uploads/20181222/b5ef02cb0a04d8df2df8b3d0fae4d533.png;/uploads/20181222/c1ab27fe1dadff2fd9ddf16f122f55ba.png;/uploads/20181222/3914e2fba12705fcd9683bd1d1d0fbba.png','中控\n天窗\n轮胎\n后备厢\n发动机\n大灯\n车尾\n安全气囊'),(4,55,1,'admin','4','','','','',0,1,0,'',0,4,0,1545486794,1545488465,'油电混动','优享','14.18','--','--','1.8L 99马力 L4','无级变速','4630*1775*1485','4.2','营运超长质保','2700','油箱容积（L）','45','镍氢电池','--','综合油耗百公里4.2L','约0.1元/公里','市场占有率高，车辆保值，质量可靠，安全稳定，客户认可','保养成本高于新能源汽车，受限行管控','1',4.0,4.0,3.5,3.5,'/uploads/20181222/8bb0dda2896e469325e473a3665e063d.png','/uploads/20181222/0bc48c6d687c30929b438105c0acdfe3.png','/uploads/20181222/8dbc763de004a069b1b7d38c5d5ab93b.png','/uploads/20181222/e1f41f294cbf9c56d057c92f22c76236.png;/uploads/20181222/7c96446491844d20fafad64eb20deb55.png;/uploads/20181222/ab41ac1c4a7d4ebaf23c85ac6473eb13.png;/uploads/20181222/86e45484c089c085a71bd35a9cede482.png;/uploads/20181222/04efc283a93559f26c2de353b9512753.png;/uploads/20181222/b5ef02cb0a04d8df2df8b3d0fae4d533.png;/uploads/20181222/c1ab27fe1dadff2fd9ddf16f122f55ba.png;/uploads/20181222/3914e2fba12705fcd9683bd1d1d0fbba.png','中控\n天窗\n轮胎\n后备厢\n发动机\n大灯\n车尾\n安全气囊'),(5,55,1,'admin','5','','','','',0,1,0,'',0,5,0,1545486794,0,'油电混动','优享','14.18','--','--','1.8L 99马力 L4','无级变速','4630*1775*1485','4.2','营运超长质保','2700','油箱容积（L）','45','镍氢电池','--','综合油耗百公里4.2L','约0.1元/公里','市场占有率高，车辆保值，质量可靠，安全稳定，客户认可','保养成本高于新能源汽车，受限行管控','1',4.0,4.0,3.5,3.5,'/uploads/20181222/8bb0dda2896e469325e473a3665e063d.png','/uploads/20181222/0bc48c6d687c30929b438105c0acdfe3.png','/uploads/20181222/8dbc763de004a069b1b7d38c5d5ab93b.png','/uploads/20181222/e1f41f294cbf9c56d057c92f22c76236.png;/uploads/20181222/7c96446491844d20fafad64eb20deb55.png;/uploads/20181222/ab41ac1c4a7d4ebaf23c85ac6473eb13.png;/uploads/20181222/86e45484c089c085a71bd35a9cede482.png;/uploads/20181222/04efc283a93559f26c2de353b9512753.png;/uploads/20181222/b5ef02cb0a04d8df2df8b3d0fae4d533.png;/uploads/20181222/c1ab27fe1dadff2fd9ddf16f122f55ba.png;/uploads/20181222/3914e2fba12705fcd9683bd1d1d0fbba.png','中控\n天窗\n轮胎\n后备厢\n发动机\n大灯\n车尾\n安全气囊'),(6,55,1,'admin','6','','','','',0,1,0,'',0,6,0,1545486794,0,'油电混动','优享','14.18','--','--','1.8L 99马力 L4','无级变速','4630*1775*1485','4.2','营运超长质保','2700','油箱容积（L）','45','镍氢电池','--','综合油耗百公里4.2L','约0.1元/公里','市场占有率高，车辆保值，质量可靠，安全稳定，客户认可','保养成本高于新能源汽车，受限行管控','1',4.0,4.0,3.5,3.5,'/uploads/20181222/8bb0dda2896e469325e473a3665e063d.png','/uploads/20181222/0bc48c6d687c30929b438105c0acdfe3.png','/uploads/20181222/8dbc763de004a069b1b7d38c5d5ab93b.png','/uploads/20181222/e1f41f294cbf9c56d057c92f22c76236.png;/uploads/20181222/7c96446491844d20fafad64eb20deb55.png;/uploads/20181222/ab41ac1c4a7d4ebaf23c85ac6473eb13.png;/uploads/20181222/86e45484c089c085a71bd35a9cede482.png;/uploads/20181222/04efc283a93559f26c2de353b9512753.png;/uploads/20181222/b5ef02cb0a04d8df2df8b3d0fae4d533.png;/uploads/20181222/c1ab27fe1dadff2fd9ddf16f122f55ba.png;/uploads/20181222/3914e2fba12705fcd9683bd1d1d0fbba.png','中控\n天窗\n轮胎\n后备厢\n发动机\n大灯\n车尾\n安全气囊'),(8,55,1,'admin','7','','','','',0,1,0,'',0,1,0,1545480522,1545482580,'插电式混合','优享','15.28','168','622','1.0T 125马力 L3','2挡自动','4671*1835*1460','4.9','营运超长质保','2715','油箱容积（L）','30','三元锂电池','53','百公里1.5L','约0.07元/公里','外观时尚，免购置税，不受限行管控，比较受网约车司机青睐','动力及保养成本介于纯电动车和传统燃油车之间','2',5.0,5.0,5.0,0.5,'/uploads/20181222/5570b7428044535c74aa847a2509fb94.png','/uploads/20181222/1910b55afec0b37c848561ac4cf8c1e9.png','/uploads/20181222/6fb6523010a56b4b0aadcea987134153.png','/uploads/20181222/e5aef03f8abce4c023a363197127389e.png;/uploads/20181222/ab8cb0a2e164048c44e9928b73d9b9d5.png;/uploads/20181222/78a763d746aa322da975398d6b281666.png;/uploads/20181222/0bc314bffb224e5e7cd9c4579d0b2e81.png;/uploads/20181222/69876f16162848068847bab2c4c2867d.png;/uploads/20181222/8c8bd94d8df9cc65ae81e9e2745f84a6.png;/uploads/20181222/e8064da117378ef0e6d8f1a3c425b98f.png;/uploads/20181222/34e1783c11e4de439b7826c651cbadcb.png;/uploads/20181222/7c5172510839bcdcf5709891e7799c72.png','中控\n旋钮式换挡杆\n前舱\n轮胎\n后排空间\n后备厢\n发动机\n充电口\n车尾'),(9,55,1,'admin','8','','','','',0,1,0,'',0,2,0,1545484913,0,'油气混动','优享','12.18','118','193','2.0L 161马力 L4','6挡手动','4855*1860*1475','--','营运超长质保','2805','油箱容积（L）','60','--','--','用气百公里9.1立方米','约0.07元/公里','车价低，空间大，客户认可度较高','手动挡，油气车后备厢空间小，受限行管控','2',4.5,4.5,3.5,3.0,'/uploads/20181222/aba795cc3d3abf74f5ea6f82ceecbce3.png','/uploads/20181222/b793e260d84a11ac701fc8106eeee7d1.png','/uploads/20181222/2d40ec69268ef6f8040ef585efa17868.png','/uploads/20181222/aa9717ef81fb85b5b8a5e18f864031a3.png;/uploads/20181222/5720021a472135be3c393ceef27e0606.png;/uploads/20181222/0db339d32c21c49a6166c4c2145341a0.png;/uploads/20181222/81f2c52d6d13c3bf50ba482c398d028e.png;/uploads/20181222/56b5e427c1b61e95200c81f4cb2603a6.png','中控\n轮胎\n后备厢\n发动机\n车尾'),(10,55,1,'admin','9','','','','',0,1,0,'',0,3,0,1545486794,1545488397,'油电混动','优享','14.18','--','--','1.8L 99马力 L4','无级变速','4630*1775*1485','4.2','营运超长质保','2700','油箱容积（L）','45','镍氢电池','--','综合油耗百公里4.2L','约0.1元/公里','市场占有率高，车辆保值，质量可靠，安全稳定，客户认可','保养成本高于新能源汽车，受限行管控','2',4.0,4.0,3.5,3.5,'/uploads/20181222/8bb0dda2896e469325e473a3665e063d.png','/uploads/20181222/0bc48c6d687c30929b438105c0acdfe3.png','/uploads/20181222/8dbc763de004a069b1b7d38c5d5ab93b.png','/uploads/20181222/e1f41f294cbf9c56d057c92f22c76236.png;/uploads/20181222/7c96446491844d20fafad64eb20deb55.png;/uploads/20181222/ab41ac1c4a7d4ebaf23c85ac6473eb13.png;/uploads/20181222/86e45484c089c085a71bd35a9cede482.png;/uploads/20181222/04efc283a93559f26c2de353b9512753.png;/uploads/20181222/b5ef02cb0a04d8df2df8b3d0fae4d533.png;/uploads/20181222/c1ab27fe1dadff2fd9ddf16f122f55ba.png;/uploads/20181222/3914e2fba12705fcd9683bd1d1d0fbba.png','中控\n天窗\n轮胎\n后备厢\n发动机\n大灯\n车尾\n安全气囊'),(11,55,1,'admin','10','','','','',0,1,0,'',0,4,0,1545486794,1545488465,'油电混动','优享','14.18','--','--','1.8L 99马力 L4','无级变速','4630*1775*1485','4.2','营运超长质保','2700','油箱容积（L）','45','镍氢电池','--','综合油耗百公里4.2L','约0.1元/公里','市场占有率高，车辆保值，质量可靠，安全稳定，客户认可','保养成本高于新能源汽车，受限行管控','2',4.0,4.0,3.5,3.5,'/uploads/20181222/8bb0dda2896e469325e473a3665e063d.png','/uploads/20181222/0bc48c6d687c30929b438105c0acdfe3.png','/uploads/20181222/8dbc763de004a069b1b7d38c5d5ab93b.png','/uploads/20181222/e1f41f294cbf9c56d057c92f22c76236.png;/uploads/20181222/7c96446491844d20fafad64eb20deb55.png;/uploads/20181222/ab41ac1c4a7d4ebaf23c85ac6473eb13.png;/uploads/20181222/86e45484c089c085a71bd35a9cede482.png;/uploads/20181222/04efc283a93559f26c2de353b9512753.png;/uploads/20181222/b5ef02cb0a04d8df2df8b3d0fae4d533.png;/uploads/20181222/c1ab27fe1dadff2fd9ddf16f122f55ba.png;/uploads/20181222/3914e2fba12705fcd9683bd1d1d0fbba.png','中控\n天窗\n轮胎\n后备厢\n发动机\n大灯\n车尾\n安全气囊'),(12,55,1,'admin','11','','','','',0,1,0,'',0,5,0,1545486794,0,'油电混动','优享','14.18','--','--','1.8L 99马力 L4','无级变速','4630*1775*1485','4.2','营运超长质保','2700','油箱容积（L）','45','镍氢电池','--','综合油耗百公里4.2L','约0.1元/公里','市场占有率高，车辆保值，质量可靠，安全稳定，客户认可','保养成本高于新能源汽车，受限行管控','2',4.0,4.0,3.5,3.5,'/uploads/20181222/8bb0dda2896e469325e473a3665e063d.png','/uploads/20181222/0bc48c6d687c30929b438105c0acdfe3.png','/uploads/20181222/8dbc763de004a069b1b7d38c5d5ab93b.png','/uploads/20181222/e1f41f294cbf9c56d057c92f22c76236.png;/uploads/20181222/7c96446491844d20fafad64eb20deb55.png;/uploads/20181222/ab41ac1c4a7d4ebaf23c85ac6473eb13.png;/uploads/20181222/86e45484c089c085a71bd35a9cede482.png;/uploads/20181222/04efc283a93559f26c2de353b9512753.png;/uploads/20181222/b5ef02cb0a04d8df2df8b3d0fae4d533.png;/uploads/20181222/c1ab27fe1dadff2fd9ddf16f122f55ba.png;/uploads/20181222/3914e2fba12705fcd9683bd1d1d0fbba.png','中控\n天窗\n轮胎\n后备厢\n发动机\n大灯\n车尾\n安全气囊'),(13,55,1,'admin','12','','','','',0,1,0,'',0,6,0,1545486794,0,'油电混动','优享','14.18','--','--','1.8L 99马力 L4','无级变速','4630*1775*1485','4.2','营运超长质保','2700','油箱容积（L）','45','镍氢电池','--','综合油耗百公里4.2L','约0.1元/公里','市场占有率高，车辆保值，质量可靠，安全稳定，客户认可','保养成本高于新能源汽车，受限行管控','2',4.0,4.0,3.5,3.5,'/uploads/20181222/8bb0dda2896e469325e473a3665e063d.png','/uploads/20181222/0bc48c6d687c30929b438105c0acdfe3.png','/uploads/20181222/8dbc763de004a069b1b7d38c5d5ab93b.png','/uploads/20181222/e1f41f294cbf9c56d057c92f22c76236.png;/uploads/20181222/7c96446491844d20fafad64eb20deb55.png;/uploads/20181222/ab41ac1c4a7d4ebaf23c85ac6473eb13.png;/uploads/20181222/86e45484c089c085a71bd35a9cede482.png;/uploads/20181222/04efc283a93559f26c2de353b9512753.png;/uploads/20181222/b5ef02cb0a04d8df2df8b3d0fae4d533.png;/uploads/20181222/c1ab27fe1dadff2fd9ddf16f122f55ba.png;/uploads/20181222/3914e2fba12705fcd9683bd1d1d0fbba.png','中控\n天窗\n轮胎\n后备厢\n发动机\n大灯\n车尾\n安全气囊');
/*!40000 ALTER TABLE `clt_cars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_category`
--

DROP TABLE IF EXISTS `clt_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_category` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `catname` varchar(255) NOT NULL DEFAULT '',
  `catdir` varchar(30) NOT NULL DEFAULT '',
  `parentdir` varchar(50) NOT NULL DEFAULT '',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `moduleid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `module` char(24) NOT NULL DEFAULT '',
  `arrparentid` varchar(255) NOT NULL DEFAULT '',
  `arrchildid` varchar(100) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(150) NOT NULL DEFAULT '',
  `keywords` varchar(200) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `sort` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ishtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ismenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `image` varchar(100) NOT NULL DEFAULT '',
  `imageMobile` varchar(255) DEFAULT '',
  `child` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` varchar(100) NOT NULL DEFAULT '',
  `template_list` varchar(20) NOT NULL DEFAULT '',
  `template_show` varchar(20) NOT NULL DEFAULT '',
  `pagesize` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `listtype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否预览',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`),
  KEY `listorder` (`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_category`
--

LOCK TABLES `clt_category` WRITE;
/*!40000 ALTER TABLE `clt_category` DISABLE KEYS */;
INSERT INTO `clt_category` VALUES (46,'行业动态','trade','',0,1,'page','0','46,47,48,49',0,'行业动态','行业动态','行业动态',1,0,1,0,'/uploads/20181222/146661e43e621b595477963c4aaa107f.png','/uploads/20181222/4dcf3a2628f3fa838de86de9abcf9dd5.png',0,'','','page_dynamic',0,'1',0,0,0),(2,'公司简介','about','',0,1,'page','0','2,44,45',0,'公司介绍','公司介绍','公司介绍',0,0,1,0,'/uploads/20181222/cb6413dc6f7dbc5cae664c7286c6a4d6.png','/uploads/20181222/f2996a4c5028d0c99838fc0a1e182487.png',1,'','','page_show',0,'1,2',0,0,0),(48,'证照相关','licence','trade/',46,1,'page','0,46','48',0,'','','',1,0,1,0,'','',0,'','','',0,'1',0,0,0),(47,'政策','policy','trade/',46,1,'page','0,46','47',0,'','','',0,0,1,0,'','',0,'','','',0,'1',0,0,0),(44,'公司简介','COMPANY PROFILE','about/',2,1,'page','0,2','44',0,'公司简介','公司简介','公司简介',0,0,1,0,'/uploads/20181222/faad4c6e5f24ef28fdccc33a34c840f7.png','/uploads/20181222/d8b6a40ebfa81c5bf4f90cbc1f55323c.png',0,'','','page_show',0,'1,2',0,0,0),(45,'公司环境','environment','about/',2,3,'picture','0,2','45',0,'公司环境','公司环境','公司环境',0,0,1,0,'/uploads/20181222/16c31e8365bdce5af5bb8cceb1815aa3.png','/uploads/20181222/a2c260e2c48dabc0da6ff5e58ad12f75.png',0,'','','',0,'1,2',0,0,0),(49,'合规公司优势','advantage','trade/',46,1,'page','0,46','49',0,'','','',2,0,1,0,'','',0,'','','',0,'1',0,0,0),(50,'公司优势','goodness','',0,1,'page','0','50,51,52',0,'公司优势','公司优势','公司优势',3,0,1,0,'/uploads/20181222/8097a49d095e082a2a9e45f2d6b6d158.png','/uploads/20181222/f45c96d9b87f795ae1ef7da99d4b75bf.png',1,'','','page_advantage',0,'1',0,0,0),(51,'公司保障','Corporate security','goodness/',50,25,'question','0,50','51',0,'','','',0,0,1,0,'','',0,'','','',0,'1',0,0,0),(52,'司机日常','Daily plan','goodness/',50,1,'page','0,50','52',0,'','','',0,0,1,0,'/uploads/20181222/916f9a0244e43d7aff4a70308312094c.png','/uploads/20181222/597999cfc2f7007e85a93e8094ab1ec0.png',0,'','','',0,'1',0,0,0),(53,'加入我们','join','',0,1,'page','0','53,54',0,'','','',5,0,1,0,'/uploads/20181222/8265b2b4237e91b625b85818e0a71df2.png','/uploads/20181222/fdaafb2235a09fb6a9aaa09d1581ccb9.png',0,'','','page_contact',0,'1',0,0,0),(54,'地址','address','join/',53,26,'address','0,53','54',0,'','','',0,0,0,0,'','',0,'','','',0,'1',0,0,0),(55,'车型展示','car','',0,27,'cars','0','55',0,'','','',2,0,1,0,'','',0,'','','',0,'1',0,0,0);
/*!40000 ALTER TABLE `clt_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_config`
--

DROP TABLE IF EXISTS `clt_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_config` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `name` varchar(50) DEFAULT NULL COMMENT '配置的key键名',
  `value` varchar(512) DEFAULT NULL COMMENT '配置的val值',
  `inc_type` varchar(64) DEFAULT NULL COMMENT '配置分组',
  `desc` varchar(50) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=90 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_config`
--

LOCK TABLES `clt_config` WRITE;
/*!40000 ALTER TABLE `clt_config` DISABLE KEYS */;
INSERT INTO `clt_config` VALUES (16,'is_mark','0','water','0'),(17,'mark_txt','','water','0'),(18,'mark_img','/public/upload/public/2017/01-20/10cd966bd5f3549833c09a5c9700a9b8.jpg','water','0'),(19,'mark_width','','water','0'),(20,'mark_height','','water','0'),(21,'mark_degree','54','water','0'),(22,'mark_quality','56','water','0'),(23,'sel','9','water','0'),(24,'sms_url','https://yunpan.cn/OcRgiKWxZFmjSJ','sms','0'),(25,'sms_user','','sms','0'),(26,'sms_pwd','访问密码 080e','sms','0'),(27,'regis_sms_enable','1','sms','0'),(28,'sms_time_out','1200','sms','0'),(38,'__hash__','8d9fea07e44955760d3407524e469255_6ac8706878aa807db7ffb09dd0b02453','sms','0'),(39,'__hash__','8d9fea07e44955760d3407524e469255_6ac8706878aa807db7ffb09dd0b02453','sms','0'),(56,'sms_appkey','123456789','sms','0'),(57,'sms_secretKey','123456789','sms','0'),(58,'sms_product','CLTPHP','sms','0'),(59,'sms_templateCode','SMS_101234567890','sms','0'),(60,'smtp_server','smtp.qq.com','smtp','0'),(61,'smtp_port','465','smtp','0'),(62,'smtp_user','1109305556@qq.com','smtp','0'),(63,'smtp_pwd','zmmqivfdfflahemiegc','smtp','0'),(64,'regis_smtp_enable','1','smtp','0'),(65,'test_eamil','23456@qq.com','smtp','0'),(70,'forget_pwd_sms_enable','1','sms','0'),(71,'bind_mobile_sms_enable','1','sms','0'),(72,'order_add_sms_enable','1','sms','0'),(73,'order_pay_sms_enable','1','sms','0'),(74,'order_shipping_sms_enable','1','sms','0'),(88,'email_id','CLTPHP官网','smtp','0'),(89,'test_eamil_info',' 您好！这是一封来自CLTPHP的测试邮件！','smtp','0');
/*!40000 ALTER TABLE `clt_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_debris`
--

DROP TABLE IF EXISTS `clt_debris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_debris` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `type_id` int(6) DEFAULT NULL COMMENT '碎片分类ID',
  `title` varchar(120) DEFAULT NULL COMMENT '标题',
  `content` text COMMENT '内容',
  `addtime` int(13) DEFAULT NULL COMMENT '添加时间',
  `sort` int(11) DEFAULT '50' COMMENT '排序',
  `url` varchar(120) DEFAULT '' COMMENT '链接',
  `pic` varchar(120) DEFAULT '' COMMENT '图片',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_debris`
--

LOCK TABLES `clt_debris` WRITE;
/*!40000 ALTER TABLE `clt_debris` DISABLE KEYS */;
INSERT INTO `clt_debris` VALUES (15,1,'我们的差异化','<p><span style=\"text-align: center;\">CLTPHP内容管理系统给您自由的模型构建权利，让您的想法通过您亲自操作实现。不要再为传统的数据库字段限制而发愁。一步删除，一步增加，您想要的，就是这一步。</span></p>',1503293255,1,'',''),(16,1,'完整的建站理念','<p><span style=\"text-align: center;\">CLTPHP可以轻松构建模型，让数据库随心而动，让内容表单随意而变。模型和栏目的绑定，是为了让前台页面能更好的为您的想法服务，让您不再为建站留下遗憾。</span></p>',1503293273,2,'',''),(17,1,'简单、高效、低门槛','<p><span style=\"text-align: center;\">CLTPHP内容管理系统，全程鼠标操作，不用手动建立数据库，不用画网站结构图，也不用打开编译器。网站后台直接</span><span style=\"text-align: center;\">编辑</span><span style=\"text-align: center;\">模版，让网站建设达到前所未有的极致简单。</span></p>',1503293291,3,'','');
/*!40000 ALTER TABLE `clt_debris` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_debris_type`
--

DROP TABLE IF EXISTS `clt_debris_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_debris_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) DEFAULT NULL,
  `sort` int(1) DEFAULT '50',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_debris_type`
--

LOCK TABLES `clt_debris_type` WRITE;
/*!40000 ALTER TABLE `clt_debris_type` DISABLE KEYS */;
INSERT INTO `clt_debris_type` VALUES (1,'【首页】中部碎片',1);
/*!40000 ALTER TABLE `clt_debris_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_donation`
--

DROP TABLE IF EXISTS `clt_donation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_donation` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `name` varchar(120) NOT NULL DEFAULT '' COMMENT '用户名',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '捐赠金额',
  `addtime` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_donation`
--

LOCK TABLES `clt_donation` WRITE;
/*!40000 ALTER TABLE `clt_donation` DISABLE KEYS */;
INSERT INTO `clt_donation` VALUES (3,'高飞',10.00,'1466566714'),(4,'王磊',5.50,'1466566733'),(5,'一匹忧郁的狼',11.11,'1466566780'),(6,'神盾',50.00,'1467517788'),(7,'赵云的枪',20.00,'1469582594'),(8,'王@楠',5.00,'1473155340'),(9,'王宁',10.00,'1473647377'),(11,'幽鸣',100.00,'1483080600'),(12,'得水',6.60,'1484874321'),(13,'挨踢男',50.00,'1485224098'),(14,'郭强',6.60,'1486343033'),(15,'周超',5.00,'1487570095'),(16,'栖息地',20.00,'1488507544'),(17,'杨萍',11.00,'1489368971'),(18,'杨蹦蹦V587',20.00,'1490608429'),(19,'锋行天下',20.00,'1499765536'),(20,'周伟',50.00,'1500014307'),(21,'王者不荣耀',20.00,'1500368368'),(22,'老虎的虎',5.00,'1500867256'),(23,'老夫子',20.00,'1501203253'),(24,'我是传奇',20.00,'1501567608'),(25,'秋心',10.00,'1501807989'),(31,'晓强',20.00,'1506742161'),(32,'再向南飞',20.00,'1507266070'),(33,'女王大人',300.00,'1508807674'),(34,'在路上',18.88,'1508851175'),(35,'玉望灬',3.00,'1509091826'),(36,'诚 ',40.00,'1510121131');
/*!40000 ALTER TABLE `clt_donation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_download`
--

DROP TABLE IF EXISTS `clt_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_download` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `description` mediumtext,
  `content` text,
  `template` varchar(40) NOT NULL DEFAULT '',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `readpoint` smallint(5) NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发布时间',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `files` varchar(80) NOT NULL DEFAULT '',
  `ext` varchar(255) NOT NULL DEFAULT 'zip',
  `size` varchar(255) NOT NULL DEFAULT '',
  `downs` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`sort`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_download`
--

LOCK TABLES `clt_download` WRITE;
/*!40000 ALTER TABLE `clt_download` DISABLE KEYS */;
/*!40000 ALTER TABLE `clt_download` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_feast`
--

DROP TABLE IF EXISTS `clt_feast`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_feast` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `title` varchar(120) DEFAULT '' COMMENT '标题',
  `open` int(1) DEFAULT '1' COMMENT '是否开启',
  `sort` int(4) DEFAULT '50' COMMENT '排序',
  `addtime` varchar(15) DEFAULT NULL COMMENT '添加时间',
  `feast_date` varchar(20) DEFAULT '' COMMENT '节日日期',
  `type` int(1) DEFAULT '1' COMMENT '1阳历 2农历',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='节日列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_feast`
--

LOCK TABLES `clt_feast` WRITE;
/*!40000 ALTER TABLE `clt_feast` DISABLE KEYS */;
INSERT INTO `clt_feast` VALUES (2,'圣诞节',1,50,'1513304012','12-25',1),(3,'中秋节',1,2,'1513317857','07-12',1),(4,'七夕',1,50,'1532420762','07-24',1);
/*!40000 ALTER TABLE `clt_feast` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_feast_element`
--

DROP TABLE IF EXISTS `clt_feast_element`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_feast_element` (
  `id` int(5) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `pid` int(4) DEFAULT NULL COMMENT '父级ID',
  `title` varchar(120) DEFAULT NULL COMMENT '标题',
  `css` text COMMENT 'CSS',
  `js` text COMMENT 'JS',
  `sort` int(5) DEFAULT '50' COMMENT '排序',
  `open` int(1) DEFAULT '1' COMMENT '是否开启',
  `addtime` varchar(15) DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='节日元素表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_feast_element`
--

LOCK TABLES `clt_feast_element` WRITE;
/*!40000 ALTER TABLE `clt_feast_element` DISABLE KEYS */;
INSERT INTO `clt_feast_element` VALUES (1,2,'内容雪人','#content-wrapper{position: relative;}\n#top-left img{width: 150px;}\n#top-left{position: absolute;top: 30px;left: -145px;}','$(\"#content-wrapper\").append(\"<div id=top-left><img src=/static/feast/christmas/top-left.png></div>\");',1,1,'1513309235'),(2,2,'主页右下角驯鹿','#body-right-bottom{position: fixed;bottom: 0;right: 20px;z-index:51}\n#body-right-bottom img{width: 400px;}','$(\"body\").append(\"<div id=body-right-bottom><img src=/static/feast/christmas/body-right-bottom.png></div>\");',2,1,'1513309340'),(3,2,'主页左下角圣诞树','#body-left-bottom{position: fixed;bottom: 0;left:0;z-index:51}\n#body-left-bottom img{width: 200px;}',' $(\"body\").append(\"<div id=body-left-bottom><img src=/static/feast/christmas/body-left-bottom.png></div>\");',3,1,'1513309488'),(4,2,'主页右上角铃铛','#body-top-right{position: fixed;top: 0;right:0;z-index: 100;}\n#body-top-right img{width: 120px;}',' $(\"body\").append(\"<div id=body-top-right><img src=/static/feast/christmas/body-top-right.png></div>\");',4,1,'1513309568'),(5,2,'主页左中部圣诞老人','#body-left-center{position: fixed;top: 300px;left: 0;z-index: 100;}\n#body-left-center img{width: 220px;}','$(\"body\").append(\"<div id=body-left-center><img src=/static/feast/christmas/body-left-center.png></div>\");',5,1,'1513309625'),(6,2,'下载栏树叶','.rfeatured-box{position: relative;}\n#right-one-top-right img{width: 60px;}\n#right-one-top-right{position: absolute;top: 0;right: -10px;}',' $(\".featured-box\").append(\"<div id=right-one-top-right><img src=/static/feast/christmas/right-one-top-right.png></div>\");',6,1,'1513309980'),(7,2,'导航栏雪景','header{position: relative;}\n#nav-bg img{}\n#nav-bg{position: absolute;bottom: -15px;height:30px;left: 0;width: 100%;background: url(\"/static/feast/christmas/nav-bg.png\")repeat-x; z-index:50}','$(\"header\").append(\"<div id=nav-bg><img src=/static/feast/christmas/nav-bg.png></div>\");',7,1,'1513310236'),(8,2,'主页背景','body{background: url(\"/static/feast/christmas/zbg.png\") no-repeat 100% 100%;background-size: 100%;}','',50,1,'1513310497'),(10,3,'主页左下角房子','#body-left-bottom{position: fixed;bottom: 0;left:0;}\n#body-left-bottom img{width: 200px;}',' $(\"body\").append(\"<div id=body-left-bottom><img src=/static/feast/zhongqiu/body-left-bottom.png></div>\");',50,1,'1513320275'),(11,3,'左上角文字','#body-top-left{position: fixed;top:0;left0;z-index: 100;}\n#body-top-left img{width: 350px;}',' $(\"body\").append(\"<div id=body-top-left><img src=/static/feast/zhongqiu/body-top-left.png?111></div>\");',50,1,'1513320569'),(12,3,'右上角嫦娥','#body-top-right{position: fixed;top: 0;right:0;z-index: 100;}\n#body-top-right img{width: 300px;}',' $(\"body\").append(\"<div id=body-top-right><img src=/static/feast/zhongqiu/body-top-right.png></div>\");',50,1,'1513321010'),(13,4,'右上角喜鹊','#body-top-right{position: fixed;top: 0;right:0;z-index: 100;}\n#body-top-right img{width: 300px;}',' $(\"body\").append(\"<div id=body-top-right><img src=/static/feast/qixi/bird.png></div>\");',1,1,'1528689869');
/*!40000 ALTER TABLE `clt_feast_element` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_field`
--

DROP TABLE IF EXISTS `clt_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_field` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `moduleid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `field` varchar(20) NOT NULL DEFAULT '',
  `name` varchar(30) NOT NULL DEFAULT '',
  `tips` varchar(150) NOT NULL DEFAULT '',
  `required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `minlength` int(10) unsigned NOT NULL DEFAULT '0',
  `maxlength` int(10) unsigned NOT NULL DEFAULT '0',
  `pattern` varchar(255) NOT NULL DEFAULT '',
  `errormsg` varchar(255) NOT NULL DEFAULT '',
  `class` varchar(20) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT '',
  `setup` text,
  `ispost` tinyint(1) NOT NULL DEFAULT '0',
  `unpostgroup` varchar(60) NOT NULL DEFAULT '',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=250 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_field`
--

LOCK TABLES `clt_field` WRITE;
/*!40000 ALTER TABLE `clt_field` DISABLE KEYS */;
INSERT INTO `clt_field` VALUES (1,1,'title','标题','',1,1,80,'defaul','标题必须为1-80个字符','title','title','array (\n  \'thumb\' => \'0\',\n  \'style\' => \'0\',\n)',1,'',1,1,1),(2,1,'hits','点击次数','',0,0,8,'','','','number','array (\n  \'size\' => \'10\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',8,0,0),(3,1,'createtime','发布时间','',1,0,0,'date','','','datetime','',1,'',97,1,1),(4,1,'template','模板','',0,0,0,'','','','template','',1,'',99,0,1),(5,1,'status','状态','',0,0,0,'defaul','','status','radio','array (\n  \'options\' => \'发布|1\n定时发布|0\',\n  \'fieldtype\' => \'varchar\',\n  \'numbertype\' => \'1\',\n  \'default\' => \'1\',\n)',0,'',98,1,1),(6,1,'content','内容','',1,0,0,'defaul','','content','editor','array (\n  \'edittype\' => \'wangEditor\',\n)',0,'',3,1,0),(7,2,'catid','栏目','',1,1,6,'','必须选择一个栏目','','catid','',1,'',1,1,1),(8,2,'title','标题','',1,1,80,'defaul','标题必须为1-80个字符','title','title','array (\n  \'thumb\' => \'0\',\n  \'style\' => \'0\',\n)',1,'',2,1,1),(9,2,'keywords','关键词','',0,0,80,'','','','text','array (\n  \'size\' => \'55\',\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',1,'',3,1,1),(10,2,'description','SEO简介','',0,0,0,'defaul','','description','textarea','array (\n  \'fieldtype\' => \'text\',\n  \'default\' => \'\',\n)',1,'',4,1,1),(11,2,'content','内容','',0,0,0,'defaul','','content','editor','array (\n  \'edittype\' => \'nkeditor\',\n)',1,'',5,1,1),(12,2,'createtime','发布时间','',1,0,0,'date','','createtime','datetime','',1,'',6,1,1),(13,2,'recommend','允许评论','',0,0,1,'','','','radio','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'\',\n  \'default\' => \'\',\n)',1,'',10,0,0),(14,2,'readpoint','阅读收费','',0,0,5,'','','','number','array (\n  \'size\' => \'5\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',11,0,0),(15,2,'hits','点击次数','',0,0,8,'','','','number','array (\n  \'size\' => \'10\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',12,1,0),(16,2,'readgroup','访问权限','',0,0,0,'','','','groupid','array (\n  \'inputtype\' => \'checkbox\',\n  \'fieldtype\' => \'tinyint\',\n  \'labelwidth\' => \'85\',\n  \'default\' => \'\',\n)',1,'',13,1,1),(17,2,'posid','推荐位','',0,0,0,'','','','posid','',1,'',14,1,1),(18,2,'template','模板','',0,0,0,'','','','template','',1,'',15,1,1),(19,2,'status','状态','',0,0,0,'defaul','','status','radio','array (\n  \'options\' => \'发布|1\n定时发布|2\',\n  \'fieldtype\' => \'varchar\',\n  \'numbertype\' => \'1\',\n  \'default\' => \'1\',\n)',1,'',7,1,1),(20,3,'catid','栏目','',1,1,6,'','必须选择一个栏目','','catid','',1,'',1,1,1),(21,3,'title','标题','',1,1,80,'defaul','标题必须为1-80个字符','','title','array (\n  \'thumb\' => \'0\',\n  \'style\' => \'0\',\n)',1,'',2,1,1),(22,3,'keywords','关键词','',0,0,80,'','','','text','array (\n  \'size\' => \'55\',\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',1,'',3,0,1),(23,3,'description','SEO简介','',0,0,0,'','','','textarea','array (\n  \'fieldtype\' => \'mediumtext\',\n  \'rows\' => \'4\',\n  \'cols\' => \'55\',\n  \'default\' => \'\',\n)',1,'',4,0,1),(24,3,'content','内容','',0,0,0,'defaul','','content','editor','array (\n  \'edittype\' => \'layedit\',\n)',1,'',7,0,1),(25,3,'createtime','发布时间','',1,0,0,'date','','','datetime','',1,'',8,1,1),(26,3,'recommend','允许评论','',0,0,1,'','','','radio','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'\',\n  \'default\' => \'\',\n)',1,'',10,0,0),(27,3,'readpoint','阅读收费','',0,0,5,'','','','number','array (\n  \'size\' => \'5\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',11,0,0),(28,3,'hits','点击次数','',0,0,8,'','','','number','array (\n  \'size\' => \'10\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',12,0,0),(29,3,'readgroup','访问权限','',0,0,0,'','','','groupid','array (\n  \'inputtype\' => \'checkbox\',\n  \'fieldtype\' => \'tinyint\',\n  \'labelwidth\' => \'85\',\n  \'default\' => \'\',\n)',1,'',13,0,1),(30,3,'posid','推荐位','',0,0,0,'','','','posid','',1,'',14,0,1),(31,3,'template','模板','',0,0,0,'','','','template','',1,'',15,0,1),(32,3,'status','状态','',0,0,0,'','','','radio','array (\n  \'options\' => \'发布|1\r\n定时发布|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'75\',\n  \'default\' => \'1\',\n)',1,'',9,1,1),(33,3,'pic','图片','',1,0,0,'defaul','','pic','image','',0,'',5,1,0),(34,3,'group','类型','',1,0,0,'defaul','','group','select','array (\n  \'options\' => \'模型管理|1\n分类管理|2\n内容管理|3\',\n  \'multiple\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n  \'numbertype\' => \'1\',\n  \'size\' => \'\',\n  \'default\' => \'\',\n)',0,'',6,0,0),(168,24,'readgroup','访问权限','',0,0,0,'','','','groupid','array (\n  \'inputtype\' => \'checkbox\',\n  \'fieldtype\' => \'tinyint\',\n  \'labelwidth\' => \'85\',\n  \'default\' => \'\',\n)',1,'',11,0,1),(167,24,'hits','点击次数','',0,0,8,'','','','number','array (\n  \'size\' => \'10\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',10,0,0),(166,24,'readpoint','阅读收费','',0,0,5,'','','','number','array (\n  \'size\' => \'5\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',9,0,0),(165,24,'recommend','允许评论','',0,0,1,'','','','radio','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'\',\n  \'default\' => \'\',\n)',1,'',8,0,0),(171,25,'catid','栏目','',1,1,6,'','必须选择一个栏目','','catid','',1,'',1,1,1),(163,24,'createtime','发布时间','',1,0,0,'date','','createtime','datetime','',1,'',6,1,1),(164,24,'status','状态','',0,0,0,'','','','radio','array (\n  \'options\' => \'发布|1\r\n定时发布|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'75\',\n  \'default\' => \'1\',\n)',1,'',7,1,1),(172,25,'title','标题','',1,1,80,'defaul','标题必须为1-80个字符','title','title','array (\n  \'thumb\' => \'0\',\n  \'style\' => \'0\',\n)',1,'',2,1,1),(162,24,'content','内容','',0,0,0,'defaul','','content','editor','array (\n  \'edittype\' => \'wangEditor\',\n)',1,'',5,1,1),(161,24,'description','SEO简介','',0,0,0,'defaul','','description','textarea','array (\n  \'fieldtype\' => \'mediumtext\',\n  \'default\' => \'\\\'\\\'\',\n)',1,'',4,0,1),(160,24,'keywords','关键词','',0,0,80,'','','','text','array (\n  \'size\' => \'55\',\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',1,'',3,0,1),(159,24,'title','标题','',1,1,80,'defaul','标题必须为1-80个字符','title','title','array (\n  \'thumb\' => \'0\',\n  \'style\' => \'0\',\n)',1,'',2,1,1),(158,24,'catid','栏目','',1,1,6,'','必须选择一个栏目','','catid','',1,'',1,1,1),(51,5,'catid','栏目','',1,1,6,'','必须选择一个栏目','','catid','',1,'',1,1,1),(52,5,'title','标题','',1,1,80,'defaul','标题必须为1-80个字符','title','title','array (\n  \'thumb\' => \'0\',\n  \'style\' => \'0\',\n)',1,'',2,1,1),(53,5,'keywords','关键词','',0,0,80,'','','','text','array (\n  \'size\' => \'55\',\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',1,'',3,0,1),(54,5,'description','SEO简介','',0,0,0,'','','','textarea','array (\n  \'fieldtype\' => \'mediumtext\',\n  \'rows\' => \'4\',\n  \'cols\' => \'55\',\n  \'default\' => \'\',\n)',1,'',4,0,1),(55,5,'content','内容','',0,0,0,'defaul','','content','editor','array (\n  \'edittype\' => \'layedit\',\n)',1,'',9,0,1),(56,5,'createtime','发布时间','',1,0,0,'date','','createtime','datetime','',1,'',10,1,1),(57,5,'status','状态','',0,0,0,'','','','radio','array (\n  \'options\' => \'发布|1\r\n定时发布|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'75\',\n  \'default\' => \'1\',\n)',1,'',11,1,1),(58,5,'recommend','允许评论','',0,0,1,'','','','radio','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'\',\n  \'default\' => \'\',\n)',1,'',12,0,0),(59,5,'readpoint','阅读收费','',0,0,5,'','','','number','array (\n  \'size\' => \'5\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',13,0,0),(60,5,'hits','点击次数','',0,0,8,'','','','number','array (\n  \'size\' => \'10\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',14,0,0),(61,5,'readgroup','访问权限','',0,0,0,'','','','groupid','array (\n  \'inputtype\' => \'checkbox\',\n  \'fieldtype\' => \'tinyint\',\n  \'labelwidth\' => \'85\',\n  \'default\' => \'\',\n)',1,'',15,0,1),(62,5,'posid','推荐位','',0,0,0,'','','','posid','',1,'',16,0,1),(63,5,'template','模板','',0,0,0,'','','','template','',1,'',17,0,1),(64,5,'files','上传文件','',0,0,0,'defaul','','files','file','array (\n  \'upload_allowext\' => \'zip,rar,doc,ppt\',\n)',0,'',5,1,0),(65,5,'ext','文档类型','',0,0,0,'defaul','','ext','text','array (\n  \'default\' => \'zip\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',6,0,0),(66,5,'size','文档大小','',0,0,0,'defaul','','size','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',7,0,0),(67,5,'downs','下载次数','',0,0,0,'defaul','','','number','array (\n  \'size\' => \'\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'\',\n)',0,'',8,0,0),(174,25,'description','SEO简介','',0,0,0,'','','','textarea','array (\n  \'fieldtype\' => \'mediumtext\',\n  \'rows\' => \'4\',\n  \'cols\' => \'55\',\n  \'default\' => \'\',\n)',1,'',4,0,1),(173,25,'keywords','关键词','',0,0,80,'','','','text','array (\n  \'size\' => \'55\',\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',1,'',3,0,1),(169,24,'posid','推荐位','',0,0,0,'','','','posid','',1,'',12,0,1),(170,24,'template','模板','',0,0,0,'','','','template','',1,'',13,0,1),(75,2,'copyfrom','来源','',0,0,0,'defaul','','copyfrom','text','array (\n  \'default\' => \'CLTPHP\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',8,1,0),(76,2,'fromlink','来源网址','',0,0,0,'defaul','','fromlink','text','array (\n  \'default\' => \'http://www.cltphp.com/\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',9,1,0),(175,25,'content','内容','',0,0,0,'defaul','','content','editor','array (\n  \'edittype\' => \'wangEditor\',\n)',1,'',5,1,1),(184,25,'english','英文名','',0,0,0,'defaul','','english','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',3,1,0),(176,25,'createtime','发布时间','',1,0,0,'date','','createtime','datetime','',1,'',6,1,1),(177,25,'status','状态','',0,0,0,'','','','radio','array (\n  \'options\' => \'发布|1\r\n定时发布|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'75\',\n  \'default\' => \'1\',\n)',1,'',7,1,1),(178,25,'recommend','允许评论','',0,0,1,'','','','radio','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'\',\n  \'default\' => \'\',\n)',1,'',8,0,0),(179,25,'readpoint','阅读收费','',0,0,5,'','','','number','array (\n  \'size\' => \'5\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',9,0,0),(180,25,'hits','点击次数','',0,0,8,'','','','number','array (\n  \'size\' => \'10\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',10,0,0),(181,25,'readgroup','访问权限','',0,0,0,'','','','groupid','array (\n  \'inputtype\' => \'checkbox\',\n  \'fieldtype\' => \'tinyint\',\n  \'labelwidth\' => \'85\',\n  \'default\' => \'\',\n)',1,'',11,0,1),(182,25,'posid','推荐位','',0,0,0,'','','','posid','',1,'',12,0,1),(183,25,'template','模板','',0,0,0,'','','','template','',1,'',13,0,1),(185,25,'image','图片','',1,0,0,'defaul','','image','image','array (\n  \'upload_allowext\' => \'jpg|jpeg|gif|png\',\n)',0,'',3,1,0),(186,26,'catid','栏目','',1,1,6,'','必须选择一个栏目','','catid','',1,'',1,1,1),(187,26,'title','标题','',1,1,80,'defaul','标题必须为1-80个字符','title','title','array (\n  \'thumb\' => \'0\',\n  \'style\' => \'0\',\n)',1,'',2,1,1),(188,26,'keywords','关键词','',0,0,80,'','','','text','array (\n  \'size\' => \'55\',\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',1,'',3,0,1),(189,26,'description','SEO简介','',0,0,0,'','','','textarea','array (\n  \'fieldtype\' => \'mediumtext\',\n  \'rows\' => \'4\',\n  \'cols\' => \'55\',\n  \'default\' => \'\',\n)',1,'',4,0,1),(190,26,'content','内容','',0,0,0,'','','','editor','array (\n  \'toolbar\' => \'full\',\n  \'default\' => \'\',\n  \'height\' => \'\',\n  \'showpage\' => \'1\',\n  \'enablekeylink\' => \'0\',\n  \'replacenum\' => \'\',\n  \'enablesaveimage\' => \'0\',\n  \'flashupload\' => \'1\',\n  \'alowuploadexts\' => \'\',\n)',1,'',5,0,1),(191,26,'createtime','发布时间','',1,0,0,'date','','createtime','datetime','',1,'',6,1,1),(192,26,'status','状态','',0,0,0,'','','','radio','array (\n  \'options\' => \'发布|1\r\n定时发布|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'75\',\n  \'default\' => \'1\',\n)',1,'',7,1,1),(193,26,'recommend','允许评论','',0,0,1,'','','','radio','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'\',\n  \'default\' => \'\',\n)',1,'',8,0,0),(194,26,'readpoint','阅读收费','',0,0,5,'','','','number','array (\n  \'size\' => \'5\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',9,0,0),(195,26,'hits','点击次数','',0,0,8,'','','','number','array (\n  \'size\' => \'10\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',10,0,0),(196,26,'readgroup','访问权限','',0,0,0,'','','','groupid','array (\n  \'inputtype\' => \'checkbox\',\n  \'fieldtype\' => \'tinyint\',\n  \'labelwidth\' => \'85\',\n  \'default\' => \'\',\n)',1,'',11,0,1),(197,26,'posid','推荐位','',0,0,0,'','','','posid','',1,'',12,0,1),(198,26,'template','模板','',0,0,0,'','','','template','',1,'',13,0,1),(199,26,'lon','经度','',0,0,0,'defaul','','lon','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(200,26,'lat','纬度','',0,0,0,'defaul','','lat','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(201,26,'address','地址','',0,0,0,'defaul','','address','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(202,27,'catid','栏目','',1,1,6,'','必须选择一个栏目','','catid','',1,'',1,1,1),(203,27,'title','标题','',1,1,80,'defaul','标题必须为1-80个字符','title','title','array (\n  \'thumb\' => \'0\',\n  \'style\' => \'0\',\n)',1,'',2,1,1),(204,27,'keywords','关键词','',0,0,80,'','','','text','array (\n  \'size\' => \'55\',\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',1,'',3,0,1),(205,27,'description','SEO简介','',0,0,0,'','','','textarea','array (\n  \'fieldtype\' => \'mediumtext\',\n  \'rows\' => \'4\',\n  \'cols\' => \'55\',\n  \'default\' => \'\',\n)',1,'',4,0,1),(206,27,'content','内容','',0,0,0,'','','','editor','array (\n  \'toolbar\' => \'full\',\n  \'default\' => \'\',\n  \'height\' => \'\',\n  \'showpage\' => \'1\',\n  \'enablekeylink\' => \'0\',\n  \'replacenum\' => \'\',\n  \'enablesaveimage\' => \'0\',\n  \'flashupload\' => \'1\',\n  \'alowuploadexts\' => \'\',\n)',1,'',5,0,1),(207,27,'createtime','发布时间','',1,0,0,'date','','createtime','datetime','',1,'',6,1,1),(208,27,'status','状态','',0,0,0,'','','','radio','array (\n  \'options\' => \'发布|1\r\n定时发布|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'75\',\n  \'default\' => \'1\',\n)',1,'',7,1,1),(209,27,'recommend','允许评论','',0,0,1,'','','','radio','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'fieldtype\' => \'tinyint\',\n  \'numbertype\' => \'1\',\n  \'labelwidth\' => \'\',\n  \'default\' => \'\',\n)',1,'',8,0,0),(210,27,'readpoint','阅读收费','',0,0,5,'','','','number','array (\n  \'size\' => \'5\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',9,0,0),(211,27,'hits','点击次数','',0,0,8,'','','','number','array (\n  \'size\' => \'10\',\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'0\',\n  \'default\' => \'0\',\n)',1,'',10,0,0),(212,27,'readgroup','访问权限','',0,0,0,'','','','groupid','array (\n  \'inputtype\' => \'checkbox\',\n  \'fieldtype\' => \'tinyint\',\n  \'labelwidth\' => \'85\',\n  \'default\' => \'\',\n)',1,'',11,0,1),(213,27,'posid','推荐位','',0,0,0,'','','','posid','',1,'',12,0,1),(214,27,'template','模板','',0,0,0,'','','','template','',1,'',13,0,1),(217,27,'type','类型','',1,0,0,'defaul','','type','select','array (\n  \'options\' => \'油电混动|油电混动\n插电式混合|插电式混合\n纯电动|纯电动\n油气混动|油气混动\',\n  \'multiple\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n  \'numbertype\' => \'1\',\n  \'size\' => \'\',\n  \'default\' => \'\',\n)',0,'',4,1,0),(218,27,'tag','标签','',1,0,0,'defaul','','tag','radio','array (\n  \'options\' => \'快车|快车\n优享|优享\',\n  \'fieldtype\' => \'varchar\',\n  \'numbertype\' => \'1\',\n  \'default\' => \'快车\',\n)',0,'',4,1,0),(219,27,'price','裸车价','',1,0,0,'defaul','','price','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(220,27,'maxKw','最大功率(KW)','',0,0,0,'defaul','','maxKw','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(221,27,'maxNm','最大扭矩(N*M)','',0,0,0,'defaul','','maxNm','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(222,27,'engine','发动机','',0,0,0,'defaul','','engine','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(223,27,'bsx','变速箱','',0,0,0,'defaul','','bsx','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(224,27,'size','长*宽*高(MM)','',0,0,0,'defaul','','size','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(225,27,'zhyh','工信部综合油耗(L/100KM)','',0,0,0,'defaul','','zhyh','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(226,27,'zb','整车质保','',0,0,0,'defaul','','zb','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(227,27,'zj','轴距(MM)','',0,0,0,'defaul','','zj','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(228,27,'riTitle','容积类型','',1,0,0,'defaul','','riTitle','radio','array (\n  \'options\' => \'油箱容积（L）|油箱容积（L）\n电池容量（kWh）|电池容量（kWh）\',\n  \'fieldtype\' => \'varchar\',\n  \'numbertype\' => \'1\',\n  \'default\' => \'油箱容积（L）\',\n)',0,'',4,1,0),(229,27,'rj','容积','',0,0,0,'defaul','','rj','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(230,27,'dc','电池类型','',0,0,0,'defaul','','dc','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(231,27,'lc','工信部续航里程(KM)','',0,0,0,'defaul','','lc','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(232,27,'dlcb','动力成本','',0,0,0,'defaul','','dlcb','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(233,27,'bycb','保养成本','',0,0,0,'defaul','','bycb','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(234,27,'ys','优势','',0,0,0,'defaul','','ys','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(235,27,'ls','劣势','',0,0,0,'defaul','','ls','text','array (\n  \'default\' => \'\',\n  \'ispassword\' => \'0\',\n  \'fieldtype\' => \'varchar\',\n)',0,'',4,1,0),(240,27,'address_id','地区','',1,0,0,'defaul','','address_id','radio','array (\n  \'options\' => \'石家庄|1\n保定|2\',\n  \'fieldtype\' => \'varchar\',\n  \'numbertype\' => \'1\',\n  \'default\' => \'1\',\n)',0,'',3,1,0),(241,27,'wgS','外观','',0,0,0,'digits','请输入0.5的整数倍','wgS','number','array (\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'1\',\n  \'default\' => \'5\',\n)',0,'',4,1,0),(242,27,'cbS','成本','',0,0,0,'digits','请输入0.5的整数倍','cbS','number','array (\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'1\',\n  \'default\' => \'5\',\n)',0,'',4,1,0),(243,27,'dlS','动力','',0,0,0,'digits','请输入0.5的整数倍','dlS','number','array (\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'1\',\n  \'default\' => \'5\',\n)',0,'',4,1,0),(244,27,'zbS','质保','',0,0,0,'digits','请输入0.5的整数倍','zbS','number','array (\n  \'numbertype\' => \'1\',\n  \'decimaldigits\' => \'1\',\n  \'default\' => \'0.5\',\n)',0,'',4,1,0),(245,27,'bgimg','背景图','',0,0,0,'defaul','','bgimg','image','array (\n  \'upload_allowext\' => \'jpg|jpeg|gif|png\',\n)',0,'',4,1,0),(246,27,'bg','大图','',0,0,0,'defaul','','bg','image','array (\n  \'upload_allowext\' => \'jpg|jpeg|gif|png\',\n)',0,'',4,1,0),(247,27,'simg','小图','',0,0,0,'defaul','','simg','image','array (\n  \'upload_allowext\' => \'jpg|jpeg|gif|png\',\n)',0,'',4,1,0),(248,27,'bimgs','车辆细节','',0,0,0,'defaul','','bimgs','images',NULL,0,'',4,1,0),(249,27,'bimgsTitle','细节图名称（回车隔开）','',0,0,0,'defaul','','bimgsTitle','textarea','array (\n  \'fieldtype\' => \'mediumtext\',\n  \'default\' => \'中控\n轮胎\n后备厢\n发动机\n车尾\n\',\n)',0,'',4,1,0);
/*!40000 ALTER TABLE `clt_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_link`
--

DROP TABLE IF EXISTS `clt_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_link` (
  `link_id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '链接名称',
  `url` varchar(200) NOT NULL COMMENT '链接URL',
  `type_id` tinyint(4) DEFAULT NULL COMMENT '所属栏目ID',
  `qq` varchar(20) NOT NULL COMMENT '联系QQ',
  `sort` int(5) NOT NULL DEFAULT '50' COMMENT '排序',
  `addtime` int(11) NOT NULL COMMENT '添加时间',
  `open` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0禁用1启用',
  PRIMARY KEY (`link_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_link`
--

LOCK TABLES `clt_link` WRITE;
/*!40000 ALTER TABLE `clt_link` DISABLE KEYS */;
INSERT INTO `clt_link` VALUES (10,'CLTPHP','http://www.cltphp.com/',0,'1109305987',1,1495183645,1),(8,'CLTPHP内容管理系统','http://www.cltphp.com/',0,'1109305987',2,1484791374,1),(11,'CLTPHP动态','http://www.cltphp.com/news-49.html',0,'',3,1499765975,1),(12,'关于我们','http://cltphp.com/about-8.html',0,'',4,1499766009,1),(13,'CLTPHP相关知识','http://cltphp.com/news-51.html',0,'',5,1499766031,1),(15,'有你有我影视','http://www.ynywo.com/',0,'',6,1501030917,1);
/*!40000 ALTER TABLE `clt_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_message`
--

DROP TABLE IF EXISTS `clt_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_message` (
  `message_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT '' COMMENT '留言标题',
  `mobile` varchar(15) NOT NULL DEFAULT '' COMMENT '留言电话',
  `addtime` varchar(15) NOT NULL COMMENT '留言时间',
  `open` tinyint(2) NOT NULL DEFAULT '0' COMMENT '1=审核 0=不审核',
  `ip` varchar(50) DEFAULT '' COMMENT '留言者IP',
  `number` int(50) NOT NULL COMMENT '驾龄',
  PRIMARY KEY (`message_id`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_message`
--

LOCK TABLES `clt_message` WRITE;
/*!40000 ALTER TABLE `clt_message` DISABLE KEYS */;
INSERT INTO `clt_message` VALUES (96,'测试6','15033332222','1545464311',0,'127.0.0.1',1);
/*!40000 ALTER TABLE `clt_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_module`
--

DROP TABLE IF EXISTS `clt_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_module` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(200) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listfields` varchar(255) NOT NULL DEFAULT '',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_module`
--

LOCK TABLES `clt_module` WRITE;
/*!40000 ALTER TABLE `clt_module` DISABLE KEYS */;
INSERT INTO `clt_module` VALUES (1,'单页模型','page','单页面',1,0,'*',0,1),(2,'文章模型','article','新闻文章',1,0,'*',0,1),(3,'图片模型','picture','图片展示',1,0,'*',0,1),(24,'招聘模型','recruit','人才招聘',1,0,'*',0,1),(5,'下载模型','download','文件下载',1,0,'*',0,1),(25,'问答模型','question','问答模型',1,0,'*',0,1),(26,'地区模型','address','',1,0,'*',0,1),(27,'汽车模型','cars','',1,0,'*',0,1);
/*!40000 ALTER TABLE `clt_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_oauth`
--

DROP TABLE IF EXISTS `clt_oauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_oauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `type` varchar(50) DEFAULT NULL COMMENT '账号类型',
  `openid` varchar(120) DEFAULT NULL COMMENT '第三方唯一标示',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_oauth`
--

LOCK TABLES `clt_oauth` WRITE;
/*!40000 ALTER TABLE `clt_oauth` DISABLE KEYS */;
/*!40000 ALTER TABLE `clt_oauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_page`
--

DROP TABLE IF EXISTS `clt_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_page` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `status` varchar(255) NOT NULL DEFAULT '1',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `lang` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content` text COMMENT '内容',
  `template` varchar(50) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_page`
--

LOCK TABLES `clt_page` WRITE;
/*!40000 ALTER TABLE `clt_page` DISABLE KEYS */;
INSERT INTO `clt_page` VALUES (2,'公司简介',40,'1',0,'',0,1504251653,0,0,'<p style=\"font-size:14px;font-family:;\"><br></p>','0'),(47,'政策',0,'1',0,'',0,1545459111,0,0,'<div class=\"floor-title\">\n						政府方面<br>\n						<span>Government aspects</span>\n					</div>\n					<div class=\"floor-1\">\n						<div class=\"cut-line\">\n							<div class=\"line\"></div>\n							<div class=\"line-title\">\n								人员要求\n							</div>\n						</div>\n						<div class=\"middle-title\">\n							<div class=\"top\">certificate</div>\n						</div>\n						<div class=\"img-word\">\n							<div class=\"back-img\">\n								<img src=\"/template/img/web/floor-1.png\" class=\"pc-web\">\n								<img src=\"/template/img/web/floor-1-mb.png\" class=\"mb-web\">\n							</div>\n							<div class=\"word-list\">\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/right-arrow.png\">\n									</div>\n									<div class=\"right-word\">\n										取得相应准驾车型机动车驾驶证并具有3年以上驾驶经历\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/right-arrow.png\">\n									</div>\n									<div class=\"right-word\">\n										无交通肇事犯罪、危险驾驶犯罪记录，无吸毒记录，无饮酒后驾驶记录，最近连续3个记分周期内没有记满12分记录\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/right-arrow.png\">\n									</div>\n									<div class=\"right-word\">\n										无暴力犯罪记录\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/right-arrow.png\">\n									</div>\n									<div class=\"right-word\">\n										有服务所在地户籍或取得服务所在地居住证\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/right-arrow.png\">\n									</div>\n									<div class=\"right-word\">\n										年龄男60岁、女55岁以下，取得健康证明\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/right-arrow.png\">\n									</div>\n									<div class=\"right-word\">\n										申请人取得《网络预约出租汽车驾驶员证》\n									</div>\n								</div>\n							</div>\n						</div>\n					</div>\n					<div class=\"floor-2\">\n						<div class=\"cut-line\">\n							<div class=\"line\"></div>\n							<div class=\"line-title\">\n								车辆要求\n							</div>\n						</div>\n						<div class=\"middle-title\">\n							<div class=\"top\">certificate</div>\n						</div>\n						<div class=\"img-word\">\n							<div class=\"left-img\">\n								<img src=\"/template/img/web/floor-2.png\">\n							</div>\n							<div class=\"right-word\">\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/left-arrow.png\">\n									</div>\n									<div class=\"word-box\">\n										本市号牌且登记注册的5座（含5座）以上，7座（含7座）以下乘用车\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/left-arrow.png\">\n									</div>\n									<div class=\"word-box\">\n										安装符合国家相关规定和标准的具有行驶记录、卫星定位、应急报警等功能的车载设备，并接入市出租汽车管理机构监管平台\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/left-arrow.png\">\n									</div>\n									<div class=\"word-box\">\n										车辆自公安交通管理部门首次注册登记到申请之日不超过3年，车辆的技术要求应当符合《道路运输车辆技术管理规定》有关规定，投保赔付额度不低于50万的第三者责任险及营运车辆相关商业保险\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/left-arrow.png\">\n									</div>\n									<div class=\"word-box\">\n										车辆计税价格应当高于我市同期上牌的巡游出租汽车\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/left-arrow.png\">\n									</div>\n									<div class=\"word-box\">\n										车辆属个人所有的，车辆所有人名下应当没有登记的其他巡游车和网约车，车辆所有人应当取得《网络预约出租汽车驾驶员证》，并承诺由本人驾驶该申请车辆提供网约车服务,不得倒卖、转租、转借他人\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/left-arrow.png\">\n									</div>\n									<div class=\"word-box\">\n										燃油车辆轴距不低于2675毫米，排量不低于1.8L或1.4T；新能源车辆轴距不低于2600毫米\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/left-arrow.png\">\n									</div>\n									<div class=\"word-box\">\n										车辆应有《网络预约出租汽车运输证》\n									</div>\n								</div>\n							</div>\n							<div class=\"clear\"></div>\n						</div>\n					</div>\n					<div class=\"floor-3\">\n						<div class=\"fixation\">\n							<div class=\"x-small-title\">\n								新政发布官网\n							</div>\n							<div class=\"middle-title\">\n								<div class=\"top\">点击查看官网</div>\n							</div>\n							<div class=\"cut-line\">\n								<div class=\"line\"></div>\n								<div class=\"line-title\">\n									<a href=\"\">http://www.sjz.gov.cn/col/1490952431216/2017/07/21/1500623305906.html</a>\n								</div>\n							</div>\n							<div class=\"img-word\">\n								<div class=\"left-word\">\n									<div class=\"small-title\">\n										平台方面<br>\n										<span>Platform aspects</span>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\"><img src=\"/template/img/web/left-arrow.png\" alt=\"\"></div>\n										<div class=\"word-box\">\n											合规司机收入更稳定\n										</div>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\"><img src=\"/template/img/web/left-arrow.png\" alt=\"\"></div>\n										<div class=\"word-box\">\n											合规司机平台专属接单奖励\n										</div>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\"><img src=\"/template/img/web/left-arrow.png\" alt=\"\"></div>\n										<div class=\"word-box\">\n											城市英雄等称号评比，将收获荣誉、奖品\n										</div>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\"><img src=\"/template/img/web/left-arrow.png\" alt=\"\"></div>\n										<div class=\"word-box\">\n											不定期司机培训\n										</div>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\"><img src=\"/template/img/web/left-arrow.png\" alt=\"\"></div>\n										<div class=\"word-box\">\n											统一组织网约车从业资格证安全培训\n										</div>\n									</div>\n								</div>\n								<div class=\"right-img\">\n									<img src=\"/template/img/web/floor-3.png\">\n								</div>\n								<div class=\"clear\"></div>\n							</div>\n						</div>\n					</div>',''),(48,'证照相关',0,'1',0,'',0,1545457997,0,0,'<div class=\"block-1\">\n						<div class=\"fixation\">\n							<div class=\"left-img\">\n								<img src=\"/template/img/web/card-1.png\" alt=\"\">\n							</div>\n							<div class=\"right-word\">\n								<div class=\"small-title\">\n									加入公司，证照办理优势<br>\n									<span>Processing advantages</span>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/left-arrow.png\">\n									</div>\n									<div class=\"word-box\">\n										公司统一办理车辆营运证即《网络预约出租汽车运输证》，司机无后顾之忧\n									</div>\n								</div>\n								<div class=\"word-line\">\n									<div class=\"left-arrow\">\n										<img src=\"/template/img/web/left-arrow.png\">\n									</div>\n									<div class=\"word-box\">\n										网约车从业资格证指定报名点，统一报名，免费培训\n									</div>\n								</div>\n							</div>\n						</div>\n					</div>\n					<div class=\"block-2\">\n						<div class=\"cut-line\">\n							<div class=\"line\"></div>\n							<div class=\"line-title\">\n								《网络预约出租汽车驾驶员证》准备资料\n							</div>\n						</div>\n						<div class=\"fixation\">\n							<div class=\"middle-title\">\n								<div class=\"top\">certificate</div>\n								<div class=\"eng-title\">Information preparation</div>\n							</div>\n							<div class=\"img-word\">\n								<div class=\"left-img\">\n									<img src=\"/template/img/web/card-2.png\">\n								</div>\n								<div class=\"right-word\">\n									<div class=\"word-line\">\n										<div class=\"left-arrow\">\n											<img src=\"/template/img/web/left-arrow.png\">\n										</div>\n										<div class=\"word-box\">\n											本市户籍人员携带本人身份证、驾驶证、健康证原件以及彩色复印件（三个证件复印到一张A4纸）\n										</div>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\">\n											<img src=\"/template/img/web/left-arrow.png\">\n										</div>\n										<div class=\"word-box\">\n											本市户籍人员携带本人身份证、驾驶证、健康证原件以及彩色复印件（三个证件复印到一张A4纸）\n										</div>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\">\n											<img src=\"/template/img/web/left-arrow.png\">\n										</div>\n										<div class=\"word-box\">\n											本人近期白底正装证件照片一寸3张、小二寸2张\n										</div>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\">\n											<img src=\"/template/img/web/left-arrow.png\">\n										</div>\n										<div class=\"word-box\">\n											驾驶证所在地交管部门开具的全国范围内的三年无重大交通事故证明（必须近期开具，之前开的无效，开具时需携带身份证，驾驶证）\n										</div>\n									</div>\n								</div>\n							</div>\n							<div class=\"img-word\">\n								<div class=\"left-word\">\n									<div class=\"small-title\">\n										报名地点<br>\n										<span>Registration Information</span>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\">\n											<img src=\"/template/img/web/left-arrow.png\">\n										</div>\n										<div class=\"word-box\">\n											河北省石家庄市长安区建华北大街与光华路交口百川大厦A座22层（长安区法院楼上）\n										</div>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\">\n											<img src=\"/template/img/web/left-arrow.png\">\n										</div>\n										<div class=\"word-box\">\n											报名时间：每周一至周六 上午9：10至-11：30         下午1：30至5：30\n										</div>\n									</div>\n								</div>\n								<div class=\"right-img\">\n									<img src=\"/template/img/web/card-3.png\">\n								</div>\n							</div>\n						</div>\n					</div>\n					<div class=\"block-3\">\n						<div class=\"cut-line\">\n							<div class=\"line\"></div>\n							<div class=\"line-title\">\n								车辆《网络预约出租汽车运输证》办证流程\n							</div>\n						</div>\n						<div class=\"fixation\">\n							<div class=\"middle-title\">\n								<div class=\"top\">process</div>\n								<div class=\"eng-title\">申请人或申请人委托的网约车平台公司，向注册所在地出租汽车管理机构提出申请，并提交下列申请材料：</div>\n							</div>\n							<div class=\"img-word\">\n								<div class=\"left-img\">\n									<img src=\"/template/img/web/card-4.png\">\n								</div>\n								<div class=\"right-word\">\n									<div class=\"word-line\">\n										<div class=\"left-arrow\">\n											<img src=\"/template/img/web/left-arrow.png\">\n										</div>\n										<div class=\"word-box\">\n											 《网络预约出租汽车运输证》申请表\n										</div>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\">\n											<img src=\"/template/img/web/left-arrow.png\">\n										</div>\n										<div class=\"word-box\">\n											 申请人所申请车辆的《机动车登记证书》、《机动车行驶证》和车辆技术等级评定结论，申请人的身份证、《网络预约出租汽车驾驶员证》及复印件（平台公司代为办理的，需持申请人委托书）\n										</div>\n									</div>\n									<div class=\"word-line\">\n										<div class=\"left-arrow\">\n											<img src=\"/template/img/web/left-arrow.png\">\n										</div>\n										<div class=\"word-box\">\n											车辆使用性质登记变更为《预约出租客运》申请表\n										</div>\n									</div>\n								</div>\n							</div>\n						</div>\n					</div><p><br></p>',''),(49,'合规公司优势',0,'1',0,'',0,1545459834,0,0,'<div class=\"fixation\">\n						<div class=\"window-title\">\n							合规公司优势<br>\n							<span>COMPLAINCE COMPANY ADVANTAGE</span>\n						</div>\n						<div class=\"short-line\"></div>\n						<div class=\"icon\">\n							<div class=\"icon-item\">\n								<div class=\"icon-img\"><img src=\"/template/img/web/icon.png\" alt=\"\"></div>\n								<div class=\"icon-word\">合规司机收入更高更稳定</div>\n							</div>\n							<div class=\"icon-item\">\n								<div class=\"icon-img\"><img src=\"/template/img/web/icon2.png\" alt=\"\"></div>\n								<div class=\"icon-word\">平台专属奖励</div>\n							</div>\n							<div class=\"icon-item\">\n								<div class=\"icon-img\"><img src=\"/template/img/web/icon3.png\" alt=\"\"></div>\n								<div class=\"icon-word\">接单区域自由</div>\n							</div>\n							<div class=\"icon-item\">\n								<div class=\"icon-img\"><img src=\"/template/img/web/icon4.png\" alt=\"\"></div>\n								<div class=\"icon-word\">证照升值</div>\n							</div>\n							<div class=\"clear\"></div>\n						</div>\n					</div>',''),(46,'',0,'1',0,'',0,0,0,0,NULL,''),(50,'公司优势',0,'1',0,'',0,1545542253,0,0,'<p>&nbsp;</p>',''),(51,'公司保障',0,'1',0,'',0,0,0,0,'',''),(52,'司机日常',0,'1',0,'',0,1545462736,0,0,'<div class=\"fixation\">\n					<div class=\"word\">\n						<div class=\"left-arrow\">\n							<img src=\"/template/img/web/right-arrow.png\">\n						</div>\n						<div class=\"small-title\">\n							奖励机制\n						</div>\n						<div class=\"word-cont\">\n							奖励机制：公司有完善的奖励机制，节假日福利，公司人文关怀福利，平台对公模式专属奖励，例：长春、哈尔滨、苏州等对公司机每日完成20单，常态化奖励50-100元不等\n						</div>\n					</div>\n					<div class=\"word\">\n						<div class=\"left-arrow\">\n							<img src=\"/template/img/web/right-arrow.png\">\n						</div>\n						<div class=\"small-title\">\n							奖励机制\n						</div>\n						<div class=\"word-cont\">\n							奖励机制：公司有完善的奖励机制，节假日福利，公司人文关怀福利，平台对公模式专属奖励，例：长春、哈尔滨、苏州等对公司机每日完成20单，常态化奖励50-100元不等\n						</div>\n					</div>\n				</div>',''),(53,'加入我们',0,'1',0,'',0,0,0,0,'',''),(44,'公司简介',0,'1',0,'',0,1545455531,0,0,'<p>巨鲨汽车为河北淞甸科技有限公司旗下汽车品牌，公司创立于2018年10月， 专注于网约车运营，是河北省首个与滴滴平台签约“车司合一”的公司。目前河北保定，重庆，成都均设立分公司。成立以来，始终坚持服务至上的理念，将司机创收放在首位，致力于让每个司机体面高收入的工作。公司拥有成熟高效完备的专业团队，秉承诚信、专业、服务、创新的经营理念，依托多年行业经验，以司机利益为中心、规模为基础、安全为保障，为司机提供全方位、专业化服务，实现公司与司机的共同发展。未来，公司规划运营近千辆合规网约车，并建设数个集司机餐厅、交流室、休息室、洗车、充电等为一体的汽车码头服务站，为司机提供一站式服务，打造全国性的网约车运营服务中心。</p><p><br></p>','');
/*!40000 ALTER TABLE `clt_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_picture`
--

DROP TABLE IF EXISTS `clt_picture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_picture` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` int(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(40) NOT NULL DEFAULT '',
  `title` varchar(80) NOT NULL DEFAULT '',
  `keywords` varchar(120) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `content` text NOT NULL,
  `template` varchar(40) NOT NULL DEFAULT '',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `readgroup` varchar(100) NOT NULL DEFAULT '',
  `readpoint` smallint(5) NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0',
  `pic` varchar(80) NOT NULL DEFAULT '',
  `group` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`sort`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `listorder` (`id`,`catid`,`status`,`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_picture`
--

LOCK TABLES `clt_picture` WRITE;
/*!40000 ALTER TABLE `clt_picture` DISABLE KEYS */;
INSERT INTO `clt_picture` VALUES (10,45,1,'admin','第一张','','','','',0,1,0,'',0,0,0,1545456796,0,'/uploads/20181222/6d30de152d1a4e26eda2c37299f9815a.png',''),(11,45,1,'admin','第二张','','','','',0,1,0,'',0,0,0,1545456814,0,'/uploads/20181222/53598ddef19ed9f22a4859bc61087393.png',''),(12,45,1,'admin','第三张','','','','',0,1,0,'',0,0,0,1545456826,0,'/uploads/20181222/df2799350de415d371ef60478e10d51f.png','');
/*!40000 ALTER TABLE `clt_picture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_plugin`
--

DROP TABLE IF EXISTS `clt_plugin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_plugin` (
  `code` varchar(13) DEFAULT NULL COMMENT '插件编码',
  `name` varchar(55) DEFAULT NULL COMMENT '中文名字',
  `version` varchar(255) DEFAULT NULL COMMENT '插件的版本',
  `author` varchar(30) DEFAULT NULL COMMENT '插件作者',
  `config` text COMMENT '配置信息',
  `config_value` text COMMENT '配置值信息',
  `desc` varchar(255) DEFAULT NULL COMMENT '插件描述',
  `status` tinyint(1) DEFAULT '0' COMMENT '是否启用',
  `type` varchar(50) DEFAULT NULL COMMENT '插件类型 payment支付 login 登陆 shipping物流',
  `icon` varchar(255) DEFAULT NULL COMMENT '图标',
  `bank_code` text COMMENT '网银配置信息',
  `scene` tinyint(1) DEFAULT '0' COMMENT '使用场景 0 PC+手机 1 手机 2 PC'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_plugin`
--

LOCK TABLES `clt_plugin` WRITE;
/*!40000 ALTER TABLE `clt_plugin` DISABLE KEYS */;
INSERT INTO `clt_plugin` VALUES ('qq','QQ登陆','1.0','CLTPHP','a:5:{i:0;a:4:{s:4:\"name\";s:5:\"appid\";s:5:\"label\";s:5:\"appid\";s:4:\"type\";s:4:\"text\";s:5:\"value\";s:0:\"\";}i:1;a:4:{s:4:\"name\";s:6:\"appkey\";s:5:\"label\";s:6:\"appkey\";s:4:\"type\";s:4:\"text\";s:5:\"value\";s:0:\"\";}i:2;a:4:{s:4:\"name\";s:8:\"callback\";s:5:\"label\";s:12:\"回调地址\";s:4:\"type\";s:4:\"text\";s:5:\"value\";s:37:\"http://cltdemo.test/index/callback/qq\";}i:3;a:4:{s:4:\"name\";s:5:\"scope\";s:5:\"label\";s:12:\"获取字段\";s:4:\"type\";s:8:\"textarea\";s:5:\"value\";s:225:\"get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo,check_page_fans,add_t,add_pic_t,del_t,get_repost_list,get_info,get_other_info,get_fanslist,get_idolist,add_idol,del_idol,get_tenpay_addr\";}i:4;a:4:{s:4:\"name\";s:11:\"errorReport\";s:5:\"label\";s:12:\"错误报告\";s:4:\"type\";s:4:\"text\";s:5:\"value\";s:4:\"true\";}}','a:5:{s:5:\"appid\";s:0:\"\";s:6:\"appkey\";s:0:\"\";s:8:\"callback\";s:37:\"http://cltdemo.test/index/callback/qq\";s:5:\"scope\";s:225:\"get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo,check_page_fans,add_t,add_pic_t,del_t,get_repost_list,get_info,get_other_info,get_fanslist,get_idolist,add_idol,del_idol,get_tenpay_addr\";s:11:\"errorReport\";s:4:\"true\";}','QQ登陆插件 ',1,'login','logo.png','s:0:\"\";',0),('changyan','畅言评论','1.0','CLTPHP','a:3:{i:0;a:4:{s:4:\"name\";s:6:\"app_id\";s:5:\"label\";s:6:\"app_id\";s:4:\"type\";s:4:\"text\";s:5:\"value\";s:0:\"\";}i:1;a:4:{s:4:\"name\";s:7:\"app_key\";s:5:\"label\";s:7:\"app_key\";s:4:\"type\";s:4:\"text\";s:5:\"value\";s:0:\"\";}i:2;a:4:{s:4:\"name\";s:6:\"config\";s:5:\"label\";s:6:\"config\";s:4:\"type\";s:4:\"text\";s:5:\"value\";s:0:\"\";}}','a:8:{s:5:\"appid\";s:0:\"\";s:6:\"appkey\";s:0:\"\";s:8:\"callback\";s:37:\"http://cltdemo.test/index/callback/qq\";s:5:\"scope\";s:225:\"get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo,check_page_fans,add_t,add_pic_t,del_t,get_repost_list,get_info,get_other_info,get_fanslist,get_idolist,add_idol,del_idol,get_tenpay_addr\";s:11:\"errorReport\";s:4:\"true\";s:6:\"app_id\";s:0:\"\";s:7:\"app_key\";s:0:\"\";s:6:\"config\";s:0:\"\";}','畅言评论插件 ',1,'msg','logo.png','s:0:\"\";',0);
/*!40000 ALTER TABLE `clt_plugin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_posid`
--

DROP TABLE IF EXISTS `clt_posid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_posid` (
  `id` tinyint(2) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `sort` tinyint(2) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_posid`
--

LOCK TABLES `clt_posid` WRITE;
/*!40000 ALTER TABLE `clt_posid` DISABLE KEYS */;
INSERT INTO `clt_posid` VALUES (1,'首页推荐',0),(2,'当前分类推荐',0);
/*!40000 ALTER TABLE `clt_posid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_question`
--

DROP TABLE IF EXISTS `clt_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_question` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `username` varchar(40) NOT NULL DEFAULT '' COMMENT '用户名',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `keywords` varchar(120) NOT NULL DEFAULT '' COMMENT '关键词',
  `description` mediumtext NOT NULL COMMENT '描述',
  `content` text COMMENT '内容',
  `template` varchar(40) NOT NULL DEFAULT '' COMMENT '模板',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '允许评论',
  `readgroup` varchar(100) NOT NULL DEFAULT '' COMMENT '访问权限',
  `readpoint` smallint(5) NOT NULL DEFAULT '0' COMMENT '阅读权限',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `hits` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点击',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `english` varchar(255) DEFAULT '' COMMENT '英文名',
  `image` varchar(80) NOT NULL DEFAULT '' COMMENT '图片',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`sort`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `sort` (`id`,`catid`,`status`,`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_question`
--

LOCK TABLES `clt_question` WRITE;
/*!40000 ALTER TABLE `clt_question` DISABLE KEYS */;
INSERT INTO `clt_question` VALUES (1,51,1,'admin','岗前培训','','','<p>公司为司机提供有关网约车运营中整套的服务培训教程，以便司机师傅更快更好进行网约车运营</p><p><br></p>','',0,1,0,'',0,1,0,1545461895,1545462016,'Pre-job training','/uploads/20181222/7adb2039cc771eadc70ecfd09f903984.png'),(2,51,1,'admin','运营分析','','','<p>公司为司机提供大数据化的车辆运营数据分析，通过分析驾驶员行为状态、运营状态、技能服务状态、掌握其优劣点进行精准培训提升，辅助司机师傅提升服务质量，提高流水收入</p><p><br></p>','',0,1,0,'',0,2,0,1545462020,0,'Operations analysis','/uploads/20181222/93d7802da4df98aa110038c92d9aca8b.png'),(3,51,1,'admin','专人对接','','','<p>公司为司机提供专属负责司管，帮助司机解决运营中出现的各类问题，从而更好的进行网约车运营</p><p><br></p>','',0,1,0,'',0,3,0,1545462056,0,'Man docking','/uploads/20181222/6c54ced4e5e1a4a9951f23fb59a5c666.png'),(4,51,1,'admin','车辆保障','','','<p>公司为司机车辆进行系统化的管理，提供车辆建档，保养保险到期提醒，车辆日常检查，车辆营运证辅助办理等服务</p><p><br></p>','',0,1,0,'',0,4,0,1545462093,0,'Vehicle protection','/uploads/20181222/a38851dcbb4625d83e61083989f7bcc8.png');
/*!40000 ALTER TABLE `clt_question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_recruit`
--

DROP TABLE IF EXISTS `clt_recruit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_recruit` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '分类ID',
  `userid` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `username` varchar(40) NOT NULL DEFAULT '' COMMENT '用户名',
  `title` varchar(80) NOT NULL DEFAULT '' COMMENT '标题',
  `keywords` varchar(120) NOT NULL DEFAULT '' COMMENT '关键词',
  `description` mediumtext COMMENT 'SEO简介',
  `content` text COMMENT '内容',
  `template` varchar(40) NOT NULL DEFAULT '' COMMENT '模板',
  `posid` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `recommend` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '允许评论',
  `readgroup` varchar(100) NOT NULL DEFAULT '' COMMENT '访问权限',
  `readpoint` smallint(5) NOT NULL DEFAULT '0' COMMENT '阅读权限',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `hits` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '点击',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `status` (`id`,`status`,`sort`),
  KEY `catid` (`id`,`catid`,`status`),
  KEY `sort` (`id`,`catid`,`status`,`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_recruit`
--

LOCK TABLES `clt_recruit` WRITE;
/*!40000 ALTER TABLE `clt_recruit` DISABLE KEYS */;
/*!40000 ALTER TABLE `clt_recruit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_region`
--

DROP TABLE IF EXISTS `clt_region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_region` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(120) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '2',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_region`
--

LOCK TABLES `clt_region` WRITE;
/*!40000 ALTER TABLE `clt_region` DISABLE KEYS */;
INSERT INTO `clt_region` VALUES (1,0,'中国',0),(2,1,'北京',1),(3,1,'安徽',1),(4,1,'福建',1),(5,1,'甘肃',1),(6,1,'广东',1),(7,1,'广西',1),(8,1,'贵州',1),(9,1,'海南',1),(10,1,'河北',1),(11,1,'河南',1),(12,1,'黑龙江',1),(13,1,'湖北',1),(14,1,'湖南',1),(15,1,'吉林',1),(16,1,'江苏',1),(17,1,'江西',1),(18,1,'辽宁',1),(19,1,'内蒙古',1),(20,1,'宁夏',1),(21,1,'青海',1),(22,1,'山东',1),(23,1,'山西',1),(24,1,'陕西',1),(25,1,'上海',1),(26,1,'四川',1),(27,1,'天津',1),(28,1,'西藏',1),(29,1,'新疆',1),(30,1,'云南',1),(31,1,'浙江',1),(32,1,'重庆',1),(33,1,'香港',1),(34,1,'澳门',1),(35,1,'台湾',1),(36,3,'安庆',2),(37,3,'蚌埠',2),(38,3,'巢湖',2),(39,3,'池州',2),(40,3,'滁州',2),(41,3,'阜阳',2),(42,3,'淮北',2),(43,3,'淮南',2),(44,3,'黄山',2),(45,3,'六安',2),(46,3,'马鞍山',2),(47,3,'宿州',2),(48,3,'铜陵',2),(49,3,'芜湖',2),(50,3,'宣城',2),(51,3,'亳州',2),(52,2,'北京',2),(53,4,'福州',2),(54,4,'龙岩',2),(55,4,'南平',2),(56,4,'宁德',2),(57,4,'莆田',2),(58,4,'泉州',2);
/*!40000 ALTER TABLE `clt_region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_role`
--

DROP TABLE IF EXISTS `clt_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remark` varchar(255) NOT NULL DEFAULT '',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(6) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_role`
--

LOCK TABLES `clt_role` WRITE;
/*!40000 ALTER TABLE `clt_role` DISABLE KEYS */;
INSERT INTO `clt_role` VALUES (1,'超级管理员',1,'超级管理',0,0),(2,'普通管理员',1,'普通管理员',0,0),(3,'注册用户',1,'注册用户',0,0),(4,'游客',1,'游客',0,0);
/*!40000 ALTER TABLE `clt_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_role_user`
--

DROP TABLE IF EXISTS `clt_role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT '0',
  `user_id` char(32) DEFAULT '0',
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_role_user`
--

LOCK TABLES `clt_role_user` WRITE;
/*!40000 ALTER TABLE `clt_role_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `clt_role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_system`
--

DROP TABLE IF EXISTS `clt_system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_system` (
  `id` int(36) unsigned NOT NULL,
  `name` char(36) NOT NULL DEFAULT '' COMMENT '网站名称',
  `url` varchar(36) NOT NULL DEFAULT '' COMMENT '网址',
  `title` varchar(200) NOT NULL COMMENT '标题',
  `key` varchar(200) NOT NULL COMMENT '关键字',
  `des` varchar(200) NOT NULL COMMENT '描述',
  `bah` varchar(50) DEFAULT NULL COMMENT '备案号',
  `copyright` varchar(30) DEFAULT NULL COMMENT 'copyright',
  `ads` varchar(120) DEFAULT NULL COMMENT '公司地址',
  `tel` varchar(15) DEFAULT NULL COMMENT '公司电话',
  `email` varchar(50) DEFAULT NULL COMMENT '公司邮箱',
  `logo` varchar(120) DEFAULT NULL COMMENT 'logo',
  `logoa` varchar(120) DEFAULT '',
  `mobile` varchar(10) DEFAULT 'open' COMMENT '是否开启手机端 open 开启 close 关闭',
  `code` varchar(10) DEFAULT 'close' COMMENT '是否开启验证码',
  `qrcode` varchar(120) DEFAULT '',
  `qrcodec` varchar(120) DEFAULT '',
  `qq` varchar(11) DEFAULT '',
  `host` varchar(20) DEFAULT '',
  `complain` varchar(20) NOT NULL DEFAULT '',
  `company` varchar(50) DEFAULT '' COMMENT '公司名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_system`
--

LOCK TABLES `clt_system` WRITE;
/*!40000 ALTER TABLE `clt_system` DISABLE KEYS */;
INSERT INTO `clt_system` VALUES (1,'巨鲨汽车','http://cltshow.test/','巨鲨汽车','巨鲨汽车','巨鲨汽车','陕ICP备15008093号-3','© 2005-2011,WWW.XXXXXX.COM巨鲨汽车','西安市雁塔区','400-800-7555','1109305556@qq.com','/uploads/20181222/8f6c34f1d54b3c272306c6d92c1f4f67.png','/uploads/20181222/1e932a72b4c9e7c5ccf2f48c443bec0b.png','close','close','/uploads/20181222/99e7bb0a5c547ba4ecf5a7c443bb7b6b.png','/uploads/20181222/d8852acfae8bc846fd93f2040fe69bd5.png','','','','河北淞甸科技有限公司');
/*!40000 ALTER TABLE `clt_system` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_user_level`
--

DROP TABLE IF EXISTS `clt_user_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_user_level` (
  `level_id` smallint(4) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `level_name` varchar(30) DEFAULT NULL COMMENT '头衔名称',
  `sort` int(3) DEFAULT '0' COMMENT '排序',
  `bomlimit` int(5) DEFAULT '0' COMMENT '积分下限',
  `toplimit` int(5) DEFAULT '0' COMMENT '积分上限',
  PRIMARY KEY (`level_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_user_level`
--

LOCK TABLES `clt_user_level` WRITE;
/*!40000 ALTER TABLE `clt_user_level` DISABLE KEYS */;
INSERT INTO `clt_user_level` VALUES (1,'注册会员',1,0,500),(2,'铜牌会员',2,501,1000),(3,'白银会员',3,1001,2000),(4,'黄金会员',4,2001,3500),(5,'钻石会员',5,3501,5500),(6,'超级VIP',6,5500,99999);
/*!40000 ALTER TABLE `clt_user_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_users`
--

DROP TABLE IF EXISTS `clt_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '表id',
  `email` varchar(60) NOT NULL DEFAULT '' COMMENT '邮件',
  `password` varchar(32) NOT NULL DEFAULT '' COMMENT '密码',
  `paypwd` varchar(32) DEFAULT NULL COMMENT '支付密码',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1 男 0 女',
  `birthday` int(11) NOT NULL DEFAULT '0' COMMENT '生日',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_ip` varchar(15) NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `qq` varchar(20) NOT NULL DEFAULT '' COMMENT 'QQ',
  `mobile` varchar(20) NOT NULL DEFAULT '' COMMENT '手机号码',
  `mobile_validated` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否验证手机',
  `oauth` varchar(10) DEFAULT '' COMMENT '第三方来源 wx weibo alipay',
  `openid` varchar(100) DEFAULT NULL COMMENT '第三方唯一标示',
  `unionid` varchar(100) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `province` int(6) DEFAULT '0' COMMENT '省份',
  `city` int(6) DEFAULT '0' COMMENT '市区',
  `district` int(6) DEFAULT '0' COMMENT '县',
  `email_validated` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否验证电子邮箱',
  `username` varchar(50) DEFAULT NULL COMMENT '第三方返回昵称',
  `level` tinyint(1) DEFAULT '1' COMMENT '会员等级',
  `is_lock` tinyint(1) DEFAULT '0' COMMENT '是否被锁定冻结',
  `token` varchar(64) DEFAULT '' COMMENT '用于app 授权类似于session_id',
  `sign` varchar(255) DEFAULT '' COMMENT '签名',
  `status` varchar(20) DEFAULT 'hide' COMMENT '登录状态',
  PRIMARY KEY (`id`),
  KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_users`
--

LOCK TABLES `clt_users` WRITE;
/*!40000 ALTER TABLE `clt_users` DISABLE KEYS */;
INSERT INTO `clt_users` VALUES (1,'1109305987@qq.com','',NULL,1,0,1516075631,0,'','','44311',0,'',NULL,NULL,'/uploads/20180613/fcb729987d8e9339bd9b2e85c85f3028.jpg',24,311,2599,0,'chichu',1,0,'','不要应为走得太远，就忘了当初为什么出发！','hide'),(2,'','e10adc3949ba59abbe56e057f20f883e',NULL,0,0,1542781390,0,'','','18092591522',1,'',NULL,NULL,NULL,0,0,0,0,'chichu',1,0,'','','hide');
/*!40000 ALTER TABLE `clt_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_auth`
--

DROP TABLE IF EXISTS `clt_wx_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_auth` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `authorizer_appid` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺的appid  授权之后不用刷新',
  `authorizer_refresh_token` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺授权之后的刷新token，每月刷新',
  `authorizer_access_token` varchar(255) NOT NULL DEFAULT '' COMMENT '店铺的公众号token，只有2小时',
  `func_info` varchar(1000) NOT NULL DEFAULT '' COMMENT '授权项目',
  `nick_name` varchar(50) NOT NULL DEFAULT '' COMMENT '公众号昵称',
  `head_img` varchar(255) NOT NULL DEFAULT '' COMMENT '公众号头像url',
  `user_name` varchar(50) NOT NULL DEFAULT '' COMMENT '公众号原始账号',
  `alias` varchar(255) NOT NULL DEFAULT '' COMMENT '公众号原始名称',
  `qrcode_url` varchar(255) NOT NULL DEFAULT '' COMMENT '公众号二维码url',
  `auth_time` int(11) DEFAULT '0' COMMENT '授权时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=8192 COMMENT='店铺(实例)微信公众账号授权';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_auth`
--

LOCK TABLES `clt_wx_auth` WRITE;
/*!40000 ALTER TABLE `clt_wx_auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `clt_wx_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_config`
--

DROP TABLE IF EXISTS `clt_wx_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `instance_id` int(11) NOT NULL DEFAULT '1' COMMENT '实例ID',
  `key` varchar(255) NOT NULL DEFAULT '' COMMENT '配置项WCHAT,QQ,WPAY,ALIPAY...',
  `value` varchar(1000) NOT NULL DEFAULT '' COMMENT '配置值json',
  `desc` varchar(1000) NOT NULL DEFAULT '' COMMENT '描述',
  `is_use` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否启用 1启用 0不启用',
  `create_time` int(11) DEFAULT '0' COMMENT '创建时间',
  `modify_time` int(11) DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=963 COMMENT='第三方配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_config`
--

LOCK TABLES `clt_wx_config` WRITE;
/*!40000 ALTER TABLE `clt_wx_config` DISABLE KEYS */;
INSERT INTO `clt_wx_config` VALUES (1,0,'WCHAT','{\"APP_KEY\":\"\",\"APP_SECRET\":\"\",\"AUTHORIZE\":\"http:\\/\\/b2c1.01.niushop.com.cn\",\"CALLBACK\":\"http:\\/\\/b2c1.01.niushop.com.cn\\/wap\\/Login\\/callback\"}','微信',0,1488350947,1497105440),(2,0,'SHOPWCHAT','{\"appid\":\"dfdsfdsf90bc7b7a\",\"appsecret\":\"e5147ce07128asdfds222f628b5c3fe1af2ea5797\",\"token\":\"dffdf\"}','',1,1497088090,1528690160);
/*!40000 ALTER TABLE `clt_wx_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_default_replay`
--

DROP TABLE IF EXISTS `clt_wx_default_replay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_default_replay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL COMMENT '店铺id',
  `reply_media_id` int(11) NOT NULL COMMENT '回复媒体内容id',
  `sort` int(11) NOT NULL,
  `create_time` int(11) DEFAULT '0',
  `modify_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=16384 COMMENT='关注时回复';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_default_replay`
--

LOCK TABLES `clt_wx_default_replay` WRITE;
/*!40000 ALTER TABLE `clt_wx_default_replay` DISABLE KEYS */;
INSERT INTO `clt_wx_default_replay` VALUES (3,0,4,0,1528695059,0);
/*!40000 ALTER TABLE `clt_wx_default_replay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_fans`
--

DROP TABLE IF EXISTS `clt_wx_fans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_fans` (
  `fans_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '粉丝ID',
  `uid` int(11) NOT NULL DEFAULT '0' COMMENT '会员编号ID',
  `source_uid` int(11) NOT NULL DEFAULT '0' COMMENT '推广人uid',
  `instance_id` int(11) NOT NULL COMMENT '店铺ID',
  `nickname` varchar(255) NOT NULL COMMENT '昵称',
  `nickname_decode` varchar(255) DEFAULT '',
  `headimgurl` varchar(500) NOT NULL DEFAULT '' COMMENT '头像',
  `sex` smallint(6) NOT NULL DEFAULT '1' COMMENT '性别',
  `language` varchar(20) NOT NULL DEFAULT '' COMMENT '用户语言',
  `country` varchar(60) NOT NULL DEFAULT '' COMMENT '国家',
  `province` varchar(255) NOT NULL DEFAULT '' COMMENT '省',
  `city` varchar(255) NOT NULL DEFAULT '' COMMENT '城市',
  `district` varchar(255) NOT NULL DEFAULT '' COMMENT '行政区/县',
  `openid` varchar(255) NOT NULL DEFAULT '' COMMENT '用户的标识，对当前公众号唯一     用户的唯一身份ID',
  `unionid` varchar(255) NOT NULL DEFAULT '' COMMENT '粉丝unionid',
  `groupid` int(11) NOT NULL DEFAULT '0' COMMENT '粉丝所在组id',
  `is_subscribe` bigint(1) NOT NULL DEFAULT '1' COMMENT '是否订阅',
  `memo` varchar(255) NOT NULL COMMENT '备注',
  `subscribe_date` int(11) DEFAULT '0' COMMENT '订阅时间',
  `unsubscribe_date` int(11) DEFAULT '0' COMMENT '解订阅时间',
  `update_date` int(11) DEFAULT '0' COMMENT '粉丝信息最后更新时间',
  PRIMARY KEY (`fans_id`),
  KEY `IDX_sys_weixin_fans_openid` (`openid`),
  KEY `IDX_sys_weixin_fans_unionid` (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1638 COMMENT='微信公众号获取粉丝列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_fans`
--

LOCK TABLES `clt_wx_fans` WRITE;
/*!40000 ALTER TABLE `clt_wx_fans` DISABLE KEYS */;
/*!40000 ALTER TABLE `clt_wx_fans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_follow_replay`
--

DROP TABLE IF EXISTS `clt_wx_follow_replay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_follow_replay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL COMMENT '店铺id',
  `reply_media_id` int(11) NOT NULL COMMENT '回复媒体内容id',
  `sort` int(11) NOT NULL,
  `create_time` int(11) DEFAULT '0',
  `modify_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=16384 COMMENT='关注时回复';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_follow_replay`
--

LOCK TABLES `clt_wx_follow_replay` WRITE;
/*!40000 ALTER TABLE `clt_wx_follow_replay` DISABLE KEYS */;
INSERT INTO `clt_wx_follow_replay` VALUES (2,0,1,0,1528695047,0);
/*!40000 ALTER TABLE `clt_wx_follow_replay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_key_replay`
--

DROP TABLE IF EXISTS `clt_wx_key_replay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_key_replay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `instance_id` int(11) NOT NULL COMMENT '店铺id',
  `key` varchar(255) NOT NULL COMMENT '关键词',
  `match_type` tinyint(4) NOT NULL COMMENT '匹配类型1模糊匹配2全部匹配',
  `reply_media_id` int(11) NOT NULL COMMENT '回复媒体内容id',
  `sort` int(11) NOT NULL,
  `create_time` int(11) DEFAULT '0',
  `modify_time` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=16384 COMMENT='关键词回复';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_key_replay`
--

LOCK TABLES `clt_wx_key_replay` WRITE;
/*!40000 ALTER TABLE `clt_wx_key_replay` DISABLE KEYS */;
INSERT INTO `clt_wx_key_replay` VALUES (2,0,'你好',1,3,0,1528696514,0);
/*!40000 ALTER TABLE `clt_wx_key_replay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_media`
--

DROP TABLE IF EXISTS `clt_wx_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_media` (
  `media_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '图文消息id',
  `title` varchar(100) DEFAULT NULL,
  `instance_id` int(11) NOT NULL DEFAULT '0' COMMENT '实例id店铺id',
  `type` varchar(255) NOT NULL DEFAULT '1' COMMENT '类型1文本(项表无内容) 2单图文 3多图文',
  `sort` int(11) NOT NULL DEFAULT '0',
  `create_time` int(11) DEFAULT '0' COMMENT '创建日期',
  `modify_time` int(11) DEFAULT '0' COMMENT '修改日期',
  PRIMARY KEY (`media_id`),
  UNIQUE KEY `id` (`media_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1170;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_media`
--

LOCK TABLES `clt_wx_media` WRITE;
/*!40000 ALTER TABLE `clt_wx_media` DISABLE KEYS */;
INSERT INTO `clt_wx_media` VALUES (1,'欢迎您来到CLTPHP官方公众号大世界！',0,'1',0,1512551413,0),(2,'你好，欢迎来到CLTPHP的世界！',0,'1',0,1512550726,0),(3,'CLTPHP内容管理系统',0,'2',0,1512550547,0),(4,'CLTPHP内容管理系统5.2.2发布',0,'3',0,1528694363,0),(5,'CLTPHP操作开发手册已完全更新',0,'2',0,1528694392,0),(6,'1111',0,'1',0,1528694379,0);
/*!40000 ALTER TABLE `clt_wx_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_media_item`
--

DROP TABLE IF EXISTS `clt_wx_media_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_media_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `media_id` int(11) NOT NULL COMMENT '图文消息id',
  `title` varchar(100) DEFAULT NULL,
  `author` varchar(50) NOT NULL COMMENT '作者',
  `cover` varchar(200) NOT NULL COMMENT '图文消息封面',
  `show_cover_pic` tinyint(4) NOT NULL DEFAULT '1' COMMENT '封面图片显示在正文中',
  `summary` text,
  `content` text NOT NULL COMMENT '正文',
  `content_source_url` varchar(200) NOT NULL DEFAULT '' COMMENT '图文消息的原文地址，即点击“阅读原文”后的URL',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序号',
  `hits` int(11) NOT NULL DEFAULT '0' COMMENT '阅读次数',
  PRIMARY KEY (`id`),
  KEY `id` (`media_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=712;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_media_item`
--

LOCK TABLES `clt_wx_media_item` WRITE;
/*!40000 ALTER TABLE `clt_wx_media_item` DISABLE KEYS */;
INSERT INTO `clt_wx_media_item` VALUES (28,3,'CLTPHP内容管理系统','cltphp','/uploads/20171206/6dfec00133ee42c5c33cea8ab0cfad8f.png',1,'CLTPHP内容管理系统，微信公众平台、APP移动应用设计、HTML5网站API定制开发。大型企业网站、个人博客论坛、手机网站定制开发。更高效、更快捷的进行定制开发。','<p style=\"text-indent: 2em;\"><span style=\"text-indent: 2em;\">虽然世界上有成千上万的建站系统，但CLTPHP会告诉你，真正高效的建站系统是什么样的。</span><br/></p><p style=\"text-indent: 2em;\"><br/></p><p style=\"text-indent: 2em;\">CLTPHP采用了优美的layui框架，一面极简，一面丰盈。加上angular Js，让数据交互变得更为简洁直白。用最基础的代码，实现最强大的效果，让你欲罢不能！</p><p style=\"text-indent: 2em;\"><br/></p><p style=\"text-indent: 2em;\">CLTPHP采用的ThinkPHP5为基础框架，从而使得CLTPHP的拓展性变的极为强大。从模型构造到栏目建立，再到前台展示，一气呵成，网站后台一条龙式操作，让小白用户能快速掌握CLTPHP管理系统的核心操作，让小白开发者能更好的理解CLTPHP的核心构建价值。</p><p><br/></p>','http://www.cltphp.com/',0,6),(29,2,'你好，欢迎来到CLTPHP的世界！','','',0,'','','',0,0),(42,1,'欢迎您来到CLTPHP官方公众号大世界！','','',0,'','','',0,0),(47,4,'CLTPHP内容管理系统5.2.2发布','chichu','/uploads/20180611/5df2c8dabd33e0a0672dcb94b51d5ada.jpg',1,'这是一篇多图文','<h4 style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-weight: normal; font-stretch: inherit; font-size: 22px; line-height: inherit; font-family: \">CLTPHP5.2.2发布</h4><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; vertical-align: baseline; margin: 0px; padding: 0px;\">修改bug若干</span></p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;\">下载地址：</span><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px;\"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;\"><a href=\"http://qiniu.cltphp.com/cltphp5.2.2.zip\" target=\"_self\" title=\"CLTPHP5.2.2\" style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px; color: rgb(0, 176, 80); outline: 0px;\"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px; text-decoration: none;\">CLTPHP5.2.2</span></a></span></span></p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px;\"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;\">补丁地址：</span><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px;\"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: 700; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px; color: rgb(0, 176, 80); outline: 0px;\"><span style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; line-height: 24px; vertical-align: baseline; margin: 0px; padding: 0px; text-decoration: none;\"><a href=\"http://qiniu.cltphp.com/CLTPHP5.2.1%E5%88%B05.2.2%E8%A1%A5%E4%B8%81.zip\" target=\"_self\" style=\"box-sizing: border-box; border: 0px; font-style: inherit; font-variant: inherit; font-weight: inherit; font-stretch: inherit; font-size: inherit; line-height: inherit; font-family: inherit; vertical-align: baseline; margin: 0px; padding: 0px; color: rgb(0, 176, 80); outline: 0px;\">CLTPHP5.2.1到5.2.2升级</a></span></span></span></p>','http://www.cltphp.com/newsInfo-44-5.html',0,0),(48,4,'给我们一点点时间 我们给你一个新突破','chichu','/uploads/20171206/18fd882e982e07e7b35dac5b962ab393.jpg',0,'给我们一点点时间 我们给你一个新突破','<p><span style=\"color: rgb(102, 102, 102); font-family: \">说实话，最近这段时间我们太忙了</span><img src=\"http://img.baidu.com/hi/jx2/j_0016.gif\"/><span style=\"color: rgb(102, 102, 102); font-family: \">，cltphp的开发，甚至可以说是搁浅了一段时间。不过，各位请耐心等待一下啊，给我们一点点时间，或许不止一点点，我们给你一个新突破。</span></p>','http://www.cltphp.com/newsInfo-45-5.html',0,0),(49,4,'CLTPHP操作开发手册已完全更新','chichu','/uploads/20171206/db19ac0c46a3ffd4ebf94028024d3036.jpg',1,'CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。','<p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \">CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \">喜欢的朋友可以购买参考</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \">同时希望CLTPHP的爱好者，可以给我提出更多CLTPHP的不足之处，让CLTPHP更健康的成长。</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \">手册地址：<a href=\"https://www.kancloud.cn/chichu/cltphp/\" target=\"_self\">https://www.kancloud.cn/chichu/cltphp/</a></p><p><br/></p>','http://www.cltphp.com/newsInfo-16-5.html',0,0),(50,6,'1111','','',0,'','','',0,0),(51,5,'CLTPHP操作开发手册已完全更新','chichu','/uploads/20180611/12e57c01f2bd9172c8c26de45cb796a6.jpg',0,'CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。','<p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; text-indent: 2em;\">CLTPHP操作开发手册已完全更新，CLTPHP核心价值，尽在其中。</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; font-family: \">喜欢的朋友可以购买参考</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; text-indent: 2em;\">同时希望CLTPHP的爱好者，可以给我提出更多CLTPHP的不足之处，让CLTPHP更健康的成长。</p><p style=\"box-sizing: border-box; border: 0px; font-variant-numeric: inherit; font-stretch: inherit; font-size: 14px; line-height: 24px; text-indent: 2em;\">手册地址：https://www.kancloud.cn/chichu/cltphp/</p><p><br/></p>','https://www.kancloud.cn/chichu/cltphp',0,0);
/*!40000 ALTER TABLE `clt_wx_media_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_menu`
--

DROP TABLE IF EXISTS `clt_wx_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_menu` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `instance_id` int(11) NOT NULL DEFAULT '0' COMMENT '店铺id',
  `menu_name` varchar(50) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `ico` varchar(32) NOT NULL DEFAULT '' COMMENT '菜图标单',
  `pid` int(11) NOT NULL DEFAULT '0' COMMENT '父菜单',
  `menu_event_type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1普通url 2 图文素材 3 功能',
  `media_id` int(11) NOT NULL DEFAULT '0' COMMENT '图文消息ID',
  `menu_event_url` varchar(255) NOT NULL DEFAULT '' COMMENT '菜单url',
  `hits` int(11) NOT NULL DEFAULT '0' COMMENT '触发数',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `create_date` int(11) DEFAULT '0' COMMENT '创建日期',
  `modify_date` int(11) DEFAULT '0' COMMENT '修改日期',
  PRIMARY KEY (`menu_id`),
  KEY `IDX_biz_shop_menu_orders` (`sort`),
  KEY `IDX_biz_shop_menu_shopId` (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 AVG_ROW_LENGTH=1638 COMMENT='微设置->微店菜单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_menu`
--

LOCK TABLES `clt_wx_menu` WRITE;
/*!40000 ALTER TABLE `clt_wx_menu` DISABLE KEYS */;
INSERT INTO `clt_wx_menu` VALUES (1,0,'官网','',0,2,3,'http://www.cltphp.com/',0,1,1512442512,0),(2,0,'手册','',0,2,5,'http://www.cltphp.com/',0,2,1512442543,0),(3,0,'论坛','',0,1,4,'http://bbs.cltphp.com/',0,3,1512547727,0),(4,0,'百度','',3,1,0,'http://www.baodu.com',0,1,1542783759,0);
/*!40000 ALTER TABLE `clt_wx_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_user`
--

DROP TABLE IF EXISTS `clt_wx_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '表id',
  `uid` int(11) NOT NULL COMMENT 'uid',
  `wxname` varchar(60) NOT NULL COMMENT '公众号名称',
  `aeskey` varchar(256) NOT NULL DEFAULT '' COMMENT 'aeskey',
  `encode` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'encode',
  `appid` varchar(50) NOT NULL DEFAULT '' COMMENT 'appid',
  `appsecret` varchar(50) NOT NULL DEFAULT '' COMMENT 'appsecret',
  `wxid` varchar(64) NOT NULL COMMENT '公众号原始ID',
  `weixin` char(64) NOT NULL COMMENT '微信号',
  `token` char(255) NOT NULL COMMENT 'token',
  `w_token` varchar(150) NOT NULL DEFAULT '' COMMENT '微信对接token',
  `create_time` int(11) NOT NULL COMMENT 'create_time',
  `updatetime` int(11) NOT NULL COMMENT 'updatetime',
  `tplcontentid` varchar(2) NOT NULL COMMENT '内容模版ID',
  `share_ticket` varchar(150) NOT NULL COMMENT '分享ticket',
  `share_dated` char(15) NOT NULL COMMENT 'share_dated',
  `authorizer_access_token` varchar(200) NOT NULL COMMENT 'authorizer_access_token',
  `authorizer_refresh_token` varchar(200) NOT NULL COMMENT 'authorizer_refresh_token',
  `authorizer_expires` char(10) NOT NULL COMMENT 'authorizer_expires',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  `web_access_token` varchar(200) NOT NULL COMMENT '网页授权token',
  `web_refresh_token` varchar(200) NOT NULL COMMENT 'web_refresh_token',
  `web_expires` int(11) NOT NULL COMMENT '过期时间',
  `menu_config` text COMMENT '菜单',
  `wait_access` tinyint(1) DEFAULT '0' COMMENT '微信接入状态,0待接入1已接入',
  `concern` varchar(225) DEFAULT '' COMMENT '关注回复',
  `default` varchar(225) DEFAULT '' COMMENT '默认回复',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `uid_2` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='微信公共帐号';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_user`
--

LOCK TABLES `clt_wx_user` WRITE;
/*!40000 ALTER TABLE `clt_wx_user` DISABLE KEYS */;
INSERT INTO `clt_wx_user` VALUES (1,0,'CLTPHP','',0,'wx08c8be078e00b88b','2e6f2d97d60582f21111be7862d14ddc','gh_8aacbef4e497','chichu12345','sdfdsfdsfdsf','cltphp',0,0,'','','','','','',1,'eY9W4LLdISpE3UtTfuodgz1HJdBYCMbzZWkiLEhF0Nzvzv2q2DtGIV5h7CPrc0Nd4_kJgKN_FdM3kNaCxfFC1wmu6JLnNoOrmMuy3FK2AhMDLCbAGAXFW','',1504242136,'0',0,'欢迎来到CLTPHP！CLTPHP采用ThinkPHP5作为基础框架，同时采用Layui作为后台界面，使得CLTPHP适用与大型企业网站、个人博客论坛、企业网站、手机网站的定制开发。更高效、更快捷的进行定制开发一直是CLTPHP追求的价值。','亲！您可以输入关键词来获取您想要知道的内容。（例：手册）');
/*!40000 ALTER TABLE `clt_wx_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_user_msg`
--

DROP TABLE IF EXISTS `clt_wx_user_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_user_msg` (
  `msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `msg_type` varchar(255) NOT NULL,
  `content` text,
  `is_replay` int(11) NOT NULL DEFAULT '0' COMMENT '是否回复',
  `create_time` int(11) DEFAULT '0',
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='微信用户消息表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_user_msg`
--

LOCK TABLES `clt_wx_user_msg` WRITE;
/*!40000 ALTER TABLE `clt_wx_user_msg` DISABLE KEYS */;
/*!40000 ALTER TABLE `clt_wx_user_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clt_wx_user_msg_replay`
--

DROP TABLE IF EXISTS `clt_wx_user_msg_replay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clt_wx_user_msg_replay` (
  `replay_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msg_id` int(11) NOT NULL,
  `replay_uid` int(11) NOT NULL COMMENT '当前客服uid',
  `replay_type` varchar(255) NOT NULL,
  `content` text,
  `replay_time` int(11) DEFAULT '0',
  PRIMARY KEY (`replay_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='微信用户消息回复表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clt_wx_user_msg_replay`
--

LOCK TABLES `clt_wx_user_msg_replay` WRITE;
/*!40000 ALTER TABLE `clt_wx_user_msg_replay` DISABLE KEYS */;
/*!40000 ALTER TABLE `clt_wx_user_msg_replay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts_tags`
--

DROP TABLE IF EXISTS `posts_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tag_id` int(11) DEFAULT NULL,
  `posts_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts_tags`
--

LOCK TABLES `posts_tags` WRITE;
/*!40000 ALTER TABLE `posts_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `posts_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT '' COMMENT '标签名称',
  `nums` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_admin`
--

DROP TABLE IF EXISTS `v9_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_admin` (
  `userid` mediumint(6) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL,
  `roleid` smallint(5) DEFAULT '0',
  `encrypt` varchar(6) DEFAULT NULL,
  `lastloginip` varchar(15) DEFAULT NULL,
  `lastlogintime` int(10) unsigned DEFAULT '0',
  `email` varchar(40) DEFAULT NULL,
  `realname` varchar(50) NOT NULL DEFAULT '',
  `card` varchar(255) NOT NULL,
  `lang` varchar(6) NOT NULL,
  PRIMARY KEY (`userid`),
  KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_admin`
--

LOCK TABLES `v9_admin` WRITE;
/*!40000 ALTER TABLE `v9_admin` DISABLE KEYS */;
INSERT INTO `v9_admin` VALUES (1,'admin','8ac9551ba9330d29c7adcc647c60e5a5',1,'nbpefj','127.0.0.1',1545282570,'aa@bb.com','','',''),(2,'linghang','e32c036833e28a23b789c7ed92166b09',1,'a8bqqg','127.0.0.1',1492597748,'lianghang@qq.com','领行','','');
/*!40000 ALTER TABLE `v9_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_admin_panel`
--

DROP TABLE IF EXISTS `v9_admin_panel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_admin_panel` (
  `menuid` mediumint(8) unsigned NOT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` char(32) DEFAULT NULL,
  `url` char(255) DEFAULT NULL,
  `datetime` int(10) unsigned DEFAULT '0',
  UNIQUE KEY `userid` (`menuid`,`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_admin_panel`
--

LOCK TABLES `v9_admin_panel` WRITE;
/*!40000 ALTER TABLE `v9_admin_panel` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_admin_panel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_admin_role`
--

DROP TABLE IF EXISTS `v9_admin_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_admin_role` (
  `roleid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `rolename` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`roleid`),
  KEY `listorder` (`listorder`),
  KEY `disabled` (`disabled`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_admin_role`
--

LOCK TABLES `v9_admin_role` WRITE;
/*!40000 ALTER TABLE `v9_admin_role` DISABLE KEYS */;
INSERT INTO `v9_admin_role` VALUES (1,'超级管理员','超级管理员',0,0),(2,'站点管理员','站点管理员',0,0),(3,'运营总监','运营总监',1,0),(4,'总编','总编',5,0),(5,'编辑','编辑',1,0),(7,'发布人员','发布人员',0,0);
/*!40000 ALTER TABLE `v9_admin_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_admin_role_priv`
--

DROP TABLE IF EXISTS `v9_admin_role_priv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_admin_role_priv` (
  `roleid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m` char(20) NOT NULL,
  `c` char(20) NOT NULL,
  `a` char(20) NOT NULL,
  `data` char(30) NOT NULL DEFAULT '',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  KEY `roleid` (`roleid`,`m`,`c`,`a`,`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_admin_role_priv`
--

LOCK TABLES `v9_admin_role_priv` WRITE;
/*!40000 ALTER TABLE `v9_admin_role_priv` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_admin_role_priv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_announce`
--

DROP TABLE IF EXISTS `v9_announce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_announce` (
  `aid` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` char(80) NOT NULL,
  `content` text NOT NULL,
  `starttime` date NOT NULL DEFAULT '0000-00-00',
  `endtime` date NOT NULL DEFAULT '0000-00-00',
  `username` varchar(40) NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` smallint(5) unsigned NOT NULL DEFAULT '0',
  `passed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `style` char(15) NOT NULL,
  `show_template` char(30) NOT NULL,
  PRIMARY KEY (`aid`),
  KEY `siteid` (`siteid`,`passed`,`endtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_announce`
--

LOCK TABLES `v9_announce` WRITE;
/*!40000 ALTER TABLE `v9_announce` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_announce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_attachment`
--

DROP TABLE IF EXISTS `v9_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_attachment` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` char(15) NOT NULL,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `filename` char(50) NOT NULL,
  `filepath` char(200) NOT NULL,
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` char(10) NOT NULL,
  `isimage` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isthumb` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `downloads` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uploadtime` int(10) unsigned NOT NULL DEFAULT '0',
  `uploadip` char(15) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `authcode` char(32) NOT NULL,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`),
  KEY `authcode` (`authcode`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_attachment`
--

LOCK TABLES `v9_attachment` WRITE;
/*!40000 ALTER TABLE `v9_attachment` DISABLE KEYS */;
INSERT INTO `v9_attachment` VALUES (1,'poster',0,'banner_tp.jpg','2018/1219/20181219061921570.jpg',131749,'jpg',1,0,0,1,1545214761,'127.0.0.1',1,'311b3b4e1ee3f45cf3cfc2d9911fcf95',1),(2,'content',0,'index_navtb1.png','2018/1219/20181219065710399.png',5059,'png',1,0,0,1,1545217030,'127.0.0.1',1,'647f25fa80204928e37ca515ccc467f3',1),(3,'content',0,'index_navtb2.png','2018/1219/20181219065736772.png',6567,'png',1,0,0,1,1545217056,'127.0.0.1',1,'d72a84f7e5b14cc73202e353ffad910b',1),(4,'content',0,'index_navtb3.png','2018/1219/20181219065755696.png',5683,'png',1,0,0,1,1545217075,'127.0.0.1',1,'bdbf044852c30b9fbbf1e353951721d8',1),(5,'content',0,'index_bt1.png','2018/1219/20181219070115257.png',1673,'png',1,0,0,1,1545217275,'127.0.0.1',1,'f71077bdfbc641145914c0fca432c352',1),(6,'content',0,'index_bt2.png','2018/1219/20181219070131231.png',1634,'png',1,0,0,1,1545217290,'127.0.0.1',1,'8379f4fdc6a6b8405b00dd1dcef3d988',1),(7,'content',12,'index_brand1.jpg','2018/1219/20181219070510763.jpg',7589,'jpg',1,0,0,1,1545217510,'127.0.0.1',1,'2830cf09048e4e182949e8c3d6770cc0',1),(8,'content',13,'index_brand2.jpg','2018/1219/20181219071021602.jpg',6918,'jpg',1,0,0,1,1545217821,'127.0.0.1',1,'2356b81017f4ee8e6b8d9e2817b33e30',1),(9,'content',0,'index_project1.jpg','2018/1219/20181219071229306.jpg',60288,'jpg',1,0,0,1,1545217949,'127.0.0.1',1,'10cac311851237be3a9295a162ae7326',1),(10,'content',0,'index_project2.jpg','2018/1219/20181219071242922.jpg',32440,'jpg',1,0,0,1,1545217962,'127.0.0.1',1,'6188470ed6308d906e18653fe553ad5f',1),(11,'content',0,'index_project3.jpg','2018/1219/20181219071255203.jpg',76850,'jpg',1,0,0,1,1545217975,'127.0.0.1',1,'3be6fddc4df6baef257af44b953a2ed6',1),(12,'content',18,'index_Appraisaltp.jpg','2018/1219/20181219071634243.jpg',42518,'jpg',1,0,0,1,1545218194,'127.0.0.1',1,'db2141b7522532a108cd656f36224a39',1),(13,'content',15,'index_Appraisaltp.jpg','2018/1219/20181219075649725.jpg',42518,'jpg',1,0,0,1,1545220609,'127.0.0.1',1,'e4680bd3e5262e5ee8c3329b572a9efb',1),(14,'content',25,'honner_tp.jpg','2018/1220/20181220042821698.jpg',122424,'jpg',1,0,0,1,1545294501,'127.0.0.1',1,'1590655789b8bec51b1d779e4cdb2e42',1),(15,'content',38,'wx_tp1.jpg','2018/1220/20181220045403722.jpg',13143,'jpg',1,0,0,1,1545296043,'127.0.0.1',1,'371f2e6edba34eea72915db33022d740',1),(16,'content',38,'wx_tp2.jpg','2018/1220/20181220045414168.jpg',13037,'jpg',1,0,0,1,1545296054,'127.0.0.1',1,'a8fabefa4194f71d2ccadff542908c3c',1),(17,'content',0,'news_tp.jpg','2018/1220/20181220050359395.jpg',66331,'jpg',1,0,0,1,1545296639,'127.0.0.1',0,'6237360655025bd3a71da328ba812144',1);
/*!40000 ALTER TABLE `v9_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_attachment_index`
--

DROP TABLE IF EXISTS `v9_attachment_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_attachment_index` (
  `keyid` char(30) NOT NULL,
  `aid` char(10) NOT NULL,
  KEY `keyid` (`keyid`),
  KEY `aid` (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_attachment_index`
--

LOCK TABLES `v9_attachment_index` WRITE;
/*!40000 ALTER TABLE `v9_attachment_index` DISABLE KEYS */;
INSERT INTO `v9_attachment_index` VALUES ('poster-11','1'),('poster-12','1'),('poster-13','1'),('catid-9','2'),('catid-10','3'),('catid-20','4'),('catid-12','5'),('catid-13','6'),('c-12-1','7'),('c-12-2','7'),('c-12-3','7'),('c-12-4','7'),('c-12-5','7'),('c-12-6','7'),('c-12-7','7'),('c-12-8','7'),('c-12-10','7'),('c-12-11','7'),('c-12-9','7'),('c-12-12','7'),('c-12-13','7'),('c-12-15','7'),('c-12-14','7'),('c-12-16','7'),('c-12-17','7'),('c-12-18','7'),('c-12-19','7'),('c-12-20','7'),('c-13-21','8'),('c-13-22','8'),('c-13-23','8'),('c-13-24','8'),('c-13-25','8'),('c-13-26','8'),('c-13-27','8'),('c-13-28','8'),('c-13-29','8'),('c-13-30','8'),('c-13-31','8'),('c-13-32','8'),('c-13-33','8'),('c-13-34','8'),('c-13-35','8'),('c-13-36','8'),('c-13-37','8'),('catid-15','9'),('catid-16','10'),('catid-17','11'),('c-18-38','12'),('c-18-39','12'),('c-18-41','12'),('c-18-40','12'),('c-9-42','12'),('c-9-43','12'),('c-9-44','12'),('c-9-45','12'),('c-9-46','12'),('c-9-47','12'),('c-9-48','12'),('c-9-49','12'),('c-9-50','12'),('c-9-51','12'),('c-9-52','12'),('c-9-53','12'),('c-9-54','12'),('c-9-55','12'),('c-15-56','13'),('c-15-57','13'),('c-15-58','13'),('c-15-59','13'),('c-15-60','13'),('c-15-61','13'),('c-15-62','13'),('c-15-63','13'),('c-15-64','13'),('c-15-65','13'),('c-15-66','13'),('c-15-67','13'),('c-15-68','13'),('c-15-69','13'),('c-15-70','13'),('c-25-101','14'),('c-25-103','14'),('c-25-102','14'),('c-25-104','14'),('c-25-106','14'),('c-25-107','14'),('c-25-105','14'),('c-25-108','14'),('c-25-109','14'),('c-25-110','14'),('c-25-111','14'),('c-25-112','14'),('c-25-113','14'),('c-25-114','14'),('c-38-1','15'),('c-38-1','16');
/*!40000 ALTER TABLE `v9_attachment_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_badword`
--

DROP TABLE IF EXISTS `v9_badword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_badword` (
  `badid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `badword` char(20) NOT NULL,
  `level` tinyint(5) NOT NULL DEFAULT '1',
  `replaceword` char(20) NOT NULL DEFAULT '0',
  `lastusetime` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`badid`),
  UNIQUE KEY `badword` (`badword`),
  KEY `usetimes` (`replaceword`,`listorder`),
  KEY `hits` (`listorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_badword`
--

LOCK TABLES `v9_badword` WRITE;
/*!40000 ALTER TABLE `v9_badword` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_badword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_block`
--

DROP TABLE IF EXISTS `v9_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_block` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned DEFAULT '0',
  `name` char(50) DEFAULT NULL,
  `pos` char(30) DEFAULT NULL,
  `type` tinyint(1) DEFAULT '0',
  `data` text,
  `template` text,
  PRIMARY KEY (`id`),
  KEY `pos` (`pos`),
  KEY `type` (`type`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_block`
--

LOCK TABLES `v9_block` WRITE;
/*!40000 ALTER TABLE `v9_block` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_block_history`
--

DROP TABLE IF EXISTS `v9_block_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_block_history` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `blockid` int(10) unsigned DEFAULT '0',
  `data` text,
  `creat_at` int(10) unsigned DEFAULT '0',
  `userid` mediumint(8) unsigned DEFAULT '0',
  `username` char(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_block_history`
--

LOCK TABLES `v9_block_history` WRITE;
/*!40000 ALTER TABLE `v9_block_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_block_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_block_priv`
--

DROP TABLE IF EXISTS `v9_block_priv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_block_priv` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `roleid` tinyint(3) unsigned DEFAULT '0',
  `siteid` smallint(5) unsigned DEFAULT '0',
  `blockid` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `blockid` (`blockid`),
  KEY `roleid` (`roleid`,`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_block_priv`
--

LOCK TABLES `v9_block_priv` WRITE;
/*!40000 ALTER TABLE `v9_block_priv` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_block_priv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_cache`
--

DROP TABLE IF EXISTS `v9_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_cache` (
  `filename` char(50) NOT NULL,
  `path` char(50) NOT NULL,
  `data` mediumtext NOT NULL,
  PRIMARY KEY (`filename`,`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_cache`
--

LOCK TABLES `v9_cache` WRITE;
/*!40000 ALTER TABLE `v9_cache` DISABLE KEYS */;
INSERT INTO `v9_cache` VALUES ('mood_program.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  1 => \n  array (\n    1 => \n    array (\n      \'use\' => \'1\',\n      \'name\' => \'震惊\',\n      \'pic\' => \'mood/a1.gif\',\n    ),\n    2 => \n    array (\n      \'use\' => \'1\',\n      \'name\' => \'不解\',\n      \'pic\' => \'mood/a2.gif\',\n    ),\n    3 => \n    array (\n      \'use\' => \'1\',\n      \'name\' => \'愤怒\',\n      \'pic\' => \'mood/a3.gif\',\n    ),\n    4 => \n    array (\n      \'use\' => \'1\',\n      \'name\' => \'杯具\',\n      \'pic\' => \'mood/a4.gif\',\n    ),\n    5 => \n    array (\n      \'use\' => \'1\',\n      \'name\' => \'无聊\',\n      \'pic\' => \'mood/a5.gif\',\n    ),\n    6 => \n    array (\n      \'use\' => \'1\',\n      \'name\' => \'高兴\',\n      \'pic\' => \'mood/a6.gif\',\n    ),\n    7 => \n    array (\n      \'use\' => \'1\',\n      \'name\' => \'支持\',\n      \'pic\' => \'mood/a7.gif\',\n    ),\n    8 => \n    array (\n      \'use\' => \'1\',\n      \'name\' => \'超赞\',\n      \'pic\' => \'mood/a8.gif\',\n    ),\n    9 => \n    array (\n      \'use\' => NULL,\n      \'name\' => \'\',\n      \'pic\' => \'\',\n    ),\n    10 => \n    array (\n      \'use\' => NULL,\n      \'name\' => \'\',\n      \'pic\' => \'\',\n    ),\n  ),\n);\n?>'),('category_content.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  21 => \'1\',\n  22 => \'1\',\n  23 => \'1\',\n  24 => \'1\',\n  25 => \'1\',\n  26 => \'1\',\n  27 => \'1\',\n  28 => \'1\',\n  29 => \'1\',\n  32 => \'1\',\n  33 => \'1\',\n  34 => \'1\',\n  35 => \'1\',\n  36 => \'1\',\n  37 => \'1\',\n  38 => \'1\',\n);\n?>'),('category_content_1.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  21 => \n  array (\n    \'catid\' => \'21\',\n    \'siteid\' => \'1\',\n    \'type\' => \'1\',\n    \'modelid\' => \'0\',\n    \'parentid\' => \'0\',\n    \'arrparentid\' => \'0\',\n    \'child\' => \'1\',\n    \'arrchildid\' => \'21,22,23,24,25\',\n    \'catname\' => \'关于我们\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'\',\n    \'catdir\' => \'about\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=21\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_jump\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}\',\n    \'listorder\' => \'21\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'guanyuwomen\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => NULL,\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => NULL,\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'\',\n    \'workflowid\' => NULL,\n    \'isdomain\' => \'0\',\n  ),\n  22 => \n  array (\n    \'catid\' => \'22\',\n    \'siteid\' => \'1\',\n    \'type\' => \'1\',\n    \'modelid\' => \'0\',\n    \'parentid\' => \'21\',\n    \'arrparentid\' => \'0,21\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'22\',\n    \'catname\' => \'公司简介\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'about/\',\n    \'catdir\' => \'introduce\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=22\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_about\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}\',\n    \'listorder\' => \'22\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'gongsijianjie\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => NULL,\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => NULL,\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'\',\n    \'workflowid\' => NULL,\n    \'isdomain\' => \'0\',\n  ),\n  23 => \n  array (\n    \'catid\' => \'23\',\n    \'siteid\' => \'1\',\n    \'type\' => \'1\',\n    \'modelid\' => \'0\',\n    \'parentid\' => \'21\',\n    \'arrparentid\' => \'0,21\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'23\',\n    \'catname\' => \'业务范围\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'about/\',\n    \'catdir\' => \'business\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=23\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_business\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}\',\n    \'listorder\' => \'23\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'yewufanwei\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => NULL,\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => NULL,\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'\',\n    \'workflowid\' => NULL,\n    \'isdomain\' => \'0\',\n  ),\n  24 => \n  array (\n    \'catid\' => \'24\',\n    \'siteid\' => \'1\',\n    \'type\' => \'1\',\n    \'modelid\' => \'0\',\n    \'parentid\' => \'21\',\n    \'arrparentid\' => \'0,21\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'24\',\n    \'catname\' => \'价值理念\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'about/\',\n    \'catdir\' => \'value\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=24\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_value\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}\',\n    \'listorder\' => \'24\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'jiazhilinian\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => NULL,\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => NULL,\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'\',\n    \'workflowid\' => NULL,\n    \'isdomain\' => \'0\',\n  ),\n  25 => \n  array (\n    \'catid\' => \'25\',\n    \'siteid\' => \'1\',\n    \'type\' => \'0\',\n    \'modelid\' => \'1\',\n    \'parentid\' => \'21\',\n    \'arrparentid\' => \'0,21\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'25\',\n    \'catname\' => \'资质荣誉\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'about/\',\n    \'catdir\' => \'honor\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=25\',\n    \'items\' => \'14\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"list_honor\",\"show_template\":\"show_news\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}\',\n    \'listorder\' => \'25\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'zizhirongyu\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => \'0\',\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => \'0\',\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'16\',\n    \'workflowid\' => \'\',\n    \'isdomain\' => \'0\',\n  ),\n  26 => \n  array (\n    \'catid\' => \'26\',\n    \'siteid\' => \'1\',\n    \'type\' => \'0\',\n    \'modelid\' => \'1\',\n    \'parentid\' => \'0\',\n    \'arrparentid\' => \'0\',\n    \'child\' => \'1\',\n    \'arrchildid\' => \'26,27,28\',\n    \'catname\' => \'资讯\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'\',\n    \'catdir\' => \'news\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=26\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"\",\"show_template\":\"\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}\',\n    \'listorder\' => \'26\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'zixun\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => \'0\',\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => \'0\',\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'16\',\n    \'workflowid\' => \'\',\n    \'isdomain\' => \'0\',\n  ),\n  27 => \n  array (\n    \'catid\' => \'27\',\n    \'siteid\' => \'1\',\n    \'type\' => \'0\',\n    \'modelid\' => \'1\',\n    \'parentid\' => \'26\',\n    \'arrparentid\' => \'0,26\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'27\',\n    \'catname\' => \'公司新闻\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'news/\',\n    \'catdir\' => \'company\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=27\',\n    \'items\' => \'12\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"list_news\",\"show_template\":\"show_news\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}\',\n    \'listorder\' => \'27\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'gongsixinwen\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => \'0\',\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => \'0\',\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'16\',\n    \'workflowid\' => \'\',\n    \'isdomain\' => \'0\',\n  ),\n  28 => \n  array (\n    \'catid\' => \'28\',\n    \'siteid\' => \'1\',\n    \'type\' => \'0\',\n    \'modelid\' => \'1\',\n    \'parentid\' => \'26\',\n    \'arrparentid\' => \'0,26\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'28\',\n    \'catname\' => \'行业动态\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'news/\',\n    \'catdir\' => \'trade\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=28\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"list_news\",\"show_template\":\"show_news\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}\',\n    \'listorder\' => \'28\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'xingyedongtai\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => \'0\',\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => \'0\',\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'16\',\n    \'workflowid\' => \'\',\n    \'isdomain\' => \'0\',\n  ),\n  29 => \n  array (\n    \'catid\' => \'29\',\n    \'siteid\' => \'1\',\n    \'type\' => \'1\',\n    \'modelid\' => \'0\',\n    \'parentid\' => \'0\',\n    \'arrparentid\' => \'0\',\n    \'child\' => \'1\',\n    \'arrchildid\' => \'29,32,36,37\',\n    \'catname\' => \'党建学习\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'\',\n    \'catdir\' => \'study\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=29\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}\',\n    \'listorder\' => \'29\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'dangjianxuexi\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => NULL,\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => NULL,\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'\',\n    \'workflowid\' => NULL,\n    \'isdomain\' => \'0\',\n  ),\n  32 => \n  array (\n    \'catid\' => \'32\',\n    \'siteid\' => \'1\',\n    \'type\' => \'1\',\n    \'modelid\' => \'0\',\n    \'parentid\' => \'29\',\n    \'arrparentid\' => \'0,29\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'32\',\n    \'catname\' => \'支部概括\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'study/\',\n    \'catdir\' => \'survey\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=32\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_survey\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}\',\n    \'listorder\' => \'32\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'zhibugaikuo\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => NULL,\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => NULL,\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'\',\n    \'workflowid\' => NULL,\n    \'isdomain\' => \'0\',\n  ),\n  33 => \n  array (\n    \'catid\' => \'33\',\n    \'siteid\' => \'1\',\n    \'type\' => \'1\',\n    \'modelid\' => \'0\',\n    \'parentid\' => \'0\',\n    \'arrparentid\' => \'0\',\n    \'child\' => \'1\',\n    \'arrchildid\' => \'33,34,35\',\n    \'catname\' => \'联系我们\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'\',\n    \'catdir\' => \'contact\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=33\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}\',\n    \'listorder\' => \'33\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'lianxiwomen\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => NULL,\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => NULL,\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'\',\n    \'workflowid\' => NULL,\n    \'isdomain\' => \'0\',\n  ),\n  34 => \n  array (\n    \'catid\' => \'34\',\n    \'siteid\' => \'1\',\n    \'type\' => \'1\',\n    \'modelid\' => \'0\',\n    \'parentid\' => \'33\',\n    \'arrparentid\' => \'0,33\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'34\',\n    \'catname\' => \'联系方式\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'contact/\',\n    \'catdir\' => \'way\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=34\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_contact\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}\',\n    \'listorder\' => \'34\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'lianxifangshi\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => NULL,\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => NULL,\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'\',\n    \'workflowid\' => NULL,\n    \'isdomain\' => \'0\',\n  ),\n  35 => \n  array (\n    \'catid\' => \'35\',\n    \'siteid\' => \'1\',\n    \'type\' => \'1\',\n    \'modelid\' => \'0\',\n    \'parentid\' => \'33\',\n    \'arrparentid\' => \'0,33\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'35\',\n    \'catname\' => \'招聘信息\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'contact/\',\n    \'catdir\' => \'recruit\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=35\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_recruit\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}\',\n    \'listorder\' => \'35\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'zhaopinxinxi\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => NULL,\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => NULL,\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'\',\n    \'workflowid\' => NULL,\n    \'isdomain\' => \'0\',\n  ),\n  36 => \n  array (\n    \'catid\' => \'36\',\n    \'siteid\' => \'1\',\n    \'type\' => \'0\',\n    \'modelid\' => \'1\',\n    \'parentid\' => \'29\',\n    \'arrparentid\' => \'0,29\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'36\',\n    \'catname\' => \'支部荣誉\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'study/\',\n    \'catdir\' => \'honors\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=36\',\n    \'items\' => \'18\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"list_party\",\"show_template\":\"show_news\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}\',\n    \'listorder\' => \'36\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'zhiburongyu\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => \'0\',\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => \'0\',\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'16\',\n    \'workflowid\' => \'\',\n    \'isdomain\' => \'0\',\n  ),\n  37 => \n  array (\n    \'catid\' => \'37\',\n    \'siteid\' => \'1\',\n    \'type\' => \'0\',\n    \'modelid\' => \'1\',\n    \'parentid\' => \'29\',\n    \'arrparentid\' => \'0,29\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'37\',\n    \'catname\' => \'支部活动\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'study/\',\n    \'catdir\' => \'activity\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=37\',\n    \'items\' => \'12\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"list_party\",\"show_template\":\"show_news\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}\',\n    \'listorder\' => \'37\',\n    \'ismenu\' => \'1\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'zhibuhuodong\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => \'0\',\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => \'0\',\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'16\',\n    \'workflowid\' => \'\',\n    \'isdomain\' => \'0\',\n  ),\n  38 => \n  array (\n    \'catid\' => \'38\',\n    \'siteid\' => \'1\',\n    \'type\' => \'0\',\n    \'modelid\' => \'12\',\n    \'parentid\' => \'0\',\n    \'arrparentid\' => \'0\',\n    \'child\' => \'0\',\n    \'arrchildid\' => \'38\',\n    \'catname\' => \'系统配置\',\n    \'style\' => \'\',\n    \'image\' => \'\',\n    \'description\' => \'\',\n    \'parentdir\' => \'\',\n    \'catdir\' => \'sys\',\n    \'url\' => \'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=38\',\n    \'items\' => \'0\',\n    \'hits\' => \'0\',\n    \'setting\' => \'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"\",\"list_template\":\"\",\"show_template\":\"\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}\',\n    \'listorder\' => \'38\',\n    \'ismenu\' => \'0\',\n    \'sethtml\' => \'0\',\n    \'letter\' => \'xitongpeizhi\',\n    \'usable_type\' => \'\',\n    \'create_to_html_root\' => \'0\',\n    \'ishtml\' => \'0\',\n    \'content_ishtml\' => \'0\',\n    \'category_ruleid\' => \'6\',\n    \'show_ruleid\' => \'16\',\n    \'workflowid\' => \'\',\n    \'isdomain\' => \'0\',\n  ),\n);\n?>'),('sitelist.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  1 => \n  array (\n    \'siteid\' => \'1\',\n    \'name\' => \'筑城融创\',\n    \'dirname\' => \'\',\n    \'domain\' => \'http://zhucheng.gitlay.com/\',\n    \'site_title\' => \'筑城融创\',\n    \'keywords\' => \'筑城融创\',\n    \'description\' => \'筑城融创\',\n    \'release_point\' => \'\',\n    \'default_style\' => \'zhucheng\',\n    \'template\' => \'zhucheng\',\n    \'setting\' => \'{\"upload_maxsize\":\"2048\",\"upload_allowext\":\"jpg|jpeg|gif|bmp|png|doc|docx|xls|xlsx|ppt|pptx|pdf|txt|rar|zip|swf\",\"watermark_enable\":\"1\",\"watermark_minwidth\":\"300\",\"watermark_minheight\":\"300\",\"watermark_img\":\"statics\\\\/images\\\\/water\\\\/\\\\/mark.png\",\"watermark_pct\":\"85\",\"watermark_quality\":\"80\",\"watermark_pos\":\"9\"}\',\n    \'uuid\' => \'c63c0957-24db-11e7-9d05-94de8058de48\',\n    \'url\' => \'http://zhucheng.gitlay.com/\',\n  ),\n);\n?>'),('category_items_13.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('downservers.cache.php','caches_commons/caches_data/','<?php\nreturn NULL;\n?>'),('badword.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('ipbanned.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('keylink.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('position.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  2 => \n  array (\n    \'posid\' => \'2\',\n    \'modelid\' => \'0\',\n    \'catid\' => \'0\',\n    \'name\' => \'首页头条推荐\',\n    \'maxnum\' => \'20\',\n    \'extention\' => NULL,\n    \'listorder\' => \'4\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n  1 => \n  array (\n    \'posid\' => \'1\',\n    \'modelid\' => \'0\',\n    \'catid\' => \'0\',\n    \'name\' => \'首页焦点图推荐\',\n    \'maxnum\' => \'20\',\n    \'extention\' => NULL,\n    \'listorder\' => \'1\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n  13 => \n  array (\n    \'posid\' => \'13\',\n    \'modelid\' => \'82\',\n    \'catid\' => \'0\',\n    \'name\' => \'栏目页焦点图\',\n    \'maxnum\' => \'20\',\n    \'extention\' => NULL,\n    \'listorder\' => \'0\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n  5 => \n  array (\n    \'posid\' => \'5\',\n    \'modelid\' => \'69\',\n    \'catid\' => \'0\',\n    \'name\' => \'推荐下载\',\n    \'maxnum\' => \'20\',\n    \'extention\' => NULL,\n    \'listorder\' => \'0\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n  8 => \n  array (\n    \'posid\' => \'8\',\n    \'modelid\' => \'30\',\n    \'catid\' => \'54\',\n    \'name\' => \'图片频道首页焦点图\',\n    \'maxnum\' => \'20\',\n    \'extention\' => NULL,\n    \'listorder\' => \'0\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n  9 => \n  array (\n    \'posid\' => \'9\',\n    \'modelid\' => \'0\',\n    \'catid\' => \'0\',\n    \'name\' => \'网站顶部推荐\',\n    \'maxnum\' => \'20\',\n    \'extention\' => NULL,\n    \'listorder\' => \'0\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n  10 => \n  array (\n    \'posid\' => \'10\',\n    \'modelid\' => \'0\',\n    \'catid\' => \'0\',\n    \'name\' => \'栏目首页推荐\',\n    \'maxnum\' => \'20\',\n    \'extention\' => NULL,\n    \'listorder\' => \'0\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n  12 => \n  array (\n    \'posid\' => \'12\',\n    \'modelid\' => \'0\',\n    \'catid\' => \'0\',\n    \'name\' => \'首页图片推荐\',\n    \'maxnum\' => \'20\',\n    \'extention\' => NULL,\n    \'listorder\' => \'0\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n  14 => \n  array (\n    \'posid\' => \'14\',\n    \'modelid\' => \'0\',\n    \'catid\' => \'0\',\n    \'name\' => \'视频首页焦点图\',\n    \'maxnum\' => \'20\',\n    \'extention\' => \'\',\n    \'listorder\' => \'0\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n  15 => \n  array (\n    \'posid\' => \'15\',\n    \'modelid\' => \'0\',\n    \'catid\' => \'0\',\n    \'name\' => \'视频首页头条推荐\',\n    \'maxnum\' => \'20\',\n    \'extention\' => \'\',\n    \'listorder\' => \'0\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n  16 => \n  array (\n    \'posid\' => \'16\',\n    \'modelid\' => \'0\',\n    \'catid\' => \'0\',\n    \'name\' => \'视频首页每日热点\',\n    \'maxnum\' => \'20\',\n    \'extention\' => \'\',\n    \'listorder\' => \'0\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n  17 => \n  array (\n    \'posid\' => \'17\',\n    \'modelid\' => \'0\',\n    \'catid\' => \'0\',\n    \'name\' => \'视频栏目精彩推荐\',\n    \'maxnum\' => \'20\',\n    \'extention\' => \'\',\n    \'listorder\' => \'0\',\n    \'siteid\' => \'1\',\n    \'thumb\' => \'\',\n  ),\n);\n?>'),('role_siteid.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('role.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  1 => \'超级管理员\',\n  2 => \'站点管理员\',\n  3 => \'运营总监\',\n  4 => \'总编\',\n  5 => \'编辑\',\n  7 => \'发布人员\',\n);\n?>'),('urlrules_detail.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  1 => \n  array (\n    \'urlruleid\' => \'1\',\n    \'module\' => \'content\',\n    \'file\' => \'category\',\n    \'ishtml\' => \'1\',\n    \'urlrule\' => \'{$categorydir}{$catdir}/index.html|{$categorydir}{$catdir}/{$page}.html\',\n    \'example\' => \'news/china/1000.html\',\n  ),\n  6 => \n  array (\n    \'urlruleid\' => \'6\',\n    \'module\' => \'content\',\n    \'file\' => \'category\',\n    \'ishtml\' => \'0\',\n    \'urlrule\' => \'index.php?m=content&c=index&a=lists&catid={$catid}|index.php?m=content&c=index&a=lists&catid={$catid}&page={$page}\',\n    \'example\' => \'index.php?m=content&c=index&a=lists&catid=1&page=1\',\n  ),\n  11 => \n  array (\n    \'urlruleid\' => \'11\',\n    \'module\' => \'content\',\n    \'file\' => \'show\',\n    \'ishtml\' => \'1\',\n    \'urlrule\' => \'{$year}/{$catdir}_{$month}{$day}/{$id}.html|{$year}/{$catdir}_{$month}{$day}/{$id}_{$page}.html\',\n    \'example\' => \'2010/catdir_0720/1_2.html\',\n  ),\n  12 => \n  array (\n    \'urlruleid\' => \'12\',\n    \'module\' => \'content\',\n    \'file\' => \'show\',\n    \'ishtml\' => \'1\',\n    \'urlrule\' => \'{$categorydir}{$catdir}/{$year}/{$month}{$day}/{$id}.html|{$categorydir}{$catdir}/{$year}/{$month}{$day}/{$id}_{$page}.html\',\n    \'example\' => \'it/product/2010/0720/1_2.html\',\n  ),\n  16 => \n  array (\n    \'urlruleid\' => \'16\',\n    \'module\' => \'content\',\n    \'file\' => \'show\',\n    \'ishtml\' => \'0\',\n    \'urlrule\' => \'index.php?m=content&c=index&a=show&catid={$catid}&id={$id}|index.php?m=content&c=index&a=show&catid={$catid}&id={$id}&page={$page}\',\n    \'example\' => \'index.php?m=content&c=index&a=show&catid=1&id=1\',\n  ),\n  17 => \n  array (\n    \'urlruleid\' => \'17\',\n    \'module\' => \'content\',\n    \'file\' => \'show\',\n    \'ishtml\' => \'0\',\n    \'urlrule\' => \'show-{$catid}-{$id}-{$page}.html\',\n    \'example\' => \'show-1-2-1.html\',\n  ),\n  18 => \n  array (\n    \'urlruleid\' => \'18\',\n    \'module\' => \'content\',\n    \'file\' => \'show\',\n    \'ishtml\' => \'0\',\n    \'urlrule\' => \'content-{$catid}-{$id}-{$page}.html\',\n    \'example\' => \'content-1-2-1.html\',\n  ),\n  30 => \n  array (\n    \'urlruleid\' => \'30\',\n    \'module\' => \'content\',\n    \'file\' => \'category\',\n    \'ishtml\' => \'0\',\n    \'urlrule\' => \'list-{$catid}-{$page}.html\',\n    \'example\' => \'list-1-1.html\',\n  ),\n);\n?>'),('urlrules.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  1 => \'{$categorydir}{$catdir}/index.html|{$categorydir}{$catdir}/{$page}.html\',\n  6 => \'index.php?m=content&c=index&a=lists&catid={$catid}|index.php?m=content&c=index&a=lists&catid={$catid}&page={$page}\',\n  11 => \'{$year}/{$catdir}_{$month}{$day}/{$id}.html|{$year}/{$catdir}_{$month}{$day}/{$id}_{$page}.html\',\n  12 => \'{$categorydir}{$catdir}/{$year}/{$month}{$day}/{$id}.html|{$categorydir}{$catdir}/{$year}/{$month}{$day}/{$id}_{$page}.html\',\n  16 => \'index.php?m=content&c=index&a=show&catid={$catid}&id={$id}|index.php?m=content&c=index&a=show&catid={$catid}&id={$id}&page={$page}\',\n  17 => \'show-{$catid}-{$id}-{$page}.html\',\n  18 => \'content-{$catid}-{$id}-{$page}.html\',\n  30 => \'list-{$catid}-{$page}.html\',\n);\n?>'),('modules.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  \'admin\' => \n  array (\n    \'module\' => \'admin\',\n    \'name\' => \'admin\',\n    \'url\' => \'\',\n    \'iscore\' => \'1\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'array (\n  \\\'admin_email\\\' => \\\'phpcms@phpcms.cn\\\',\n  \\\'adminaccessip\\\' => \\\'0\\\',\n  \\\'maxloginfailedtimes\\\' => \\\'8\\\',\n  \\\'maxiplockedtime\\\' => \\\'15\\\',\n  \\\'minrefreshtime\\\' => \\\'2\\\',\n  \\\'mail_type\\\' => \\\'1\\\',\n  \\\'mail_server\\\' => \\\'smtp.qq.com\\\',\n  \\\'mail_port\\\' => \\\'25\\\',\n  \\\'mail_user\\\' => \\\'phpcms.cn@foxmail.com\\\',\n  \\\'mail_auth\\\' => \\\'1\\\',\n  \\\'mail_from\\\' => \\\'phpcms.cn@foxmail.com\\\',\n  \\\'mail_password\\\' => \\\'\\\',\n  \\\'errorlog_size\\\' => \\\'20\\\',\n)\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-10-18\',\n    \'updatedate\' => \'2010-10-18\',\n  ),\n  \'member\' => \n  array (\n    \'module\' => \'member\',\n    \'name\' => \'会员\',\n    \'url\' => \'\',\n    \'iscore\' => \'1\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'array (\n  \\\'allowregister\\\' => \\\'1\\\',\n  \\\'choosemodel\\\' => \\\'1\\\',\n  \\\'enablemailcheck\\\' => \\\'0\\\',\n  \\\'registerverify\\\' => \\\'0\\\',\n  \\\'showapppoint\\\' => \\\'0\\\',\n  \\\'rmb_point_rate\\\' => \\\'10\\\',\n  \\\'defualtpoint\\\' => \\\'0\\\',\n  \\\'defualtamount\\\' => \\\'0\\\',\n  \\\'showregprotocol\\\' => \\\'0\\\',\n  \\\'regprotocol\\\' => \\\'		 欢迎您注册成为phpcms用户\r\n请仔细阅读下面的协议，只有接受协议才能继续进行注册。 \r\n1．服务条款的确认和接纳\r\n　　phpcms用户服务的所有权和运作权归phpcms拥有。phpcms所提供的服务将按照有关章程、服务条款和操作规则严格执行。用户通过注册程序点击“我同意” 按钮，即表示用户与phpcms达成协议并接受所有的服务条款。\r\n2． phpcms服务简介\r\n　　phpcms通过国际互联网为用户提供新闻及文章浏览、图片浏览、软件下载、网上留言和BBS论坛等服务。\r\n　　用户必须： \r\n　　1)购置设备，包括个人电脑一台、调制解调器一个及配备上网装置。 \r\n　　2)个人上网和支付与此服务有关的电话费用、网络费用。\r\n　　用户同意： \r\n　　1)提供及时、详尽及准确的个人资料。 \r\n　　2)不断更新注册资料，符合及时、详尽、准确的要求。所有原始键入的资料将引用为注册资料。 \r\n　　3)用户同意遵守《中华人民共和国保守国家秘密法》、《中华人民共和国计算机信息系统安全保护条例》、《计算机软件保护条例》等有关计算机及互联网规定的法律和法规、实施办法。在任何情况下，phpcms合理地认为用户的行为可能违反上述法律、法规，phpcms可以在任何时候，不经事先通知终止向该用户提供服务。用户应了解国际互联网的无国界性，应特别注意遵守当地所有有关的法律和法规。\r\n3． 服务条款的修改\r\n　　phpcms会不定时地修改服务条款，服务条款一旦发生变动，将会在相关页面上提示修改内容。如果您同意改动，则再一次点击“我同意”按钮。 如果您不接受，则及时取消您的用户使用服务资格。\r\n4． 服务修订\r\n　　phpcms保留随时修改或中断服务而不需知照用户的权利。phpcms行使修改或中断服务的权利，不需对用户或第三方负责。\r\n5． 用户隐私制度\r\n　　尊重用户个人隐私是phpcms的 基本政策。phpcms不会公开、编辑或透露用户的注册信息，除非有法律许可要求，或phpcms在诚信的基础上认为透露这些信息在以下三种情况是必要的： \r\n　　1)遵守有关法律规定，遵从合法服务程序。 \r\n　　2)保持维护phpcms的商标所有权。 \r\n　　3)在紧急情况下竭力维护用户个人和社会大众的隐私安全。 \r\n　　4)符合其他相关的要求。 \r\n6．用户的帐号，密码和安全性\r\n　　一旦注册成功成为phpcms用户，您将得到一个密码和帐号。如果您不保管好自己的帐号和密码安全，将对因此产生的后果负全部责任。另外，每个用户都要对其帐户中的所有活动和事件负全责。您可随时根据指示改变您的密码，也可以结束旧的帐户重开一个新帐户。用户同意若发现任何非法使用用户帐号或安全漏洞的情况，立即通知phpcms。\r\n7． 免责条款\r\n　　用户明确同意网站服务的使用由用户个人承担风险。 　　 \r\n　　phpcms不作任何类型的担保，不担保服务一定能满足用户的要求，也不担保服务不会受中断，对服务的及时性，安全性，出错发生都不作担保。用户理解并接受：任何通过phpcms服务取得的信息资料的可靠性取决于用户自己，用户自己承担所有风险和责任。 \r\n8．有限责任\r\n　　phpcms对任何直接、间接、偶然、特殊及继起的损害不负责任。\r\n9． 不提供零售和商业性服务 \r\n　　用户使用网站服务的权利是个人的。用户只能是一个单独的个体而不能是一个公司或实体商业性组织。用户承诺不经phpcms同意，不能利用网站服务进行销售或其他商业用途。\r\n10．用户责任 \r\n　　用户单独承担传输内容的责任。用户必须遵循： \r\n　　1)从中国境内向外传输技术性资料时必须符合中国有关法规。 \r\n　　2)使用网站服务不作非法用途。 \r\n　　3)不干扰或混乱网络服务。 \r\n　　4)不在论坛BBS或留言簿发表任何与政治相关的信息。 \r\n　　5)遵守所有使用网站服务的网络协议、规定、程序和惯例。\r\n　　6)不得利用本站危害国家安全、泄露国家秘密，不得侵犯国家社会集体的和公民的合法权益。\r\n　　7)不得利用本站制作、复制和传播下列信息： \r\n　　　1、煽动抗拒、破坏宪法和法律、行政法规实施的；\r\n　　　2、煽动颠覆国家政权，推翻社会主义制度的；\r\n　　　3、煽动分裂国家、破坏国家统一的；\r\n　　　4、煽动民族仇恨、民族歧视，破坏民族团结的；\r\n　　　5、捏造或者歪曲事实，散布谣言，扰乱社会秩序的；\r\n　　　6、宣扬封建迷信、淫秽、色情、赌博、暴力、凶杀、恐怖、教唆犯罪的；\r\n　　　7、公然侮辱他人或者捏造事实诽谤他人的，或者进行其他恶意攻击的；\r\n　　　8、损害国家机关信誉的；\r\n　　　9、其他违反宪法和法律行政法规的；\r\n　　　10、进行商业广告行为的。\r\n　　用户不能传输任何教唆他人构成犯罪行为的资料；不能传输长国内不利条件和涉及国家安全的资料；不能传输任何不符合当地法规、国家法律和国际法 律的资料。未经许可而非法进入其它电脑系统是禁止的。若用户的行为不符合以上的条款，phpcms将取消用户服务帐号。\r\n11．网站内容的所有权\r\n　　phpcms定义的内容包括：文字、软件、声音、相片、录象、图表；在广告中全部内容；电子邮件的全部内容；phpcms为用户提供的商业信息。所有这些内容受版权、商标、标签和其它财产所有权法律的保护。所以，用户只能在phpcms和广告商授权下才能使用这些内容，而不能擅自复制、篡改这些内容、或创造与内容有关的派生产品。\r\n12．附加信息服务\r\n　　用户在享用phpcms提供的免费服务的同时，同意接受phpcms提供的各类附加信息服务。\r\n13．解释权\r\n　　本注册协议的解释权归phpcms所有。如果其中有任何条款与国家的有关法律相抵触，则以国家法律的明文规定为准。 \\\',\n  \\\'registerverifymessage\\\' => \\\' 欢迎您注册成为phpcms用户，您的账号需要邮箱认证，点击下面链接进行认证：{click}\r\n或者将网址复制到浏览器：{url}\\\',\n  \\\'forgetpassword\\\' => \\\' phpcms密码找回，请在一小时内点击下面链接进行操作：{click}\r\n或者将网址复制到浏览器：{url}\\\',\n)\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-06\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'pay\' => \n  array (\n    \'module\' => \'pay\',\n    \'name\' => \'支付\',\n    \'url\' => \'\',\n    \'iscore\' => \'1\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-06\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'digg\' => \n  array (\n    \'module\' => \'digg\',\n    \'name\' => \'顶一下\',\n    \'url\' => \'\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-06\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'special\' => \n  array (\n    \'module\' => \'special\',\n    \'name\' => \'专题\',\n    \'url\' => \'\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-06\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'content\' => \n  array (\n    \'module\' => \'content\',\n    \'name\' => \'内容模块\',\n    \'url\' => \'\',\n    \'iscore\' => \'1\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-06\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'search\' => \n  array (\n    \'module\' => \'search\',\n    \'name\' => \'全站搜索\',\n    \'url\' => \'\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'array (\n  \\\'fulltextenble\\\' => \\\'1\\\',\n  \\\'relationenble\\\' => \\\'1\\\',\n  \\\'suggestenable\\\' => \\\'1\\\',\n  \\\'sphinxenable\\\' => \\\'0\\\',\n  \\\'sphinxhost\\\' => \\\'10.228.134.102\\\',\n  \\\'sphinxport\\\' => \\\'9312\\\',\n)\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-06\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'scan\' => \n  array (\n    \'module\' => \'scan\',\n    \'name\' => \'木马扫描\',\n    \'url\' => \'scan\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-01\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'attachment\' => \n  array (\n    \'module\' => \'attachment\',\n    \'name\' => \'附件\',\n    \'url\' => \'attachment\',\n    \'iscore\' => \'1\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-01\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'block\' => \n  array (\n    \'module\' => \'block\',\n    \'name\' => \'碎片\',\n    \'url\' => \'\',\n    \'iscore\' => \'1\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-01\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'collection\' => \n  array (\n    \'module\' => \'collection\',\n    \'name\' => \'采集模块\',\n    \'url\' => \'collection\',\n    \'iscore\' => \'1\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-01\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'dbsource\' => \n  array (\n    \'module\' => \'dbsource\',\n    \'name\' => \'数据源\',\n    \'url\' => \'\',\n    \'iscore\' => \'1\',\n    \'version\' => \'\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-01\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'template\' => \n  array (\n    \'module\' => \'template\',\n    \'name\' => \'模板风格\',\n    \'url\' => \'\',\n    \'iscore\' => \'1\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-01\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'release\' => \n  array (\n    \'module\' => \'release\',\n    \'name\' => \'发布点\',\n    \'url\' => \'\',\n    \'iscore\' => \'1\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-01\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'video\' => \n  array (\n    \'module\' => \'video\',\n    \'name\' => \'视频库\',\n    \'url\' => \'\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2012-09-28\',\n    \'updatedate\' => \'2012-09-28\',\n  ),\n  \'announce\' => \n  array (\n    \'module\' => \'announce\',\n    \'name\' => \'公告\',\n    \'url\' => \'announce/\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'公告\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2017-04-19\',\n    \'updatedate\' => \'2017-04-19\',\n  ),\n  \'comment\' => \n  array (\n    \'module\' => \'comment\',\n    \'name\' => \'评论\',\n    \'url\' => \'comment/\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'评论\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2017-04-19\',\n    \'updatedate\' => \'2017-04-19\',\n  ),\n  \'link\' => \n  array (\n    \'module\' => \'link\',\n    \'name\' => \'友情链接\',\n    \'url\' => \'\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'array (\n  1 => \n  array (\n    \\\'is_post\\\' => \\\'1\\\',\n    \\\'enablecheckcode\\\' => \\\'0\\\',\n  ),\n)\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-06\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'vote\' => \n  array (\n    \'module\' => \'vote\',\n    \'name\' => \'投票\',\n    \'url\' => \'\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'array (\r\n  1 => \r\n  array (\r\n    \\\'default_style\\\' => \\\'default\\\',\r\n    \\\'vote_tp_template\\\' => \\\'vote_tp\\\',\r\n    \\\'allowguest\\\' => \\\'1\\\',\r\n    \\\'enabled\\\' => \\\'1\\\',\r\n    \\\'interval\\\' => \\\'1\\\',\r\n    \\\'credit\\\' => \\\'1\\\',\r\n  ),\r\n)\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-06\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'message\' => \n  array (\n    \'module\' => \'message\',\n    \'name\' => \'短消息\',\n    \'url\' => \'\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-09-06\',\n    \'updatedate\' => \'2010-09-06\',\n  ),\n  \'mood\' => \n  array (\n    \'module\' => \'mood\',\n    \'name\' => \'新闻心情\',\n    \'url\' => \'mood/\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'新闻心情\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2017-04-19\',\n    \'updatedate\' => \'2017-04-19\',\n  ),\n  \'poster\' => \n  array (\n    \'module\' => \'poster\',\n    \'name\' => \'广告模块\',\n    \'url\' => \'poster/\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'广告模块\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2017-04-19\',\n    \'updatedate\' => \'2017-04-19\',\n  ),\n  \'formguide\' => \n  array (\n    \'module\' => \'formguide\',\n    \'name\' => \'表单向导\',\n    \'url\' => \'formguide/\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'formguide\',\n    \'setting\' => \'array (\n  \\\'allowmultisubmit\\\' => \\\'1\\\',\n  \\\'interval\\\' => \\\'30\\\',\n  \\\'allowunreg\\\' => \\\'0\\\',\n  \\\'mailmessage\\\' => \\\'用户向我们提交了表单数据，赶快去看看吧。\\\',\n)\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2010-10-20\',\n    \'updatedate\' => \'2010-10-20\',\n  ),\n  \'wap\' => \n  array (\n    \'module\' => \'wap\',\n    \'name\' => \'手机门户\',\n    \'url\' => \'wap/\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'手机门户\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2017-04-19\',\n    \'updatedate\' => \'2017-04-19\',\n  ),\n  \'upgrade\' => \n  array (\n    \'module\' => \'upgrade\',\n    \'name\' => \'在线升级\',\n    \'url\' => \'\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2011-05-18\',\n    \'updatedate\' => \'2011-05-18\',\n  ),\n  \'tag\' => \n  array (\n    \'module\' => \'tag\',\n    \'name\' => \'标签向导\',\n    \'url\' => \'tag/\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'标签向导\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2017-04-19\',\n    \'updatedate\' => \'2017-04-19\',\n  ),\n  \'sms\' => \n  array (\n    \'module\' => \'sms\',\n    \'name\' => \'短信平台\',\n    \'url\' => \'sms/\',\n    \'iscore\' => \'0\',\n    \'version\' => \'1.0\',\n    \'description\' => \'短信平台\',\n    \'setting\' => \'\',\n    \'listorder\' => \'0\',\n    \'disabled\' => \'0\',\n    \'installdate\' => \'2011-09-02\',\n    \'updatedate\' => \'2011-09-02\',\n  ),\n);\n?>'),('model.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  1 => \n  array (\n    \'modelid\' => \'1\',\n    \'siteid\' => \'1\',\n    \'name\' => \'文章模型\',\n    \'description\' => \'\',\n    \'tablename\' => \'news\',\n    \'setting\' => \'\',\n    \'addtime\' => \'0\',\n    \'items\' => \'0\',\n    \'enablesearch\' => \'1\',\n    \'disabled\' => \'0\',\n    \'default_style\' => \'default\',\n    \'category_template\' => \'category\',\n    \'list_template\' => \'list\',\n    \'show_template\' => \'show\',\n    \'js_template\' => \'\',\n    \'admin_list_template\' => \'\',\n    \'member_add_template\' => \'\',\n    \'member_list_template\' => \'\',\n    \'sort\' => \'0\',\n    \'type\' => \'0\',\n  ),\n  2 => \n  array (\n    \'modelid\' => \'2\',\n    \'siteid\' => \'1\',\n    \'name\' => \'下载模型\',\n    \'description\' => \'\',\n    \'tablename\' => \'download\',\n    \'setting\' => \'\',\n    \'addtime\' => \'0\',\n    \'items\' => \'0\',\n    \'enablesearch\' => \'1\',\n    \'disabled\' => \'0\',\n    \'default_style\' => \'default\',\n    \'category_template\' => \'category_download\',\n    \'list_template\' => \'list_download\',\n    \'show_template\' => \'show_download\',\n    \'js_template\' => \'\',\n    \'admin_list_template\' => \'\',\n    \'member_add_template\' => \'\',\n    \'member_list_template\' => \'\',\n    \'sort\' => \'0\',\n    \'type\' => \'0\',\n  ),\n  3 => \n  array (\n    \'modelid\' => \'3\',\n    \'siteid\' => \'1\',\n    \'name\' => \'图片模型\',\n    \'description\' => \'\',\n    \'tablename\' => \'picture\',\n    \'setting\' => \'\',\n    \'addtime\' => \'0\',\n    \'items\' => \'0\',\n    \'enablesearch\' => \'1\',\n    \'disabled\' => \'0\',\n    \'default_style\' => \'default\',\n    \'category_template\' => \'category_picture\',\n    \'list_template\' => \'list_picture\',\n    \'show_template\' => \'show_picture\',\n    \'js_template\' => \'\',\n    \'admin_list_template\' => \'\',\n    \'member_add_template\' => \'\',\n    \'member_list_template\' => \'\',\n    \'sort\' => \'0\',\n    \'type\' => \'0\',\n  ),\n  11 => \n  array (\n    \'modelid\' => \'11\',\n    \'siteid\' => \'1\',\n    \'name\' => \'视频模型\',\n    \'description\' => \'\',\n    \'tablename\' => \'video\',\n    \'setting\' => \'\',\n    \'addtime\' => \'0\',\n    \'items\' => \'0\',\n    \'enablesearch\' => \'1\',\n    \'disabled\' => \'0\',\n    \'default_style\' => \'default\',\n    \'category_template\' => \'category_video\',\n    \'list_template\' => \'list_video\',\n    \'show_template\' => \'show_video\',\n    \'js_template\' => \'\',\n    \'admin_list_template\' => \'\',\n    \'member_add_template\' => \'\',\n    \'member_list_template\' => \'\',\n    \'sort\' => \'0\',\n    \'type\' => \'0\',\n  ),\n  12 => \n  array (\n    \'modelid\' => \'12\',\n    \'siteid\' => \'1\',\n    \'name\' => \'配置模型\',\n    \'description\' => \'\',\n    \'tablename\' => \'sys\',\n    \'setting\' => \'\',\n    \'addtime\' => \'0\',\n    \'items\' => \'0\',\n    \'enablesearch\' => \'1\',\n    \'disabled\' => \'0\',\n    \'default_style\' => \'\',\n    \'category_template\' => \'\',\n    \'list_template\' => \'\',\n    \'show_template\' => \'\',\n    \'js_template\' => \'\',\n    \'admin_list_template\' => \'\',\n    \'member_add_template\' => \'\',\n    \'member_list_template\' => \'\',\n    \'sort\' => \'0\',\n    \'type\' => \'0\',\n  ),\n);\n?>'),('workflow_1.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  1 => \n  array (\n    \'workflowid\' => \'1\',\n    \'siteid\' => \'1\',\n    \'steps\' => \'1\',\n    \'workname\' => \'一级审核\',\n    \'description\' => \'审核一次\',\n    \'setting\' => \'\',\n    \'flag\' => \'0\',\n  ),\n  2 => \n  array (\n    \'workflowid\' => \'2\',\n    \'siteid\' => \'1\',\n    \'steps\' => \'2\',\n    \'workname\' => \'二级审核\',\n    \'description\' => \'审核两次\',\n    \'setting\' => \'\',\n    \'flag\' => \'0\',\n  ),\n  3 => \n  array (\n    \'workflowid\' => \'3\',\n    \'siteid\' => \'1\',\n    \'steps\' => \'3\',\n    \'workname\' => \'三级审核\',\n    \'description\' => \'审核三次\',\n    \'setting\' => \'\',\n    \'flag\' => \'0\',\n  ),\n  4 => \n  array (\n    \'workflowid\' => \'4\',\n    \'siteid\' => \'1\',\n    \'steps\' => \'4\',\n    \'workname\' => \'四级审核\',\n    \'description\' => \'四级审核\',\n    \'setting\' => \'\',\n    \'flag\' => \'0\',\n  ),\n);\n?>'),('member_model.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  10 => \n  array (\n    \'modelid\' => \'10\',\n    \'siteid\' => \'1\',\n    \'name\' => \'普通会员\',\n    \'description\' => \'普通会员\',\n    \'tablename\' => \'member_detail\',\n    \'setting\' => \'\',\n    \'addtime\' => \'0\',\n    \'items\' => \'0\',\n    \'enablesearch\' => \'1\',\n    \'disabled\' => \'0\',\n    \'default_style\' => \'\',\n    \'category_template\' => \'\',\n    \'list_template\' => \'\',\n    \'show_template\' => \'\',\n    \'js_template\' => \'\',\n    \'admin_list_template\' => \'\',\n    \'member_add_template\' => \'\',\n    \'member_list_template\' => \'\',\n    \'sort\' => \'0\',\n    \'type\' => \'2\',\n  ),\n);\n?>'),('special.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('common.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  \'admin_email\' => \'phpcms@phpcms.cn\',\n  \'adminaccessip\' => \'0\',\n  \'maxloginfailedtimes\' => \'8\',\n  \'maxiplockedtime\' => \'15\',\n  \'minrefreshtime\' => \'2\',\n  \'mail_type\' => \'1\',\n  \'mail_server\' => \'smtp.qq.com\',\n  \'mail_port\' => \'25\',\n  \'mail_user\' => \'phpcms.cn@foxmail.com\',\n  \'mail_auth\' => \'1\',\n  \'mail_from\' => \'phpcms.cn@foxmail.com\',\n  \'mail_password\' => \'\',\n  \'errorlog_size\' => \'20\',\n);\n?>'),('category_items_1.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  28 => \'0\',\n  37 => \'12\',\n  36 => \'18\',\n  27 => \'12\',\n  25 => \'14\',\n  26 => \'0\',\n);\n?>'),('category_items_2.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('category_items_3.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('category_items_11.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('type_content.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('vote.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  1 => \n  array (\n    \'default_style\' => \'default\',\n    \'vote_tp_template\' => \'vote_tp\',\n    \'allowguest\' => \'1\',\n    \'enabled\' => \'1\',\n    \'interval\' => \'1\',\n    \'credit\' => \'1\',\n  ),\n);\n?>'),('link.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  1 => \n  array (\n    \'is_post\' => \'1\',\n    \'enablecheckcode\' => \'0\',\n  ),\n);\n?>'),('category_items_14.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('category_items_15.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('category_items_16.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('category_items_17.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('category_items_18.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('category_items_19.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('type_.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n);\n?>'),('category_items_12.cache.php','caches_commons/caches_data/','<?php\nreturn array (\n  38 => \'1\',\n);\n?>');
/*!40000 ALTER TABLE `v9_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_category`
--

DROP TABLE IF EXISTS `v9_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_category` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `module` varchar(15) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `arrparentid` varchar(255) NOT NULL,
  `child` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `arrchildid` mediumtext NOT NULL,
  `catname` varchar(30) NOT NULL,
  `style` varchar(5) NOT NULL,
  `image` varchar(100) NOT NULL,
  `description` mediumtext NOT NULL,
  `parentdir` varchar(100) NOT NULL,
  `catdir` varchar(30) NOT NULL,
  `url` varchar(100) NOT NULL,
  `items` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `setting` mediumtext NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `ismenu` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `sethtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `letter` varchar(30) NOT NULL,
  `usable_type` varchar(255) NOT NULL,
  PRIMARY KEY (`catid`),
  KEY `module` (`module`,`parentid`,`listorder`,`catid`),
  KEY `siteid` (`siteid`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_category`
--

LOCK TABLES `v9_category` WRITE;
/*!40000 ALTER TABLE `v9_category` DISABLE KEYS */;
INSERT INTO `v9_category` VALUES (28,1,'content',0,1,26,'0,26',0,'28','行业动态','','','','news/','trade','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=28',0,0,'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"list_news\",\"show_template\":\"show_news\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}',28,1,0,'xingyedongtai',''),(29,1,'content',1,0,0,'0',1,'29,32,36,37','党建学习','','','','','study','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=29',0,0,'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}',29,1,0,'dangjianxuexi',''),(37,1,'content',0,1,29,'0,29',0,'37','支部活动','','','','study/','activity','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=37',12,0,'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"list_party\",\"show_template\":\"show_news\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}',37,1,0,'zhibuhuodong',''),(32,1,'content',1,0,29,'0,29',0,'32','支部概括','','','','study/','survey','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=32',0,0,'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_survey\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}',32,1,0,'zhibugaikuo',''),(36,1,'content',0,1,29,'0,29',0,'36','支部荣誉','','','','study/','honors','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=36',18,0,'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"list_party\",\"show_template\":\"show_news\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}',36,1,0,'zhiburongyu',''),(33,1,'content',1,0,0,'0',1,'33,34,35','联系我们','','','','','contact','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=33',0,0,'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}',33,1,0,'lianxiwomen',''),(34,1,'content',1,0,33,'0,33',0,'34','联系方式','','','','contact/','way','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=34',0,0,'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_contact\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}',34,1,0,'lianxifangshi',''),(35,1,'content',1,0,33,'0,33',0,'35','招聘信息','','','','contact/','recruit','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=35',0,0,'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_recruit\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}',35,1,0,'zhaopinxinxi',''),(27,1,'content',0,1,26,'0,26',0,'27','公司新闻','','','','news/','company','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=27',12,0,'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"list_news\",\"show_template\":\"show_news\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}',27,1,0,'gongsixinwen',''),(25,1,'content',0,1,21,'0,21',0,'25','资质荣誉','','','','about/','honor','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=25',14,0,'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"list_honor\",\"show_template\":\"show_news\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}',25,1,0,'zizhirongyu',''),(24,1,'content',1,0,21,'0,21',0,'24','价值理念','','','','about/','value','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=24',0,0,'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_value\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}',24,1,0,'jiazhilinian',''),(26,1,'content',0,1,0,'0',1,'26,27,28','资讯','','','','','news','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=26',0,0,'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"category_jump\",\"list_template\":\"\",\"show_template\":\"\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}',26,1,0,'zixun',''),(23,1,'content',1,0,21,'0,21',0,'23','业务范围','','','','about/','business','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=23',0,0,'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_business\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}',23,1,0,'yewufanwei',''),(21,1,'content',1,0,0,'0',1,'21,22,23,24,25','关于我们','','','','','about','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=21',0,0,'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_jump\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}',21,1,0,'guanyuwomen',''),(22,1,'content',1,0,21,'0,21',0,'22','公司简介','','','','about/','introduce','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=22',0,0,'{\"ishtml\":\"0\",\"template_list\":\"zhucheng\",\"page_template\":\"page_about\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"category_ruleid\":\"6\",\"show_ruleid\":\"\",\"repeatchargedays\":\"1\"}',22,1,0,'gongsijianjie',''),(38,1,'content',0,12,0,'0',0,'38','系统配置','','','','','sys','http://zhucheng.gitlay.com/index.php?m=content&c=index&a=lists&catid=38',1,0,'{\"workflowid\":\"\",\"ishtml\":\"0\",\"content_ishtml\":\"0\",\"create_to_html_root\":\"0\",\"template_list\":\"zhucheng\",\"category_template\":\"\",\"list_template\":\"\",\"show_template\":\"\",\"meta_title\":\"\",\"meta_keywords\":\"\",\"meta_description\":\"\",\"presentpoint\":\"1\",\"defaultchargepoint\":\"0\",\"paytype\":\"0\",\"repeatchargedays\":\"1\",\"category_ruleid\":\"6\",\"show_ruleid\":\"16\"}',38,0,0,'xitongpeizhi','');
/*!40000 ALTER TABLE `v9_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_category_priv`
--

DROP TABLE IF EXISTS `v9_category_priv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_category_priv` (
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `roleid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `is_admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `action` char(30) NOT NULL,
  KEY `catid` (`catid`,`roleid`,`is_admin`,`action`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_category_priv`
--

LOCK TABLES `v9_category_priv` WRITE;
/*!40000 ALTER TABLE `v9_category_priv` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_category_priv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_collection_content`
--

DROP TABLE IF EXISTS `v9_collection_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_collection_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nodeid` int(10) unsigned NOT NULL DEFAULT '0',
  `siteid` mediumint(5) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` char(255) NOT NULL,
  `title` char(100) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `nodeid` (`nodeid`,`siteid`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_collection_content`
--

LOCK TABLES `v9_collection_content` WRITE;
/*!40000 ALTER TABLE `v9_collection_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_collection_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_collection_history`
--

DROP TABLE IF EXISTS `v9_collection_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_collection_history` (
  `md5` char(32) NOT NULL,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`md5`,`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_collection_history`
--

LOCK TABLES `v9_collection_history` WRITE;
/*!40000 ALTER TABLE `v9_collection_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_collection_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_collection_node`
--

DROP TABLE IF EXISTS `v9_collection_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_collection_node` (
  `nodeid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sourcecharset` varchar(8) NOT NULL,
  `sourcetype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `urlpage` text NOT NULL,
  `pagesize_start` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pagesize_end` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `page_base` char(255) NOT NULL,
  `par_num` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `url_contain` char(100) NOT NULL,
  `url_except` char(100) NOT NULL,
  `url_start` char(100) NOT NULL DEFAULT '',
  `url_end` char(100) NOT NULL DEFAULT '',
  `title_rule` char(100) NOT NULL,
  `title_html_rule` text NOT NULL,
  `author_rule` char(100) NOT NULL,
  `author_html_rule` text NOT NULL,
  `comeform_rule` char(100) NOT NULL,
  `comeform_html_rule` text NOT NULL,
  `time_rule` char(100) NOT NULL,
  `time_html_rule` text NOT NULL,
  `content_rule` char(100) NOT NULL,
  `content_html_rule` text NOT NULL,
  `content_page_start` char(100) NOT NULL,
  `content_page_end` char(100) NOT NULL,
  `content_page_rule` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content_page` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `content_nextpage` char(100) NOT NULL,
  `down_attachment` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `watermark` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `coll_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `customize_config` text NOT NULL,
  PRIMARY KEY (`nodeid`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_collection_node`
--

LOCK TABLES `v9_collection_node` WRITE;
/*!40000 ALTER TABLE `v9_collection_node` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_collection_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_collection_program`
--

DROP TABLE IF EXISTS `v9_collection_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_collection_program` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `nodeid` int(10) unsigned NOT NULL DEFAULT '0',
  `modelid` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `config` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `siteid` (`siteid`),
  KEY `nodeid` (`nodeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_collection_program`
--

LOCK TABLES `v9_collection_program` WRITE;
/*!40000 ALTER TABLE `v9_collection_program` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_collection_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_comment`
--

DROP TABLE IF EXISTS `v9_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_comment` (
  `commentid` char(30) NOT NULL,
  `siteid` smallint(5) NOT NULL DEFAULT '0',
  `title` char(255) NOT NULL,
  `url` char(255) NOT NULL,
  `total` int(8) unsigned DEFAULT '0',
  `square` mediumint(8) unsigned DEFAULT '0',
  `anti` mediumint(8) unsigned DEFAULT '0',
  `neutral` mediumint(8) unsigned DEFAULT '0',
  `display_type` tinyint(1) DEFAULT '0',
  `tableid` mediumint(8) unsigned DEFAULT '0',
  `lastupdate` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`commentid`),
  KEY `lastupdate` (`lastupdate`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_comment`
--

LOCK TABLES `v9_comment` WRITE;
/*!40000 ALTER TABLE `v9_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_comment_check`
--

DROP TABLE IF EXISTS `v9_comment_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_comment_check` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `comment_data_id` int(10) DEFAULT '0' COMMENT '论评ID号',
  `siteid` smallint(5) NOT NULL DEFAULT '0' COMMENT '站点ID',
  `tableid` mediumint(8) DEFAULT '0' COMMENT '数据存储表ID',
  PRIMARY KEY (`id`),
  KEY `siteid` (`siteid`),
  KEY `comment_data_id` (`comment_data_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_comment_check`
--

LOCK TABLES `v9_comment_check` WRITE;
/*!40000 ALTER TABLE `v9_comment_check` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_comment_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_comment_data_1`
--

DROP TABLE IF EXISTS `v9_comment_data_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_comment_data_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `commentid` char(30) NOT NULL DEFAULT '' COMMENT '评论ID号',
  `siteid` smallint(5) NOT NULL DEFAULT '0' COMMENT '站点ID',
  `userid` int(10) unsigned DEFAULT '0' COMMENT '用户ID',
  `username` varchar(20) DEFAULT NULL COMMENT '用户名',
  `creat_at` int(10) DEFAULT NULL COMMENT '发布时间',
  `ip` varchar(15) DEFAULT NULL COMMENT '用户IP地址',
  `status` tinyint(1) DEFAULT '0' COMMENT '评论状态{0:未审核,-1:未通过审核,1:通过审核}',
  `content` text COMMENT '评论内容',
  `direction` tinyint(1) DEFAULT '0' COMMENT '评论方向{0:无方向,1:正文,2:反方,3:中立}',
  `support` mediumint(8) unsigned DEFAULT '0' COMMENT '支持数',
  `reply` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为回复',
  PRIMARY KEY (`id`),
  KEY `commentid` (`commentid`),
  KEY `direction` (`direction`),
  KEY `siteid` (`siteid`),
  KEY `support` (`support`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_comment_data_1`
--

LOCK TABLES `v9_comment_data_1` WRITE;
/*!40000 ALTER TABLE `v9_comment_data_1` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_comment_data_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_comment_setting`
--

DROP TABLE IF EXISTS `v9_comment_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_comment_setting` (
  `siteid` smallint(5) NOT NULL DEFAULT '0' COMMENT '站点ID',
  `guest` tinyint(1) DEFAULT '0' COMMENT '是否允许游客评论',
  `check` tinyint(1) DEFAULT '0' COMMENT '是否需要审核',
  `code` tinyint(1) DEFAULT '0' COMMENT '是否开启验证码',
  `add_point` tinyint(3) unsigned DEFAULT '0' COMMENT '添加的积分数',
  `del_point` tinyint(3) unsigned DEFAULT '0' COMMENT '扣除的积分数',
  PRIMARY KEY (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_comment_setting`
--

LOCK TABLES `v9_comment_setting` WRITE;
/*!40000 ALTER TABLE `v9_comment_setting` DISABLE KEYS */;
INSERT INTO `v9_comment_setting` VALUES (1,0,0,0,0,0);
/*!40000 ALTER TABLE `v9_comment_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_comment_table`
--

DROP TABLE IF EXISTS `v9_comment_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_comment_table` (
  `tableid` mediumint(8) NOT NULL AUTO_INCREMENT COMMENT '表ID号',
  `total` int(10) unsigned DEFAULT '0' COMMENT '数据总量',
  `creat_at` int(10) DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`tableid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_comment_table`
--

LOCK TABLES `v9_comment_table` WRITE;
/*!40000 ALTER TABLE `v9_comment_table` DISABLE KEYS */;
INSERT INTO `v9_comment_table` VALUES (1,0,0);
/*!40000 ALTER TABLE `v9_comment_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_content_check`
--

DROP TABLE IF EXISTS `v9_content_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_content_check` (
  `checkid` char(15) NOT NULL,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` char(80) NOT NULL,
  `username` char(20) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `username` (`username`),
  KEY `checkid` (`checkid`),
  KEY `status` (`status`,`inputtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_content_check`
--

LOCK TABLES `v9_content_check` WRITE;
/*!40000 ALTER TABLE `v9_content_check` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_content_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_copyfrom`
--

DROP TABLE IF EXISTS `v9_copyfrom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_copyfrom` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sitename` varchar(30) NOT NULL,
  `siteurl` varchar(100) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_copyfrom`
--

LOCK TABLES `v9_copyfrom` WRITE;
/*!40000 ALTER TABLE `v9_copyfrom` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_copyfrom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_datacall`
--

DROP TABLE IF EXISTS `v9_datacall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_datacall` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` char(40) DEFAULT NULL,
  `dis_type` tinyint(1) unsigned DEFAULT '0',
  `type` tinyint(1) DEFAULT '0',
  `module` char(20) DEFAULT NULL,
  `action` char(20) DEFAULT NULL,
  `data` text,
  `template` text,
  `cache` mediumint(8) DEFAULT NULL,
  `num` smallint(6) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_datacall`
--

LOCK TABLES `v9_datacall` WRITE;
/*!40000 ALTER TABLE `v9_datacall` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_datacall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_dbsource`
--

DROP TABLE IF EXISTS `v9_dbsource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_dbsource` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL,
  `host` varchar(20) NOT NULL,
  `port` int(5) NOT NULL DEFAULT '3306',
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `dbname` varchar(50) NOT NULL,
  `dbtablepre` varchar(30) NOT NULL,
  `charset` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_dbsource`
--

LOCK TABLES `v9_dbsource` WRITE;
/*!40000 ALTER TABLE `v9_dbsource` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_dbsource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_download`
--

DROP TABLE IF EXISTS `v9_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_download` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(5) unsigned NOT NULL,
  `title` char(80) NOT NULL DEFAULT '',
  `style` char(24) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `keywords` char(40) NOT NULL DEFAULT '',
  `description` char(255) NOT NULL DEFAULT '',
  `posids` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` char(100) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `sysadd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `systems` varchar(100) NOT NULL DEFAULT 'Win2000/WinXP/Win2003',
  `copytype` varchar(15) NOT NULL DEFAULT '',
  `language` varchar(10) NOT NULL DEFAULT '',
  `classtype` varchar(20) NOT NULL DEFAULT '',
  `version` varchar(20) NOT NULL DEFAULT '',
  `filesize` varchar(10) NOT NULL DEFAULT 'Unkown',
  `stars` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`,`id`),
  KEY `listorder` (`catid`,`status`,`listorder`,`id`),
  KEY `catid` (`catid`,`status`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_download`
--

LOCK TABLES `v9_download` WRITE;
/*!40000 ALTER TABLE `v9_download` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_download` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_download_data`
--

DROP TABLE IF EXISTS `v9_download_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_download_data` (
  `id` mediumint(8) unsigned DEFAULT '0',
  `content` text NOT NULL,
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0',
  `groupids_view` varchar(100) NOT NULL,
  `paginationtype` tinyint(1) NOT NULL,
  `maxcharperpage` mediumint(6) NOT NULL,
  `template` varchar(30) NOT NULL,
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `relation` varchar(255) NOT NULL DEFAULT '',
  `allow_comment` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `downfiles` mediumtext NOT NULL,
  `downfile` varchar(255) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_download_data`
--

LOCK TABLES `v9_download_data` WRITE;
/*!40000 ALTER TABLE `v9_download_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_download_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_downservers`
--

DROP TABLE IF EXISTS `v9_downservers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_downservers` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `sitename` varchar(100) DEFAULT NULL,
  `siteurl` varchar(255) DEFAULT NULL,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_downservers`
--

LOCK TABLES `v9_downservers` WRITE;
/*!40000 ALTER TABLE `v9_downservers` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_downservers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_extend_setting`
--

DROP TABLE IF EXISTS `v9_extend_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_extend_setting` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `key` char(30) NOT NULL,
  `data` mediumtext,
  PRIMARY KEY (`id`),
  KEY `key` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_extend_setting`
--

LOCK TABLES `v9_extend_setting` WRITE;
/*!40000 ALTER TABLE `v9_extend_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_extend_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_favorite`
--

DROP TABLE IF EXISTS `v9_favorite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_favorite` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` char(100) NOT NULL,
  `url` char(100) NOT NULL,
  `adddate` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_favorite`
--

LOCK TABLES `v9_favorite` WRITE;
/*!40000 ALTER TABLE `v9_favorite` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_favorite` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_hits`
--

DROP TABLE IF EXISTS `v9_hits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_hits` (
  `hitsid` char(30) NOT NULL,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `yesterdayviews` int(10) unsigned NOT NULL DEFAULT '0',
  `dayviews` int(10) unsigned NOT NULL DEFAULT '0',
  `weekviews` int(10) unsigned NOT NULL DEFAULT '0',
  `monthviews` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`hitsid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_hits`
--

LOCK TABLES `v9_hits` WRITE;
/*!40000 ALTER TABLE `v9_hits` DISABLE KEYS */;
INSERT INTO `v9_hits` VALUES ('c-1-1',12,0,0,0,0,0,1545217517),('c-1-2',12,0,0,0,0,0,1545217517),('c-1-3',12,0,0,0,0,0,1545217518),('c-1-4',12,0,0,0,0,0,1545217518),('c-1-5',12,0,0,0,0,0,1545217518),('c-1-6',12,0,0,0,0,0,1545217519),('c-1-7',12,0,0,0,0,0,1545217519),('c-1-8',12,0,0,0,0,0,1545217519),('c-1-10',12,0,0,0,0,0,1545217520),('c-1-11',12,0,0,0,0,0,1545217520),('c-1-9',12,0,0,0,0,0,1545217519),('c-1-12',12,0,0,0,0,0,1545217520),('c-1-13',12,0,0,0,0,0,1545217520),('c-1-14',12,0,0,0,0,0,1545217520),('c-1-15',12,0,0,0,0,0,1545217520),('c-1-16',12,0,0,0,0,0,1545217520),('c-1-17',12,0,0,0,0,0,1545217521),('c-1-18',12,0,0,0,0,0,1545217521),('c-1-19',12,0,0,0,0,0,1545217521),('c-1-20',12,0,0,0,0,0,1545217521),('c-1-21',13,0,0,0,0,0,1545217824),('c-1-22',13,0,0,0,0,0,1545217825),('c-1-23',13,0,0,0,0,0,1545217825),('c-1-24',13,0,0,0,0,0,1545217825),('c-1-25',13,0,0,0,0,0,1545217826),('c-1-26',13,0,0,0,0,0,1545217826),('c-1-27',13,0,0,0,0,0,1545217826),('c-1-28',13,0,0,0,0,0,1545217826),('c-1-29',13,0,0,0,0,0,1545217826),('c-1-30',13,0,0,0,0,0,1545217826),('c-1-31',13,0,0,0,0,0,1545217827),('c-1-32',13,0,0,0,0,0,1545217827),('c-1-33',13,0,0,0,0,0,1545217827),('c-1-34',13,0,0,0,0,0,1545217827),('c-1-35',13,0,0,0,0,0,1545217827),('c-1-36',13,0,0,0,0,0,1545217827),('c-1-37',13,0,0,0,0,0,1545217828),('c-1-38',18,0,0,0,0,0,1545218200),('c-1-39',18,0,0,0,0,0,1545218201),('c-1-40',18,0,0,0,0,0,1545218201),('c-1-41',18,0,0,0,0,0,1545218202),('c-1-42',9,0,0,0,0,0,1545220511),('c-1-43',9,0,0,0,0,0,1545220512),('c-1-44',9,0,0,0,0,0,1545220512),('c-1-45',9,0,0,0,0,0,1545220512),('c-1-46',9,0,0,0,0,0,1545220513),('c-1-47',9,0,0,0,0,0,1545220513),('c-1-48',9,0,0,0,0,0,1545220513),('c-1-49',9,0,0,0,0,0,1545220513),('c-1-50',9,0,0,0,0,0,1545220513),('c-1-51',9,0,0,0,0,0,1545220513),('c-1-52',9,0,0,0,0,0,1545220514),('c-1-53',9,0,0,0,0,0,1545220514),('c-1-54',9,0,0,0,0,0,1545220514),('c-1-55',9,0,0,0,0,0,1545220515),('c-1-56',15,0,0,0,0,0,1545220614),('c-1-57',15,0,0,0,0,0,1545220614),('c-1-58',15,0,0,0,0,0,1545220614),('c-1-59',15,0,0,0,0,0,1545220614),('c-1-60',15,0,0,0,0,0,1545220614),('c-1-61',15,0,0,0,0,0,1545220615),('c-1-62',15,0,0,0,0,0,1545220615),('c-1-63',15,0,0,0,0,0,1545220615),('c-1-64',15,0,0,0,0,0,1545220615),('c-1-65',15,0,0,0,0,0,1545220615),('c-1-66',15,0,0,0,0,0,1545220616),('c-1-67',15,0,0,0,0,0,1545220616),('c-1-68',15,0,0,0,0,0,1545220616),('c-1-69',15,0,0,0,0,0,1545220616),('c-1-70',15,0,0,0,0,0,1545220616),('c-1-71',36,0,0,0,0,0,1545285650),('c-1-72',36,0,0,0,0,0,1545285650),('c-1-73',36,0,0,0,0,0,1545285650),('c-1-74',36,0,0,0,0,0,1545285650),('c-1-75',36,0,0,0,0,0,1545285651),('c-1-76',36,0,0,0,0,0,1545285651),('c-1-77',36,0,0,0,0,0,1545285651),('c-1-78',36,0,0,0,0,0,1545285651),('c-1-79',36,0,0,0,0,0,1545285652),('c-1-80',36,0,0,0,0,0,1545285652),('c-1-81',36,0,0,0,0,0,1545285652),('c-1-82',36,0,0,0,0,0,1545285652),('c-1-83',36,0,0,0,0,0,1545285652),('c-1-84',36,0,0,0,0,0,1545285652),('c-1-86',36,0,0,0,0,0,1545285653),('c-1-85',36,0,0,0,0,0,1545285652),('c-1-87',36,3,0,3,3,3,1545295060),('c-1-88',36,0,0,0,0,0,1545285653),('c-1-89',27,0,0,0,0,0,1545285873),('c-1-90',27,0,0,0,0,0,1545285873),('c-1-91',27,0,0,0,0,0,1545285873),('c-1-92',27,0,0,0,0,0,1545285873),('c-1-93',27,0,0,0,0,0,1545285874),('c-1-94',27,0,0,0,0,0,1545285874),('c-1-95',27,1,0,1,1,1,1545294876),('c-1-96',27,0,0,0,0,0,1545285874),('c-1-97',27,0,0,0,0,0,1545285874),('c-1-98',27,0,0,0,0,0,1545285874),('c-1-99',27,0,0,0,0,0,1545285874),('c-1-100',27,0,0,0,0,0,1545285875),('c-1-101',25,0,0,0,0,0,1545294511),('c-1-103',25,0,0,0,0,0,1545294511),('c-1-102',25,0,0,0,0,0,1545294511),('c-1-104',25,0,0,0,0,0,1545294511),('c-1-105',25,0,0,0,0,0,1545294511),('c-1-106',25,0,0,0,0,0,1545294512),('c-1-107',25,0,0,0,0,0,1545294512),('c-1-108',25,0,0,0,0,0,1545294512),('c-1-109',25,0,0,0,0,0,1545294512),('c-1-110',25,0,0,0,0,0,1545294512),('c-1-111',25,0,0,0,0,0,1545294512),('c-1-112',25,0,0,0,0,0,1545294513),('c-1-113',25,0,0,0,0,0,1545294513),('c-1-114',25,0,0,0,0,0,1545294512),('c-1-115',37,0,0,0,0,0,1545295464),('c-1-116',37,0,0,0,0,0,1545295464),('c-1-117',37,0,0,0,0,0,1545295465),('c-1-118',37,0,0,0,0,0,1545295465),('c-1-119',37,0,0,0,0,0,1545295465),('c-1-120',37,0,0,0,0,0,1545295465),('c-1-121',37,0,0,0,0,0,1545295465),('c-1-122',37,0,0,0,0,0,1545295465),('c-1-123',37,0,0,0,0,0,1545295465),('c-1-124',37,0,0,0,0,0,1545295466),('c-1-125',37,0,0,0,0,0,1545295466),('c-1-126',37,0,0,0,0,0,1545295466),('c-12-1',38,0,0,0,0,0,1545296059);
/*!40000 ALTER TABLE `v9_hits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_ipbanned`
--

DROP TABLE IF EXISTS `v9_ipbanned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_ipbanned` (
  `ipbannedid` smallint(5) NOT NULL AUTO_INCREMENT,
  `ip` char(15) NOT NULL,
  `expires` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ipbannedid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_ipbanned`
--

LOCK TABLES `v9_ipbanned` WRITE;
/*!40000 ALTER TABLE `v9_ipbanned` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_ipbanned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_keylink`
--

DROP TABLE IF EXISTS `v9_keylink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_keylink` (
  `keylinkid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `word` char(40) NOT NULL,
  `url` char(100) NOT NULL,
  PRIMARY KEY (`keylinkid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_keylink`
--

LOCK TABLES `v9_keylink` WRITE;
/*!40000 ALTER TABLE `v9_keylink` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_keylink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_keyword`
--

DROP TABLE IF EXISTS `v9_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_keyword` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `keyword` char(100) NOT NULL,
  `pinyin` char(100) NOT NULL,
  `videonum` int(11) NOT NULL DEFAULT '0',
  `searchnums` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `keyword` (`keyword`,`siteid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_keyword`
--

LOCK TABLES `v9_keyword` WRITE;
/*!40000 ALTER TABLE `v9_keyword` DISABLE KEYS */;
INSERT INTO `v9_keyword` VALUES (1,1,'','',125,0),(2,1,'','',1,0);
/*!40000 ALTER TABLE `v9_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_keyword_data`
--

DROP TABLE IF EXISTS `v9_keyword_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_keyword_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tagid` int(10) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `contentid` char(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tagid` (`tagid`,`siteid`)
) ENGINE=MyISAM AUTO_INCREMENT=127 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_keyword_data`
--

LOCK TABLES `v9_keyword_data` WRITE;
/*!40000 ALTER TABLE `v9_keyword_data` DISABLE KEYS */;
INSERT INTO `v9_keyword_data` VALUES (1,1,1,'1-1'),(2,2,1,'2-1'),(3,1,1,'3-1'),(4,1,1,'4-1'),(5,1,1,'5-1'),(6,1,1,'6-1'),(7,1,1,'7-1'),(8,1,1,'8-1'),(9,1,1,'10-1'),(10,1,1,'11-1'),(11,1,1,'9-1'),(12,1,1,'12-1'),(13,1,1,'13-1'),(14,1,1,'15-1'),(15,1,1,'14-1'),(16,1,1,'16-1'),(17,1,1,'17-1'),(18,1,1,'18-1'),(19,1,1,'19-1'),(20,1,1,'20-1'),(21,1,1,'21-1'),(22,1,1,'22-1'),(23,1,1,'23-1'),(24,1,1,'24-1'),(25,1,1,'25-1'),(26,1,1,'26-1'),(27,1,1,'27-1'),(28,1,1,'28-1'),(29,1,1,'29-1'),(30,1,1,'30-1'),(31,1,1,'31-1'),(32,1,1,'32-1'),(33,1,1,'33-1'),(34,1,1,'34-1'),(35,1,1,'35-1'),(36,1,1,'36-1'),(37,1,1,'37-1'),(38,1,1,'38-1'),(39,1,1,'39-1'),(40,1,1,'41-1'),(41,1,1,'40-1'),(42,1,1,'42-1'),(43,1,1,'43-1'),(44,1,1,'44-1'),(45,1,1,'45-1'),(46,1,1,'46-1'),(47,1,1,'47-1'),(48,1,1,'48-1'),(49,1,1,'49-1'),(50,1,1,'50-1'),(51,1,1,'51-1'),(52,1,1,'52-1'),(53,1,1,'53-1'),(54,1,1,'54-1'),(55,1,1,'55-1'),(56,1,1,'56-1'),(57,1,1,'57-1'),(58,1,1,'58-1'),(59,1,1,'59-1'),(60,1,1,'60-1'),(61,1,1,'61-1'),(62,1,1,'62-1'),(63,1,1,'63-1'),(64,1,1,'64-1'),(65,1,1,'65-1'),(66,1,1,'66-1'),(67,1,1,'67-1'),(68,1,1,'68-1'),(69,1,1,'69-1'),(70,1,1,'70-1'),(71,1,1,'71-1'),(72,1,1,'72-1'),(73,1,1,'73-1'),(74,1,1,'74-1'),(75,1,1,'75-1'),(76,1,1,'76-1'),(77,1,1,'77-1'),(78,1,1,'78-1'),(79,1,1,'79-1'),(80,1,1,'80-1'),(81,1,1,'81-1'),(82,1,1,'82-1'),(83,1,1,'83-1'),(84,1,1,'84-1'),(85,1,1,'86-1'),(86,1,1,'85-1'),(87,1,1,'87-1'),(88,1,1,'88-1'),(89,1,1,'89-1'),(90,1,1,'90-1'),(91,1,1,'91-1'),(92,1,1,'92-1'),(93,1,1,'93-1'),(94,1,1,'94-1'),(95,1,1,'95-1'),(96,1,1,'96-1'),(97,1,1,'97-1'),(98,1,1,'98-1'),(99,1,1,'99-1'),(100,1,1,'100-1'),(101,1,1,'101-1'),(102,1,1,'103-1'),(103,1,1,'102-1'),(104,1,1,'104-1'),(105,1,1,'105-1'),(106,1,1,'106-1'),(107,1,1,'107-1'),(108,1,1,'108-1'),(109,1,1,'109-1'),(110,1,1,'110-1'),(111,1,1,'111-1'),(112,1,1,'112-1'),(113,1,1,'113-1'),(114,1,1,'114-1'),(115,1,1,'115-1'),(116,1,1,'116-1'),(117,1,1,'117-1'),(118,1,1,'118-1'),(119,1,1,'119-1'),(120,1,1,'120-1'),(121,1,1,'121-1'),(122,1,1,'122-1'),(123,1,1,'123-1'),(124,1,1,'124-1'),(125,1,1,'125-1'),(126,1,1,'126-1');
/*!40000 ALTER TABLE `v9_keyword_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_link`
--

DROP TABLE IF EXISTS `v9_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_link` (
  `linkid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned DEFAULT '0',
  `typeid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `linktype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `logo` varchar(255) NOT NULL DEFAULT '',
  `introduce` text NOT NULL,
  `username` varchar(30) NOT NULL DEFAULT '',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `elite` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `passed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`linkid`),
  KEY `typeid` (`typeid`,`passed`,`listorder`,`linkid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_link`
--

LOCK TABLES `v9_link` WRITE;
/*!40000 ALTER TABLE `v9_link` DISABLE KEYS */;
INSERT INTO `v9_link` VALUES (3,1,0,0,'筑城资本','http://baidu.com','','','',0,0,1,1545296939),(4,1,0,0,'增益通科技','http://baidu.com','','','',0,0,1,1545296954),(5,1,0,0,'筑城融创','http://baidu.com','','','',0,0,1,1545296967),(6,1,0,0,'河北铭融','http://baidu.com','','','',0,0,1,1545297027);
/*!40000 ALTER TABLE `v9_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_linkage`
--

DROP TABLE IF EXISTS `v9_linkage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_linkage` (
  `linkageid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `style` varchar(35) NOT NULL,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `child` tinyint(1) NOT NULL,
  `arrchildid` mediumtext NOT NULL,
  `keyid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  `setting` varchar(255) DEFAULT NULL,
  `siteid` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`linkageid`,`keyid`),
  KEY `parentid` (`parentid`,`listorder`)
) ENGINE=MyISAM AUTO_INCREMENT=3360 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_linkage`
--

LOCK TABLES `v9_linkage` WRITE;
/*!40000 ALTER TABLE `v9_linkage` DISABLE KEYS */;
INSERT INTO `v9_linkage` VALUES (1,'中国','1',0,0,'',0,0,'',NULL,0),(2,'北京市','0',0,0,'',1,0,'',NULL,0),(3,'上海市','0',0,0,'',1,0,'',NULL,0),(4,'天津市','0',0,0,'',1,0,'',NULL,0),(5,'重庆市','0',0,0,'',1,0,'',NULL,0),(6,'河北省','0',0,0,'',1,0,'',NULL,0),(7,'山西省','0',0,0,'',1,0,'',NULL,0),(8,'内蒙古','0',0,0,'',1,0,'',NULL,0),(9,'辽宁省','0',0,0,'',1,0,'',NULL,0),(10,'吉林省','0',0,0,'',1,0,'',NULL,0),(11,'黑龙江省','0',0,0,'',1,0,'',NULL,0),(12,'江苏省','0',0,0,'',1,0,'',NULL,0),(13,'浙江省','0',0,0,'',1,0,'',NULL,0),(14,'安徽省','0',0,0,'',1,0,'',NULL,0),(15,'福建省','0',0,0,'',1,0,'',NULL,0),(16,'江西省','0',0,0,'',1,0,'',NULL,0),(17,'山东省','0',0,0,'',1,0,'',NULL,0),(18,'河南省','0',0,0,'',1,0,'',NULL,0),(19,'湖北省','0',0,0,'',1,0,'',NULL,0),(20,'湖南省','0',0,0,'',1,0,'',NULL,0),(21,'广东省','0',0,0,'',1,0,'',NULL,0),(22,'广西','0',0,0,'',1,0,'',NULL,0),(23,'海南省','0',0,0,'',1,0,'',NULL,0),(24,'四川省','0',0,0,'',1,0,'',NULL,0),(25,'贵州省','0',0,0,'',1,0,'',NULL,0),(26,'云南省','0',0,0,'',1,0,'',NULL,0),(27,'西藏','0',0,0,'',1,0,'',NULL,0),(28,'陕西省','0',0,0,'',1,0,'',NULL,0),(29,'甘肃省','0',0,0,'',1,0,'',NULL,0),(30,'青海省','0',0,0,'',1,0,'',NULL,0),(31,'宁夏','0',0,0,'',1,0,'',NULL,0),(32,'新疆','0',0,0,'',1,0,'',NULL,0),(33,'台湾省','0',0,0,'',1,0,'',NULL,0),(34,'香港','0',0,0,'',1,0,'',NULL,0),(35,'澳门','0',0,0,'',1,0,'',NULL,0),(36,'东城区','0',2,0,'',1,0,'',NULL,0),(37,'西城区','0',2,0,'',1,0,'',NULL,0),(38,'崇文区','0',2,0,'',1,0,'',NULL,0),(39,'宣武区','0',2,0,'',1,0,'',NULL,0),(40,'朝阳区','0',2,0,'',1,0,'',NULL,0),(41,'石景山区','0',2,0,'',1,0,'',NULL,0),(42,'海淀区','0',2,0,'',1,0,'',NULL,0),(43,'门头沟区','0',2,0,'',1,0,'',NULL,0),(44,'房山区','0',2,0,'',1,0,'',NULL,0),(45,'通州区','0',2,0,'',1,0,'',NULL,0),(46,'顺义区','0',2,0,'',1,0,'',NULL,0),(47,'昌平区','0',2,0,'',1,0,'',NULL,0),(48,'大兴区','0',2,0,'',1,0,'',NULL,0),(49,'怀柔区','0',2,0,'',1,0,'',NULL,0),(50,'平谷区','0',2,0,'',1,0,'',NULL,0),(51,'密云县','0',2,0,'',1,0,'',NULL,0),(52,'延庆县','0',2,0,'',1,0,'',NULL,0),(53,'黄浦区','0',3,0,'',1,0,'',NULL,0),(54,'卢湾区','0',3,0,'',1,0,'',NULL,0),(55,'徐汇区','0',3,0,'',1,0,'',NULL,0),(56,'长宁区','0',3,0,'',1,0,'',NULL,0),(57,'静安区','0',3,0,'',1,0,'',NULL,0),(58,'普陀区','0',3,0,'',1,0,'',NULL,0),(59,'闸北区','0',3,0,'',1,0,'',NULL,0),(60,'虹口区','0',3,0,'',1,0,'',NULL,0),(61,'杨浦区','0',3,0,'',1,0,'',NULL,0),(62,'闵行区','0',3,0,'',1,0,'',NULL,0),(63,'宝山区','0',3,0,'',1,0,'',NULL,0),(64,'嘉定区','0',3,0,'',1,0,'',NULL,0),(65,'浦东新区','0',3,0,'',1,0,'',NULL,0),(66,'金山区','0',3,0,'',1,0,'',NULL,0),(67,'松江区','0',3,0,'',1,0,'',NULL,0),(68,'青浦区','0',3,0,'',1,0,'',NULL,0),(69,'南汇区','0',3,0,'',1,0,'',NULL,0),(70,'奉贤区','0',3,0,'',1,0,'',NULL,0),(71,'崇明县','0',3,0,'',1,0,'',NULL,0),(72,'和平区','0',4,0,'',1,0,'',NULL,0),(73,'河东区','0',4,0,'',1,0,'',NULL,0),(74,'河西区','0',4,0,'',1,0,'',NULL,0),(75,'南开区','0',4,0,'',1,0,'',NULL,0),(76,'河北区','0',4,0,'',1,0,'',NULL,0),(77,'红桥区','0',4,0,'',1,0,'',NULL,0),(78,'塘沽区','0',4,0,'',1,0,'',NULL,0),(79,'汉沽区','0',4,0,'',1,0,'',NULL,0),(80,'大港区','0',4,0,'',1,0,'',NULL,0),(81,'东丽区','0',4,0,'',1,0,'',NULL,0),(82,'西青区','0',4,0,'',1,0,'',NULL,0),(83,'津南区','0',4,0,'',1,0,'',NULL,0),(84,'北辰区','0',4,0,'',1,0,'',NULL,0),(85,'武清区','0',4,0,'',1,0,'',NULL,0),(86,'宝坻区','0',4,0,'',1,0,'',NULL,0),(87,'宁河县','0',4,0,'',1,0,'',NULL,0),(88,'静海县','0',4,0,'',1,0,'',NULL,0),(89,'蓟县','0',4,0,'',1,0,'',NULL,0),(90,'万州区','0',5,0,'',1,0,'',NULL,0),(91,'涪陵区','0',5,0,'',1,0,'',NULL,0),(92,'渝中区','0',5,0,'',1,0,'',NULL,0),(93,'大渡口区','0',5,0,'',1,0,'',NULL,0),(94,'江北区','0',5,0,'',1,0,'',NULL,0),(95,'沙坪坝区','0',5,0,'',1,0,'',NULL,0),(96,'九龙坡区','0',5,0,'',1,0,'',NULL,0),(97,'南岸区','0',5,0,'',1,0,'',NULL,0),(98,'北碚区','0',5,0,'',1,0,'',NULL,0),(99,'万盛区','0',5,0,'',1,0,'',NULL,0),(100,'双桥区','0',5,0,'',1,0,'',NULL,0),(101,'渝北区','0',5,0,'',1,0,'',NULL,0),(102,'巴南区','0',5,0,'',1,0,'',NULL,0),(103,'黔江区','0',5,0,'',1,0,'',NULL,0),(104,'长寿区','0',5,0,'',1,0,'',NULL,0),(105,'綦江县','0',5,0,'',1,0,'',NULL,0),(106,'潼南县','0',5,0,'',1,0,'',NULL,0),(107,'铜梁县','0',5,0,'',1,0,'',NULL,0),(108,'大足县','0',5,0,'',1,0,'',NULL,0),(109,'荣昌县','0',5,0,'',1,0,'',NULL,0),(110,'璧山县','0',5,0,'',1,0,'',NULL,0),(111,'梁平县','0',5,0,'',1,0,'',NULL,0),(112,'城口县','0',5,0,'',1,0,'',NULL,0),(113,'丰都县','0',5,0,'',1,0,'',NULL,0),(114,'垫江县','0',5,0,'',1,0,'',NULL,0),(115,'武隆县','0',5,0,'',1,0,'',NULL,0),(116,'忠县','0',5,0,'',1,0,'',NULL,0),(117,'开县','0',5,0,'',1,0,'',NULL,0),(118,'云阳县','0',5,0,'',1,0,'',NULL,0),(119,'奉节县','0',5,0,'',1,0,'',NULL,0),(120,'巫山县','0',5,0,'',1,0,'',NULL,0),(121,'巫溪县','0',5,0,'',1,0,'',NULL,0),(122,'石柱县','0',5,0,'',1,0,'',NULL,0),(123,'秀山县','0',5,0,'',1,0,'',NULL,0),(124,'酉阳县','0',5,0,'',1,0,'',NULL,0),(125,'彭水县','0',5,0,'',1,0,'',NULL,0),(126,'江津区','0',5,0,'',1,0,'',NULL,0),(127,'合川区','0',5,0,'',1,0,'',NULL,0),(128,'永川区','0',5,0,'',1,0,'',NULL,0),(129,'南川区','0',5,0,'',1,0,'',NULL,0),(130,'石家庄市','0',6,0,'',1,0,'',NULL,0),(131,'唐山市','0',6,0,'',1,0,'',NULL,0),(132,'秦皇岛市','0',6,0,'',1,0,'',NULL,0),(133,'邯郸市','0',6,0,'',1,0,'',NULL,0),(134,'邢台市','0',6,0,'',1,0,'',NULL,0),(135,'保定市','0',6,0,'',1,0,'',NULL,0),(136,'张家口市','0',6,0,'',1,0,'',NULL,0),(137,'承德市','0',6,0,'',1,0,'',NULL,0),(138,'沧州市','0',6,0,'',1,0,'',NULL,0),(139,'廊坊市','0',6,0,'',1,0,'',NULL,0),(140,'衡水市','0',6,0,'',1,0,'',NULL,0),(141,'太原市','0',7,0,'',1,0,'',NULL,0),(142,'大同市','0',7,0,'',1,0,'',NULL,0),(143,'阳泉市','0',7,0,'',1,0,'',NULL,0),(144,'长治市','0',7,0,'',1,0,'',NULL,0),(145,'晋城市','0',7,0,'',1,0,'',NULL,0),(146,'朔州市','0',7,0,'',1,0,'',NULL,0),(147,'晋中市','0',7,0,'',1,0,'',NULL,0),(148,'运城市','0',7,0,'',1,0,'',NULL,0),(149,'忻州市','0',7,0,'',1,0,'',NULL,0),(150,'临汾市','0',7,0,'',1,0,'',NULL,0),(151,'吕梁市','0',7,0,'',1,0,'',NULL,0),(152,'呼和浩特市','0',8,0,'',1,0,'',NULL,0),(153,'包头市','0',8,0,'',1,0,'',NULL,0),(154,'乌海市','0',8,0,'',1,0,'',NULL,0),(155,'赤峰市','0',8,0,'',1,0,'',NULL,0),(156,'通辽市','0',8,0,'',1,0,'',NULL,0),(157,'鄂尔多斯市','0',8,0,'',1,0,'',NULL,0),(158,'呼伦贝尔市','0',8,0,'',1,0,'',NULL,0),(159,'巴彦淖尔市','0',8,0,'',1,0,'',NULL,0),(160,'乌兰察布市','0',8,0,'',1,0,'',NULL,0),(161,'兴安盟','0',8,0,'',1,0,'',NULL,0),(162,'锡林郭勒盟','0',8,0,'',1,0,'',NULL,0),(163,'阿拉善盟','0',8,0,'',1,0,'',NULL,0),(164,'沈阳市','0',9,0,'',1,0,'',NULL,0),(165,'大连市','0',9,0,'',1,0,'',NULL,0),(166,'鞍山市','0',9,0,'',1,0,'',NULL,0),(167,'抚顺市','0',9,0,'',1,0,'',NULL,0),(168,'本溪市','0',9,0,'',1,0,'',NULL,0),(169,'丹东市','0',9,0,'',1,0,'',NULL,0),(170,'锦州市','0',9,0,'',1,0,'',NULL,0),(171,'营口市','0',9,0,'',1,0,'',NULL,0),(172,'阜新市','0',9,0,'',1,0,'',NULL,0),(173,'辽阳市','0',9,0,'',1,0,'',NULL,0),(174,'盘锦市','0',9,0,'',1,0,'',NULL,0),(175,'铁岭市','0',9,0,'',1,0,'',NULL,0),(176,'朝阳市','0',9,0,'',1,0,'',NULL,0),(177,'葫芦岛市','0',9,0,'',1,0,'',NULL,0),(178,'长春市','0',10,0,'',1,0,'',NULL,0),(179,'吉林市','0',10,0,'',1,0,'',NULL,0),(180,'四平市','0',10,0,'',1,0,'',NULL,0),(181,'辽源市','0',10,0,'',1,0,'',NULL,0),(182,'通化市','0',10,0,'',1,0,'',NULL,0),(183,'白山市','0',10,0,'',1,0,'',NULL,0),(184,'松原市','0',10,0,'',1,0,'',NULL,0),(185,'白城市','0',10,0,'',1,0,'',NULL,0),(186,'延边','0',10,0,'',1,0,'',NULL,0),(187,'哈尔滨市','0',11,0,'',1,0,'',NULL,0),(188,'齐齐哈尔市','0',11,0,'',1,0,'',NULL,0),(189,'鸡西市','0',11,0,'',1,0,'',NULL,0),(190,'鹤岗市','0',11,0,'',1,0,'',NULL,0),(191,'双鸭山市','0',11,0,'',1,0,'',NULL,0),(192,'大庆市','0',11,0,'',1,0,'',NULL,0),(193,'伊春市','0',11,0,'',1,0,'',NULL,0),(194,'佳木斯市','0',11,0,'',1,0,'',NULL,0),(195,'七台河市','0',11,0,'',1,0,'',NULL,0),(196,'牡丹江市','0',11,0,'',1,0,'',NULL,0),(197,'黑河市','0',11,0,'',1,0,'',NULL,0),(198,'绥化市','0',11,0,'',1,0,'',NULL,0),(199,'大兴安岭地区','0',11,0,'',1,0,'',NULL,0),(200,'南京市','0',12,0,'',1,0,'',NULL,0),(201,'无锡市','0',12,0,'',1,0,'',NULL,0),(202,'徐州市','0',12,0,'',1,0,'',NULL,0),(203,'常州市','0',12,0,'',1,0,'',NULL,0),(204,'苏州市','0',12,0,'',1,0,'',NULL,0),(205,'南通市','0',12,0,'',1,0,'',NULL,0),(206,'连云港市','0',12,0,'',1,0,'',NULL,0),(207,'淮安市','0',12,0,'',1,0,'',NULL,0),(208,'盐城市','0',12,0,'',1,0,'',NULL,0),(209,'扬州市','0',12,0,'',1,0,'',NULL,0),(210,'镇江市','0',12,0,'',1,0,'',NULL,0),(211,'泰州市','0',12,0,'',1,0,'',NULL,0),(212,'宿迁市','0',12,0,'',1,0,'',NULL,0),(213,'杭州市','0',13,0,'',1,0,'',NULL,0),(214,'宁波市','0',13,0,'',1,0,'',NULL,0),(215,'温州市','0',13,0,'',1,0,'',NULL,0),(216,'嘉兴市','0',13,0,'',1,0,'',NULL,0),(217,'湖州市','0',13,0,'',1,0,'',NULL,0),(218,'绍兴市','0',13,0,'',1,0,'',NULL,0),(219,'金华市','0',13,0,'',1,0,'',NULL,0),(220,'衢州市','0',13,0,'',1,0,'',NULL,0),(221,'舟山市','0',13,0,'',1,0,'',NULL,0),(222,'台州市','0',13,0,'',1,0,'',NULL,0),(223,'丽水市','0',13,0,'',1,0,'',NULL,0),(224,'合肥市','0',14,0,'',1,0,'',NULL,0),(225,'芜湖市','0',14,0,'',1,0,'',NULL,0),(226,'蚌埠市','0',14,0,'',1,0,'',NULL,0),(227,'淮南市','0',14,0,'',1,0,'',NULL,0),(228,'马鞍山市','0',14,0,'',1,0,'',NULL,0),(229,'淮北市','0',14,0,'',1,0,'',NULL,0),(230,'铜陵市','0',14,0,'',1,0,'',NULL,0),(231,'安庆市','0',14,0,'',1,0,'',NULL,0),(232,'黄山市','0',14,0,'',1,0,'',NULL,0),(233,'滁州市','0',14,0,'',1,0,'',NULL,0),(234,'阜阳市','0',14,0,'',1,0,'',NULL,0),(235,'宿州市','0',14,0,'',1,0,'',NULL,0),(236,'巢湖市','0',14,0,'',1,0,'',NULL,0),(237,'六安市','0',14,0,'',1,0,'',NULL,0),(238,'亳州市','0',14,0,'',1,0,'',NULL,0),(239,'池州市','0',14,0,'',1,0,'',NULL,0),(240,'宣城市','0',14,0,'',1,0,'',NULL,0),(241,'福州市','0',15,0,'',1,0,'',NULL,0),(242,'厦门市','0',15,0,'',1,0,'',NULL,0),(243,'莆田市','0',15,0,'',1,0,'',NULL,0),(244,'三明市','0',15,0,'',1,0,'',NULL,0),(245,'泉州市','0',15,0,'',1,0,'',NULL,0),(246,'漳州市','0',15,0,'',1,0,'',NULL,0),(247,'南平市','0',15,0,'',1,0,'',NULL,0),(248,'龙岩市','0',15,0,'',1,0,'',NULL,0),(249,'宁德市','0',15,0,'',1,0,'',NULL,0),(250,'南昌市','0',16,0,'',1,0,'',NULL,0),(251,'景德镇市','0',16,0,'',1,0,'',NULL,0),(252,'萍乡市','0',16,0,'',1,0,'',NULL,0),(253,'九江市','0',16,0,'',1,0,'',NULL,0),(254,'新余市','0',16,0,'',1,0,'',NULL,0),(255,'鹰潭市','0',16,0,'',1,0,'',NULL,0),(256,'赣州市','0',16,0,'',1,0,'',NULL,0),(257,'吉安市','0',16,0,'',1,0,'',NULL,0),(258,'宜春市','0',16,0,'',1,0,'',NULL,0),(259,'抚州市','0',16,0,'',1,0,'',NULL,0),(260,'上饶市','0',16,0,'',1,0,'',NULL,0),(261,'济南市','0',17,0,'',1,0,'',NULL,0),(262,'青岛市','0',17,0,'',1,0,'',NULL,0),(263,'淄博市','0',17,0,'',1,0,'',NULL,0),(264,'枣庄市','0',17,0,'',1,0,'',NULL,0),(265,'东营市','0',17,0,'',1,0,'',NULL,0),(266,'烟台市','0',17,0,'',1,0,'',NULL,0),(267,'潍坊市','0',17,0,'',1,0,'',NULL,0),(268,'济宁市','0',17,0,'',1,0,'',NULL,0),(269,'泰安市','0',17,0,'',1,0,'',NULL,0),(270,'威海市','0',17,0,'',1,0,'',NULL,0),(271,'日照市','0',17,0,'',1,0,'',NULL,0),(272,'莱芜市','0',17,0,'',1,0,'',NULL,0),(273,'临沂市','0',17,0,'',1,0,'',NULL,0),(274,'德州市','0',17,0,'',1,0,'',NULL,0),(275,'聊城市','0',17,0,'',1,0,'',NULL,0),(276,'滨州市','0',17,0,'',1,0,'',NULL,0),(277,'荷泽市','0',17,0,'',1,0,'',NULL,0),(278,'郑州市','0',18,0,'',1,0,'',NULL,0),(279,'开封市','0',18,0,'',1,0,'',NULL,0),(280,'洛阳市','0',18,0,'',1,0,'',NULL,0),(281,'平顶山市','0',18,0,'',1,0,'',NULL,0),(282,'安阳市','0',18,0,'',1,0,'',NULL,0),(283,'鹤壁市','0',18,0,'',1,0,'',NULL,0),(284,'新乡市','0',18,0,'',1,0,'',NULL,0),(285,'焦作市','0',18,0,'',1,0,'',NULL,0),(286,'濮阳市','0',18,0,'',1,0,'',NULL,0),(287,'许昌市','0',18,0,'',1,0,'',NULL,0),(288,'漯河市','0',18,0,'',1,0,'',NULL,0),(289,'三门峡市','0',18,0,'',1,0,'',NULL,0),(290,'南阳市','0',18,0,'',1,0,'',NULL,0),(291,'商丘市','0',18,0,'',1,0,'',NULL,0),(292,'信阳市','0',18,0,'',1,0,'',NULL,0),(293,'周口市','0',18,0,'',1,0,'',NULL,0),(294,'驻马店市','0',18,0,'',1,0,'',NULL,0),(295,'武汉市','0',19,0,'',1,0,'',NULL,0),(296,'黄石市','0',19,0,'',1,0,'',NULL,0),(297,'十堰市','0',19,0,'',1,0,'',NULL,0),(298,'宜昌市','0',19,0,'',1,0,'',NULL,0),(299,'襄樊市','0',19,0,'',1,0,'',NULL,0),(300,'鄂州市','0',19,0,'',1,0,'',NULL,0),(301,'荆门市','0',19,0,'',1,0,'',NULL,0),(302,'孝感市','0',19,0,'',1,0,'',NULL,0),(303,'荆州市','0',19,0,'',1,0,'',NULL,0),(304,'黄冈市','0',19,0,'',1,0,'',NULL,0),(305,'咸宁市','0',19,0,'',1,0,'',NULL,0),(306,'随州市','0',19,0,'',1,0,'',NULL,0),(307,'恩施土家族苗族自治州','0',19,0,'',1,0,'',NULL,0),(308,'仙桃市','0',19,0,'',1,0,'',NULL,0),(309,'潜江市','0',19,0,'',1,0,'',NULL,0),(310,'天门市','0',19,0,'',1,0,'',NULL,0),(311,'神农架林区','0',19,0,'',1,0,'',NULL,0),(312,'长沙市','0',20,0,'',1,0,'',NULL,0),(313,'株洲市','0',20,0,'',1,0,'',NULL,0),(314,'湘潭市','0',20,0,'',1,0,'',NULL,0),(315,'衡阳市','0',20,0,'',1,0,'',NULL,0),(316,'邵阳市','0',20,0,'',1,0,'',NULL,0),(317,'岳阳市','0',20,0,'',1,0,'',NULL,0),(318,'常德市','0',20,0,'',1,0,'',NULL,0),(319,'张家界市','0',20,0,'',1,0,'',NULL,0),(320,'益阳市','0',20,0,'',1,0,'',NULL,0),(321,'郴州市','0',20,0,'',1,0,'',NULL,0),(322,'永州市','0',20,0,'',1,0,'',NULL,0),(323,'怀化市','0',20,0,'',1,0,'',NULL,0),(324,'娄底市','0',20,0,'',1,0,'',NULL,0),(325,'湘西土家族苗族自治州','0',20,0,'',1,0,'',NULL,0),(326,'广州市','0',21,0,'',1,0,'',NULL,0),(327,'韶关市','0',21,0,'',1,0,'',NULL,0),(328,'深圳市','0',21,0,'',1,0,'',NULL,0),(329,'珠海市','0',21,0,'',1,0,'',NULL,0),(330,'汕头市','0',21,0,'',1,0,'',NULL,0),(331,'佛山市','0',21,0,'',1,0,'',NULL,0),(332,'江门市','0',21,0,'',1,0,'',NULL,0),(333,'湛江市','0',21,0,'',1,0,'',NULL,0),(334,'茂名市','0',21,0,'',1,0,'',NULL,0),(335,'肇庆市','0',21,0,'',1,0,'',NULL,0),(336,'惠州市','0',21,0,'',1,0,'',NULL,0),(337,'梅州市','0',21,0,'',1,0,'',NULL,0),(338,'汕尾市','0',21,0,'',1,0,'',NULL,0),(339,'河源市','0',21,0,'',1,0,'',NULL,0),(340,'阳江市','0',21,0,'',1,0,'',NULL,0),(341,'清远市','0',21,0,'',1,0,'',NULL,0),(342,'东莞市','0',21,0,'',1,0,'',NULL,0),(343,'中山市','0',21,0,'',1,0,'',NULL,0),(344,'潮州市','0',21,0,'',1,0,'',NULL,0),(345,'揭阳市','0',21,0,'',1,0,'',NULL,0),(346,'云浮市','0',21,0,'',1,0,'',NULL,0),(347,'南宁市','0',22,0,'',1,0,'',NULL,0),(348,'柳州市','0',22,0,'',1,0,'',NULL,0),(349,'桂林市','0',22,0,'',1,0,'',NULL,0),(350,'梧州市','0',22,0,'',1,0,'',NULL,0),(351,'北海市','0',22,0,'',1,0,'',NULL,0),(352,'防城港市','0',22,0,'',1,0,'',NULL,0),(353,'钦州市','0',22,0,'',1,0,'',NULL,0),(354,'贵港市','0',22,0,'',1,0,'',NULL,0),(355,'玉林市','0',22,0,'',1,0,'',NULL,0),(356,'百色市','0',22,0,'',1,0,'',NULL,0),(357,'贺州市','0',22,0,'',1,0,'',NULL,0),(358,'河池市','0',22,0,'',1,0,'',NULL,0),(359,'来宾市','0',22,0,'',1,0,'',NULL,0),(360,'崇左市','0',22,0,'',1,0,'',NULL,0),(361,'海口市','0',23,0,'',1,0,'',NULL,0),(362,'三亚市','0',23,0,'',1,0,'',NULL,0),(363,'五指山市','0',23,0,'',1,0,'',NULL,0),(364,'琼海市','0',23,0,'',1,0,'',NULL,0),(365,'儋州市','0',23,0,'',1,0,'',NULL,0),(366,'文昌市','0',23,0,'',1,0,'',NULL,0),(367,'万宁市','0',23,0,'',1,0,'',NULL,0),(368,'东方市','0',23,0,'',1,0,'',NULL,0),(369,'定安县','0',23,0,'',1,0,'',NULL,0),(370,'屯昌县','0',23,0,'',1,0,'',NULL,0),(371,'澄迈县','0',23,0,'',1,0,'',NULL,0),(372,'临高县','0',23,0,'',1,0,'',NULL,0),(373,'白沙黎族自治县','0',23,0,'',1,0,'',NULL,0),(374,'昌江黎族自治县','0',23,0,'',1,0,'',NULL,0),(375,'乐东黎族自治县','0',23,0,'',1,0,'',NULL,0),(376,'陵水黎族自治县','0',23,0,'',1,0,'',NULL,0),(377,'保亭黎族苗族自治县','0',23,0,'',1,0,'',NULL,0),(378,'琼中黎族苗族自治县','0',23,0,'',1,0,'',NULL,0),(379,'西沙群岛','0',23,0,'',1,0,'',NULL,0),(380,'南沙群岛','0',23,0,'',1,0,'',NULL,0),(381,'中沙群岛的岛礁及其海域','0',23,0,'',1,0,'',NULL,0),(382,'成都市','0',24,0,'',1,0,'',NULL,0),(383,'自贡市','0',24,0,'',1,0,'',NULL,0),(384,'攀枝花市','0',24,0,'',1,0,'',NULL,0),(385,'泸州市','0',24,0,'',1,0,'',NULL,0),(386,'德阳市','0',24,0,'',1,0,'',NULL,0),(387,'绵阳市','0',24,0,'',1,0,'',NULL,0),(388,'广元市','0',24,0,'',1,0,'',NULL,0),(389,'遂宁市','0',24,0,'',1,0,'',NULL,0),(390,'内江市','0',24,0,'',1,0,'',NULL,0),(391,'乐山市','0',24,0,'',1,0,'',NULL,0),(392,'南充市','0',24,0,'',1,0,'',NULL,0),(393,'眉山市','0',24,0,'',1,0,'',NULL,0),(394,'宜宾市','0',24,0,'',1,0,'',NULL,0),(395,'广安市','0',24,0,'',1,0,'',NULL,0),(396,'达州市','0',24,0,'',1,0,'',NULL,0),(397,'雅安市','0',24,0,'',1,0,'',NULL,0),(398,'巴中市','0',24,0,'',1,0,'',NULL,0),(399,'资阳市','0',24,0,'',1,0,'',NULL,0),(400,'阿坝州','0',24,0,'',1,0,'',NULL,0),(401,'甘孜州','0',24,0,'',1,0,'',NULL,0),(402,'凉山州','0',24,0,'',1,0,'',NULL,0),(403,'贵阳市','0',25,0,'',1,0,'',NULL,0),(404,'六盘水市','0',25,0,'',1,0,'',NULL,0),(405,'遵义市','0',25,0,'',1,0,'',NULL,0),(406,'安顺市','0',25,0,'',1,0,'',NULL,0),(407,'铜仁地区','0',25,0,'',1,0,'',NULL,0),(408,'黔西南州','0',25,0,'',1,0,'',NULL,0),(409,'毕节地区','0',25,0,'',1,0,'',NULL,0),(410,'黔东南州','0',25,0,'',1,0,'',NULL,0),(411,'黔南州','0',25,0,'',1,0,'',NULL,0),(412,'昆明市','0',26,0,'',1,0,'',NULL,0),(413,'曲靖市','0',26,0,'',1,0,'',NULL,0),(414,'玉溪市','0',26,0,'',1,0,'',NULL,0),(415,'保山市','0',26,0,'',1,0,'',NULL,0),(416,'昭通市','0',26,0,'',1,0,'',NULL,0),(417,'丽江市','0',26,0,'',1,0,'',NULL,0),(418,'思茅市','0',26,0,'',1,0,'',NULL,0),(419,'临沧市','0',26,0,'',1,0,'',NULL,0),(420,'楚雄州','0',26,0,'',1,0,'',NULL,0),(421,'红河州','0',26,0,'',1,0,'',NULL,0),(422,'文山州','0',26,0,'',1,0,'',NULL,0),(423,'西双版纳','0',26,0,'',1,0,'',NULL,0),(424,'大理','0',26,0,'',1,0,'',NULL,0),(425,'德宏','0',26,0,'',1,0,'',NULL,0),(426,'怒江','0',26,0,'',1,0,'',NULL,0),(427,'迪庆','0',26,0,'',1,0,'',NULL,0),(428,'拉萨市','0',27,0,'',1,0,'',NULL,0),(429,'昌都','0',27,0,'',1,0,'',NULL,0),(430,'山南','0',27,0,'',1,0,'',NULL,0),(431,'日喀则','0',27,0,'',1,0,'',NULL,0),(432,'那曲','0',27,0,'',1,0,'',NULL,0),(433,'阿里','0',27,0,'',1,0,'',NULL,0),(434,'林芝','0',27,0,'',1,0,'',NULL,0),(435,'西安市','0',28,0,'',1,0,'',NULL,0),(436,'铜川市','0',28,0,'',1,0,'',NULL,0),(437,'宝鸡市','0',28,0,'',1,0,'',NULL,0),(438,'咸阳市','0',28,0,'',1,0,'',NULL,0),(439,'渭南市','0',28,0,'',1,0,'',NULL,0),(440,'延安市','0',28,0,'',1,0,'',NULL,0),(441,'汉中市','0',28,0,'',1,0,'',NULL,0),(442,'榆林市','0',28,0,'',1,0,'',NULL,0),(443,'安康市','0',28,0,'',1,0,'',NULL,0),(444,'商洛市','0',28,0,'',1,0,'',NULL,0),(445,'兰州市','0',29,0,'',1,0,'',NULL,0),(446,'嘉峪关市','0',29,0,'',1,0,'',NULL,0),(447,'金昌市','0',29,0,'',1,0,'',NULL,0),(448,'白银市','0',29,0,'',1,0,'',NULL,0),(449,'天水市','0',29,0,'',1,0,'',NULL,0),(450,'武威市','0',29,0,'',1,0,'',NULL,0),(451,'张掖市','0',29,0,'',1,0,'',NULL,0),(452,'平凉市','0',29,0,'',1,0,'',NULL,0),(453,'酒泉市','0',29,0,'',1,0,'',NULL,0),(454,'庆阳市','0',29,0,'',1,0,'',NULL,0),(455,'定西市','0',29,0,'',1,0,'',NULL,0),(456,'陇南市','0',29,0,'',1,0,'',NULL,0),(457,'临夏州','0',29,0,'',1,0,'',NULL,0),(458,'甘州','0',29,0,'',1,0,'',NULL,0),(459,'西宁市','0',30,0,'',1,0,'',NULL,0),(460,'海东地区','0',30,0,'',1,0,'',NULL,0),(461,'海州','0',30,0,'',1,0,'',NULL,0),(462,'黄南州','0',30,0,'',1,0,'',NULL,0),(463,'海南州','0',30,0,'',1,0,'',NULL,0),(464,'果洛州','0',30,0,'',1,0,'',NULL,0),(465,'玉树州','0',30,0,'',1,0,'',NULL,0),(466,'海西州','0',30,0,'',1,0,'',NULL,0),(467,'银川市','0',31,0,'',1,0,'',NULL,0),(468,'石嘴山市','0',31,0,'',1,0,'',NULL,0),(469,'吴忠市','0',31,0,'',1,0,'',NULL,0),(470,'固原市','0',31,0,'',1,0,'',NULL,0),(471,'中卫市','0',31,0,'',1,0,'',NULL,0),(472,'乌鲁木齐市','0',32,0,'',1,0,'',NULL,0),(473,'克拉玛依市','0',32,0,'',1,0,'',NULL,0),(474,'吐鲁番地区','0',32,0,'',1,0,'',NULL,0),(475,'哈密地区','0',32,0,'',1,0,'',NULL,0),(476,'昌吉州','0',32,0,'',1,0,'',NULL,0),(477,'博尔州','0',32,0,'',1,0,'',NULL,0),(478,'巴音郭楞州','0',32,0,'',1,0,'',NULL,0),(479,'阿克苏地区','0',32,0,'',1,0,'',NULL,0),(480,'克孜勒苏柯尔克孜自治州','0',32,0,'',1,0,'',NULL,0),(481,'喀什地区','0',32,0,'',1,0,'',NULL,0),(482,'和田地区','0',32,0,'',1,0,'',NULL,0),(483,'伊犁州','0',32,0,'',1,0,'',NULL,0),(484,'塔城地区','0',32,0,'',1,0,'',NULL,0),(485,'阿勒泰地区','0',32,0,'',1,0,'',NULL,0),(486,'石河子市','0',32,0,'',1,0,'',NULL,0),(487,'阿拉尔市','0',32,0,'',1,0,'',NULL,0),(488,'图木舒克市','0',32,0,'',1,0,'',NULL,0),(489,'五家渠市','0',32,0,'',1,0,'',NULL,0),(490,'台北市','0',33,0,'',1,0,'',NULL,0),(491,'高雄市','0',33,0,'',1,0,'',NULL,0),(492,'基隆市','0',33,0,'',1,0,'',NULL,0),(493,'新竹市','0',33,0,'',1,0,'',NULL,0),(494,'台中市','0',33,0,'',1,0,'',NULL,0),(495,'嘉义市','0',33,0,'',1,0,'',NULL,0),(496,'台南市','0',33,0,'',1,0,'',NULL,0),(497,'台北县','0',33,0,'',1,0,'',NULL,0),(498,'桃园县','0',33,0,'',1,0,'',NULL,0),(499,'新竹县','0',33,0,'',1,0,'',NULL,0),(500,'苗栗县','0',33,0,'',1,0,'',NULL,0),(501,'台中县','0',33,0,'',1,0,'',NULL,0),(502,'彰化县','0',33,0,'',1,0,'',NULL,0),(503,'南投县','0',33,0,'',1,0,'',NULL,0),(504,'云林县','0',33,0,'',1,0,'',NULL,0),(505,'嘉义县','0',33,0,'',1,0,'',NULL,0),(506,'台南县','0',33,0,'',1,0,'',NULL,0),(507,'高雄县','0',33,0,'',1,0,'',NULL,0),(508,'屏东县','0',33,0,'',1,0,'',NULL,0),(509,'宜兰县','0',33,0,'',1,0,'',NULL,0),(510,'花莲县','0',33,0,'',1,0,'',NULL,0),(511,'台东县','0',33,0,'',1,0,'',NULL,0),(512,'澎湖县','0',33,0,'',1,0,'',NULL,0),(513,'金门县','0',33,0,'',1,0,'',NULL,0),(514,'连江县','0',33,0,'',1,0,'',NULL,0),(515,'中西区','0',34,0,'',1,0,'',NULL,0),(516,'东区','0',34,0,'',1,0,'',NULL,0),(517,'南区','0',34,0,'',1,0,'',NULL,0),(518,'湾仔区','0',34,0,'',1,0,'',NULL,0),(519,'九龙城区','0',34,0,'',1,0,'',NULL,0),(520,'观塘区','0',34,0,'',1,0,'',NULL,0),(521,'深水埗区','0',34,0,'',1,0,'',NULL,0),(522,'黄大仙区','0',34,0,'',1,0,'',NULL,0),(523,'油尖旺区','0',34,0,'',1,0,'',NULL,0),(524,'离岛区','0',34,0,'',1,0,'',NULL,0),(525,'葵青区','0',34,0,'',1,0,'',NULL,0),(526,'北区','0',34,0,'',1,0,'',NULL,0),(527,'西贡区','0',34,0,'',1,0,'',NULL,0),(528,'沙田区','0',34,0,'',1,0,'',NULL,0),(529,'大埔区','0',34,0,'',1,0,'',NULL,0),(530,'荃湾区','0',34,0,'',1,0,'',NULL,0),(531,'屯门区','0',34,0,'',1,0,'',NULL,0),(532,'元朗区','0',34,0,'',1,0,'',NULL,0),(533,'花地玛堂区','0',35,0,'',1,0,'',NULL,0),(534,'市圣安多尼堂区','0',35,0,'',1,0,'',NULL,0),(535,'大堂区','0',35,0,'',1,0,'',NULL,0),(536,'望德堂区','0',35,0,'',1,0,'',NULL,0),(537,'风顺堂区','0',35,0,'',1,0,'',NULL,0),(538,'嘉模堂区','0',35,0,'',1,0,'',NULL,0),(539,'圣方济各堂区','0',35,0,'',1,0,'',NULL,0),(540,'长安区','0',130,0,'',1,0,'',NULL,0),(541,'桥东区','0',130,0,'',1,0,'',NULL,0),(542,'桥西区','0',130,0,'',1,0,'',NULL,0),(543,'新华区','0',130,0,'',1,0,'',NULL,0),(544,'井陉矿区','0',130,0,'',1,0,'',NULL,0),(545,'裕华区','0',130,0,'',1,0,'',NULL,0),(546,'井陉县','0',130,0,'',1,0,'',NULL,0),(547,'正定县','0',130,0,'',1,0,'',NULL,0),(548,'栾城县','0',130,0,'',1,0,'',NULL,0),(549,'行唐县','0',130,0,'',1,0,'',NULL,0),(550,'灵寿县','0',130,0,'',1,0,'',NULL,0),(551,'高邑县','0',130,0,'',1,0,'',NULL,0),(552,'深泽县','0',130,0,'',1,0,'',NULL,0),(553,'赞皇县','0',130,0,'',1,0,'',NULL,0),(554,'无极县','0',130,0,'',1,0,'',NULL,0),(555,'平山县','0',130,0,'',1,0,'',NULL,0),(556,'元氏县','0',130,0,'',1,0,'',NULL,0),(557,'赵县','0',130,0,'',1,0,'',NULL,0),(558,'辛集市','0',130,0,'',1,0,'',NULL,0),(559,'藁城市','0',130,0,'',1,0,'',NULL,0),(560,'晋州市','0',130,0,'',1,0,'',NULL,0),(561,'新乐市','0',130,0,'',1,0,'',NULL,0),(562,'鹿泉市','0',130,0,'',1,0,'',NULL,0),(563,'路南区','0',131,0,'',1,0,'',NULL,0),(564,'路北区','0',131,0,'',1,0,'',NULL,0),(565,'古冶区','0',131,0,'',1,0,'',NULL,0),(566,'开平区','0',131,0,'',1,0,'',NULL,0),(567,'丰南区','0',131,0,'',1,0,'',NULL,0),(568,'丰润区','0',131,0,'',1,0,'',NULL,0),(569,'滦县','0',131,0,'',1,0,'',NULL,0),(570,'滦南县','0',131,0,'',1,0,'',NULL,0),(571,'乐亭县','0',131,0,'',1,0,'',NULL,0),(572,'迁西县','0',131,0,'',1,0,'',NULL,0),(573,'玉田县','0',131,0,'',1,0,'',NULL,0),(574,'唐海县','0',131,0,'',1,0,'',NULL,0),(575,'遵化市','0',131,0,'',1,0,'',NULL,0),(576,'迁安市','0',131,0,'',1,0,'',NULL,0),(577,'海港区','0',132,0,'',1,0,'',NULL,0),(578,'山海关区','0',132,0,'',1,0,'',NULL,0),(579,'北戴河区','0',132,0,'',1,0,'',NULL,0),(580,'青龙县','0',132,0,'',1,0,'',NULL,0),(581,'昌黎县','0',132,0,'',1,0,'',NULL,0),(582,'抚宁县','0',132,0,'',1,0,'',NULL,0),(583,'卢龙县','0',132,0,'',1,0,'',NULL,0),(584,'邯山区','0',133,0,'',1,0,'',NULL,0),(585,'丛台区','0',133,0,'',1,0,'',NULL,0),(586,'复兴区','0',133,0,'',1,0,'',NULL,0),(587,'峰峰矿区','0',133,0,'',1,0,'',NULL,0),(588,'邯郸县','0',133,0,'',1,0,'',NULL,0),(589,'临漳县','0',133,0,'',1,0,'',NULL,0),(590,'成安县','0',133,0,'',1,0,'',NULL,0),(591,'大名县','0',133,0,'',1,0,'',NULL,0),(592,'涉县','0',133,0,'',1,0,'',NULL,0),(593,'磁县','0',133,0,'',1,0,'',NULL,0),(594,'肥乡县','0',133,0,'',1,0,'',NULL,0),(595,'永年县','0',133,0,'',1,0,'',NULL,0),(596,'邱县','0',133,0,'',1,0,'',NULL,0),(597,'鸡泽县','0',133,0,'',1,0,'',NULL,0),(598,'广平县','0',133,0,'',1,0,'',NULL,0),(599,'馆陶县','0',133,0,'',1,0,'',NULL,0),(600,'魏县','0',133,0,'',1,0,'',NULL,0),(601,'曲周县','0',133,0,'',1,0,'',NULL,0),(602,'武安市','0',133,0,'',1,0,'',NULL,0),(603,'桥东区','0',134,0,'',1,0,'',NULL,0),(604,'桥西区','0',134,0,'',1,0,'',NULL,0),(605,'邢台县','0',134,0,'',1,0,'',NULL,0),(606,'临城县','0',134,0,'',1,0,'',NULL,0),(607,'内丘县','0',134,0,'',1,0,'',NULL,0),(608,'柏乡县','0',134,0,'',1,0,'',NULL,0),(609,'隆尧县','0',134,0,'',1,0,'',NULL,0),(610,'任县','0',134,0,'',1,0,'',NULL,0),(611,'南和县','0',134,0,'',1,0,'',NULL,0),(612,'宁晋县','0',134,0,'',1,0,'',NULL,0),(613,'巨鹿县','0',134,0,'',1,0,'',NULL,0),(614,'新河县','0',134,0,'',1,0,'',NULL,0),(615,'广宗县','0',134,0,'',1,0,'',NULL,0),(616,'平乡县','0',134,0,'',1,0,'',NULL,0),(617,'威县','0',134,0,'',1,0,'',NULL,0),(618,'清河县','0',134,0,'',1,0,'',NULL,0),(619,'临西县','0',134,0,'',1,0,'',NULL,0),(620,'南宫市','0',134,0,'',1,0,'',NULL,0),(621,'沙河市','0',134,0,'',1,0,'',NULL,0),(622,'新市区','0',135,0,'',1,0,'',NULL,0),(623,'北市区','0',135,0,'',1,0,'',NULL,0),(624,'南市区','0',135,0,'',1,0,'',NULL,0),(625,'满城县','0',135,0,'',1,0,'',NULL,0),(626,'清苑县','0',135,0,'',1,0,'',NULL,0),(627,'涞水县','0',135,0,'',1,0,'',NULL,0),(628,'阜平县','0',135,0,'',1,0,'',NULL,0),(629,'徐水县','0',135,0,'',1,0,'',NULL,0),(630,'定兴县','0',135,0,'',1,0,'',NULL,0),(631,'唐县','0',135,0,'',1,0,'',NULL,0),(632,'高阳县','0',135,0,'',1,0,'',NULL,0),(633,'容城县','0',135,0,'',1,0,'',NULL,0),(634,'涞源县','0',135,0,'',1,0,'',NULL,0),(635,'望都县','0',135,0,'',1,0,'',NULL,0),(636,'安新县','0',135,0,'',1,0,'',NULL,0),(637,'易县','0',135,0,'',1,0,'',NULL,0),(638,'曲阳县','0',135,0,'',1,0,'',NULL,0),(639,'蠡县','0',135,0,'',1,0,'',NULL,0),(640,'顺平县','0',135,0,'',1,0,'',NULL,0),(641,'博野县','0',135,0,'',1,0,'',NULL,0),(642,'雄县','0',135,0,'',1,0,'',NULL,0),(643,'涿州市','0',135,0,'',1,0,'',NULL,0),(644,'定州市','0',135,0,'',1,0,'',NULL,0),(645,'安国市','0',135,0,'',1,0,'',NULL,0),(646,'高碑店市','0',135,0,'',1,0,'',NULL,0),(647,'桥东区','0',136,0,'',1,0,'',NULL,0),(648,'桥西区','0',136,0,'',1,0,'',NULL,0),(649,'宣化区','0',136,0,'',1,0,'',NULL,0),(650,'下花园区','0',136,0,'',1,0,'',NULL,0),(651,'宣化县','0',136,0,'',1,0,'',NULL,0),(652,'张北县','0',136,0,'',1,0,'',NULL,0),(653,'康保县','0',136,0,'',1,0,'',NULL,0),(654,'沽源县','0',136,0,'',1,0,'',NULL,0),(655,'尚义县','0',136,0,'',1,0,'',NULL,0),(656,'蔚县','0',136,0,'',1,0,'',NULL,0),(657,'阳原县','0',136,0,'',1,0,'',NULL,0),(658,'怀安县','0',136,0,'',1,0,'',NULL,0),(659,'万全县','0',136,0,'',1,0,'',NULL,0),(660,'怀来县','0',136,0,'',1,0,'',NULL,0),(661,'涿鹿县','0',136,0,'',1,0,'',NULL,0),(662,'赤城县','0',136,0,'',1,0,'',NULL,0),(663,'崇礼县','0',136,0,'',1,0,'',NULL,0),(664,'双桥区','0',137,0,'',1,0,'',NULL,0),(665,'双滦区','0',137,0,'',1,0,'',NULL,0),(666,'鹰手营子矿区','0',137,0,'',1,0,'',NULL,0),(667,'承德县','0',137,0,'',1,0,'',NULL,0),(668,'兴隆县','0',137,0,'',1,0,'',NULL,0),(669,'平泉县','0',137,0,'',1,0,'',NULL,0),(670,'滦平县','0',137,0,'',1,0,'',NULL,0),(671,'隆化县','0',137,0,'',1,0,'',NULL,0),(672,'丰宁县','0',137,0,'',1,0,'',NULL,0),(673,'宽城县','0',137,0,'',1,0,'',NULL,0),(674,'围场县','0',137,0,'',1,0,'',NULL,0),(675,'新华区','0',138,0,'',1,0,'',NULL,0),(676,'运河区','0',138,0,'',1,0,'',NULL,0),(677,'沧县','0',138,0,'',1,0,'',NULL,0),(678,'青县','0',138,0,'',1,0,'',NULL,0),(679,'东光县','0',138,0,'',1,0,'',NULL,0),(680,'海兴县','0',138,0,'',1,0,'',NULL,0),(681,'盐山县','0',138,0,'',1,0,'',NULL,0),(682,'肃宁县','0',138,0,'',1,0,'',NULL,0),(683,'南皮县','0',138,0,'',1,0,'',NULL,0),(684,'吴桥县','0',138,0,'',1,0,'',NULL,0),(685,'献县','0',138,0,'',1,0,'',NULL,0),(686,'孟村县','0',138,0,'',1,0,'',NULL,0),(687,'泊头市','0',138,0,'',1,0,'',NULL,0),(688,'任丘市','0',138,0,'',1,0,'',NULL,0),(689,'黄骅市','0',138,0,'',1,0,'',NULL,0),(690,'河间市','0',138,0,'',1,0,'',NULL,0),(691,'安次区','0',139,0,'',1,0,'',NULL,0),(692,'广阳区','0',139,0,'',1,0,'',NULL,0),(693,'固安县','0',139,0,'',1,0,'',NULL,0),(694,'永清县','0',139,0,'',1,0,'',NULL,0),(695,'香河县','0',139,0,'',1,0,'',NULL,0),(696,'大城县','0',139,0,'',1,0,'',NULL,0),(697,'文安县','0',139,0,'',1,0,'',NULL,0),(698,'大厂县','0',139,0,'',1,0,'',NULL,0),(699,'霸州市','0',139,0,'',1,0,'',NULL,0),(700,'三河市','0',139,0,'',1,0,'',NULL,0),(701,'桃城区','0',140,0,'',1,0,'',NULL,0),(702,'枣强县','0',140,0,'',1,0,'',NULL,0),(703,'武邑县','0',140,0,'',1,0,'',NULL,0),(704,'武强县','0',140,0,'',1,0,'',NULL,0),(705,'饶阳县','0',140,0,'',1,0,'',NULL,0),(706,'安平县','0',140,0,'',1,0,'',NULL,0),(707,'故城县','0',140,0,'',1,0,'',NULL,0),(708,'景县','0',140,0,'',1,0,'',NULL,0),(709,'阜城县','0',140,0,'',1,0,'',NULL,0),(710,'冀州市','0',140,0,'',1,0,'',NULL,0),(711,'深州市','0',140,0,'',1,0,'',NULL,0),(712,'小店区','0',141,0,'',1,0,'',NULL,0),(713,'迎泽区','0',141,0,'',1,0,'',NULL,0),(714,'杏花岭区','0',141,0,'',1,0,'',NULL,0),(715,'尖草坪区','0',141,0,'',1,0,'',NULL,0),(716,'万柏林区','0',141,0,'',1,0,'',NULL,0),(717,'晋源区','0',141,0,'',1,0,'',NULL,0),(718,'清徐县','0',141,0,'',1,0,'',NULL,0),(719,'阳曲县','0',141,0,'',1,0,'',NULL,0),(720,'娄烦县','0',141,0,'',1,0,'',NULL,0),(721,'古交市','0',141,0,'',1,0,'',NULL,0),(722,'城区','0',142,0,'',1,0,'',NULL,0),(723,'矿区','0',142,0,'',1,0,'',NULL,0),(724,'南郊区','0',142,0,'',1,0,'',NULL,0),(725,'新荣区','0',142,0,'',1,0,'',NULL,0),(726,'阳高县','0',142,0,'',1,0,'',NULL,0),(727,'天镇县','0',142,0,'',1,0,'',NULL,0),(728,'广灵县','0',142,0,'',1,0,'',NULL,0),(729,'灵丘县','0',142,0,'',1,0,'',NULL,0),(730,'浑源县','0',142,0,'',1,0,'',NULL,0),(731,'左云县','0',142,0,'',1,0,'',NULL,0),(732,'大同县','0',142,0,'',1,0,'',NULL,0),(733,'城区','0',143,0,'',1,0,'',NULL,0),(734,'矿区','0',143,0,'',1,0,'',NULL,0),(735,'郊区','0',143,0,'',1,0,'',NULL,0),(736,'平定县','0',143,0,'',1,0,'',NULL,0),(737,'盂县','0',143,0,'',1,0,'',NULL,0),(738,'城区','0',144,0,'',1,0,'',NULL,0),(739,'郊区','0',144,0,'',1,0,'',NULL,0),(740,'长治县','0',144,0,'',1,0,'',NULL,0),(741,'襄垣县','0',144,0,'',1,0,'',NULL,0),(742,'屯留县','0',144,0,'',1,0,'',NULL,0),(743,'平顺县','0',144,0,'',1,0,'',NULL,0),(744,'黎城县','0',144,0,'',1,0,'',NULL,0),(745,'壶关县','0',144,0,'',1,0,'',NULL,0),(746,'长子县','0',144,0,'',1,0,'',NULL,0),(747,'武乡县','0',144,0,'',1,0,'',NULL,0),(748,'沁县','0',144,0,'',1,0,'',NULL,0),(749,'沁源县','0',144,0,'',1,0,'',NULL,0),(750,'潞城市','0',144,0,'',1,0,'',NULL,0),(751,'城区','0',145,0,'',1,0,'',NULL,0),(752,'沁水县','0',145,0,'',1,0,'',NULL,0),(753,'阳城县','0',145,0,'',1,0,'',NULL,0),(754,'陵川县','0',145,0,'',1,0,'',NULL,0),(755,'泽州县','0',145,0,'',1,0,'',NULL,0),(756,'高平市','0',145,0,'',1,0,'',NULL,0),(757,'朔城区','0',146,0,'',1,0,'',NULL,0),(758,'平鲁区','0',146,0,'',1,0,'',NULL,0),(759,'山阴县','0',146,0,'',1,0,'',NULL,0),(760,'应县','0',146,0,'',1,0,'',NULL,0),(761,'右玉县','0',146,0,'',1,0,'',NULL,0),(762,'怀仁县','0',146,0,'',1,0,'',NULL,0),(763,'榆次区','0',147,0,'',1,0,'',NULL,0),(764,'榆社县','0',147,0,'',1,0,'',NULL,0),(765,'左权县','0',147,0,'',1,0,'',NULL,0),(766,'和顺县','0',147,0,'',1,0,'',NULL,0),(767,'昔阳县','0',147,0,'',1,0,'',NULL,0),(768,'寿阳县','0',147,0,'',1,0,'',NULL,0),(769,'太谷县','0',147,0,'',1,0,'',NULL,0),(770,'祁县','0',147,0,'',1,0,'',NULL,0),(771,'平遥县','0',147,0,'',1,0,'',NULL,0),(772,'灵石县','0',147,0,'',1,0,'',NULL,0),(773,'介休市','0',147,0,'',1,0,'',NULL,0),(774,'盐湖区','0',148,0,'',1,0,'',NULL,0),(775,'临猗县','0',148,0,'',1,0,'',NULL,0),(776,'万荣县','0',148,0,'',1,0,'',NULL,0),(777,'闻喜县','0',148,0,'',1,0,'',NULL,0),(778,'稷山县','0',148,0,'',1,0,'',NULL,0),(779,'新绛县','0',148,0,'',1,0,'',NULL,0),(780,'绛县','0',148,0,'',1,0,'',NULL,0),(781,'垣曲县','0',148,0,'',1,0,'',NULL,0),(782,'夏县','0',148,0,'',1,0,'',NULL,0),(783,'平陆县','0',148,0,'',1,0,'',NULL,0),(784,'芮城县','0',148,0,'',1,0,'',NULL,0),(785,'永济市','0',148,0,'',1,0,'',NULL,0),(786,'河津市','0',148,0,'',1,0,'',NULL,0),(787,'忻府区','0',149,0,'',1,0,'',NULL,0),(788,'定襄县','0',149,0,'',1,0,'',NULL,0),(789,'五台县','0',149,0,'',1,0,'',NULL,0),(790,'代县','0',149,0,'',1,0,'',NULL,0),(791,'繁峙县','0',149,0,'',1,0,'',NULL,0),(792,'宁武县','0',149,0,'',1,0,'',NULL,0),(793,'静乐县','0',149,0,'',1,0,'',NULL,0),(794,'神池县','0',149,0,'',1,0,'',NULL,0),(795,'五寨县','0',149,0,'',1,0,'',NULL,0),(796,'岢岚县','0',149,0,'',1,0,'',NULL,0),(797,'河曲县','0',149,0,'',1,0,'',NULL,0),(798,'保德县','0',149,0,'',1,0,'',NULL,0),(799,'偏关县','0',149,0,'',1,0,'',NULL,0),(800,'原平市','0',149,0,'',1,0,'',NULL,0),(801,'尧都区','0',150,0,'',1,0,'',NULL,0),(802,'曲沃县','0',150,0,'',1,0,'',NULL,0),(803,'翼城县','0',150,0,'',1,0,'',NULL,0),(804,'襄汾县','0',150,0,'',1,0,'',NULL,0),(805,'洪洞县','0',150,0,'',1,0,'',NULL,0),(806,'古县','0',150,0,'',1,0,'',NULL,0),(807,'安泽县','0',150,0,'',1,0,'',NULL,0),(808,'浮山县','0',150,0,'',1,0,'',NULL,0),(809,'吉县','0',150,0,'',1,0,'',NULL,0),(810,'乡宁县','0',150,0,'',1,0,'',NULL,0),(811,'大宁县','0',150,0,'',1,0,'',NULL,0),(812,'隰县','0',150,0,'',1,0,'',NULL,0),(813,'永和县','0',150,0,'',1,0,'',NULL,0),(814,'蒲县','0',150,0,'',1,0,'',NULL,0),(815,'汾西县','0',150,0,'',1,0,'',NULL,0),(816,'侯马市','0',150,0,'',1,0,'',NULL,0),(817,'霍州市','0',150,0,'',1,0,'',NULL,0),(818,'离石区','0',151,0,'',1,0,'',NULL,0),(819,'文水县','0',151,0,'',1,0,'',NULL,0),(820,'交城县','0',151,0,'',1,0,'',NULL,0),(821,'兴县','0',151,0,'',1,0,'',NULL,0),(822,'临县','0',151,0,'',1,0,'',NULL,0),(823,'柳林县','0',151,0,'',1,0,'',NULL,0),(824,'石楼县','0',151,0,'',1,0,'',NULL,0),(825,'岚县','0',151,0,'',1,0,'',NULL,0),(826,'方山县','0',151,0,'',1,0,'',NULL,0),(827,'中阳县','0',151,0,'',1,0,'',NULL,0),(828,'交口县','0',151,0,'',1,0,'',NULL,0),(829,'孝义市','0',151,0,'',1,0,'',NULL,0),(830,'汾阳市','0',151,0,'',1,0,'',NULL,0),(831,'新城区','0',152,0,'',1,0,'',NULL,0),(832,'回民区','0',152,0,'',1,0,'',NULL,0),(833,'玉泉区','0',152,0,'',1,0,'',NULL,0),(834,'赛罕区','0',152,0,'',1,0,'',NULL,0),(835,'土默特左旗','0',152,0,'',1,0,'',NULL,0),(836,'托克托县','0',152,0,'',1,0,'',NULL,0),(837,'和林格尔县','0',152,0,'',1,0,'',NULL,0),(838,'清水河县','0',152,0,'',1,0,'',NULL,0),(839,'武川县','0',152,0,'',1,0,'',NULL,0),(840,'东河区','0',153,0,'',1,0,'',NULL,0),(841,'昆都仑区','0',153,0,'',1,0,'',NULL,0),(842,'青山区','0',153,0,'',1,0,'',NULL,0),(843,'石拐区','0',153,0,'',1,0,'',NULL,0),(844,'白云矿区','0',153,0,'',1,0,'',NULL,0),(845,'九原区','0',153,0,'',1,0,'',NULL,0),(846,'土默特右旗','0',153,0,'',1,0,'',NULL,0),(847,'固阳县','0',153,0,'',1,0,'',NULL,0),(848,'达尔罕茂明安联合旗','0',153,0,'',1,0,'',NULL,0),(849,'海勃湾区','0',154,0,'',1,0,'',NULL,0),(850,'海南区','0',154,0,'',1,0,'',NULL,0),(851,'乌达区','0',154,0,'',1,0,'',NULL,0),(852,'红山区','0',155,0,'',1,0,'',NULL,0),(853,'元宝山区','0',155,0,'',1,0,'',NULL,0),(854,'松山区','0',155,0,'',1,0,'',NULL,0),(855,'阿鲁科尔沁旗','0',155,0,'',1,0,'',NULL,0),(856,'巴林左旗','0',155,0,'',1,0,'',NULL,0),(857,'巴林右旗','0',155,0,'',1,0,'',NULL,0),(858,'林西县','0',155,0,'',1,0,'',NULL,0),(859,'克什克腾旗','0',155,0,'',1,0,'',NULL,0),(860,'翁牛特旗','0',155,0,'',1,0,'',NULL,0),(861,'喀喇沁旗','0',155,0,'',1,0,'',NULL,0),(862,'宁城县','0',155,0,'',1,0,'',NULL,0),(863,'敖汉旗','0',155,0,'',1,0,'',NULL,0),(864,'科尔沁区','0',156,0,'',1,0,'',NULL,0),(865,'科尔沁左翼中旗','0',156,0,'',1,0,'',NULL,0),(866,'科尔沁左翼后旗','0',156,0,'',1,0,'',NULL,0),(867,'开鲁县','0',156,0,'',1,0,'',NULL,0),(868,'库伦旗','0',156,0,'',1,0,'',NULL,0),(869,'奈曼旗','0',156,0,'',1,0,'',NULL,0),(870,'扎鲁特旗','0',156,0,'',1,0,'',NULL,0),(871,'霍林郭勒市','0',156,0,'',1,0,'',NULL,0),(872,'东胜区','0',157,0,'',1,0,'',NULL,0),(873,'达拉特旗','0',157,0,'',1,0,'',NULL,0),(874,'准格尔旗','0',157,0,'',1,0,'',NULL,0),(875,'鄂托克前旗','0',157,0,'',1,0,'',NULL,0),(876,'鄂托克旗','0',157,0,'',1,0,'',NULL,0),(877,'杭锦旗','0',157,0,'',1,0,'',NULL,0),(878,'乌审旗','0',157,0,'',1,0,'',NULL,0),(879,'伊金霍洛旗','0',157,0,'',1,0,'',NULL,0),(880,'海拉尔区','0',158,0,'',1,0,'',NULL,0),(881,'阿荣旗','0',158,0,'',1,0,'',NULL,0),(882,'莫力达瓦达斡尔族自治旗','0',158,0,'',1,0,'',NULL,0),(883,'鄂伦春自治旗','0',158,0,'',1,0,'',NULL,0),(884,'鄂温克族自治旗','0',158,0,'',1,0,'',NULL,0),(885,'陈巴尔虎旗','0',158,0,'',1,0,'',NULL,0),(886,'新巴尔虎左旗','0',158,0,'',1,0,'',NULL,0),(887,'新巴尔虎右旗','0',158,0,'',1,0,'',NULL,0),(888,'满洲里市','0',158,0,'',1,0,'',NULL,0),(889,'牙克石市','0',158,0,'',1,0,'',NULL,0),(890,'扎兰屯市','0',158,0,'',1,0,'',NULL,0),(891,'额尔古纳市','0',158,0,'',1,0,'',NULL,0),(892,'根河市','0',158,0,'',1,0,'',NULL,0),(893,'临河区','0',159,0,'',1,0,'',NULL,0),(894,'五原县','0',159,0,'',1,0,'',NULL,0),(895,'磴口县','0',159,0,'',1,0,'',NULL,0),(896,'乌拉特前旗','0',159,0,'',1,0,'',NULL,0),(897,'乌拉特中旗','0',159,0,'',1,0,'',NULL,0),(898,'乌拉特后旗','0',159,0,'',1,0,'',NULL,0),(899,'杭锦后旗','0',159,0,'',1,0,'',NULL,0),(900,'集宁区','0',160,0,'',1,0,'',NULL,0),(901,'卓资县','0',160,0,'',1,0,'',NULL,0),(902,'化德县','0',160,0,'',1,0,'',NULL,0),(903,'商都县','0',160,0,'',1,0,'',NULL,0),(904,'兴和县','0',160,0,'',1,0,'',NULL,0),(905,'凉城县','0',160,0,'',1,0,'',NULL,0),(906,'察哈尔右翼前旗','0',160,0,'',1,0,'',NULL,0),(907,'察哈尔右翼中旗','0',160,0,'',1,0,'',NULL,0),(908,'察哈尔右翼后旗','0',160,0,'',1,0,'',NULL,0),(909,'四子王旗','0',160,0,'',1,0,'',NULL,0),(910,'丰镇市','0',160,0,'',1,0,'',NULL,0),(911,'乌兰浩特市','0',161,0,'',1,0,'',NULL,0),(912,'阿尔山市','0',161,0,'',1,0,'',NULL,0),(913,'科尔沁右翼前旗','0',161,0,'',1,0,'',NULL,0),(914,'科尔沁右翼中旗','0',161,0,'',1,0,'',NULL,0),(915,'扎赉特旗','0',161,0,'',1,0,'',NULL,0),(916,'突泉县','0',161,0,'',1,0,'',NULL,0),(917,'二连浩特市','0',162,0,'',1,0,'',NULL,0),(918,'锡林浩特市','0',162,0,'',1,0,'',NULL,0),(919,'阿巴嘎旗','0',162,0,'',1,0,'',NULL,0),(920,'苏尼特左旗','0',162,0,'',1,0,'',NULL,0),(921,'苏尼特右旗','0',162,0,'',1,0,'',NULL,0),(922,'东乌珠穆沁旗','0',162,0,'',1,0,'',NULL,0),(923,'西乌珠穆沁旗','0',162,0,'',1,0,'',NULL,0),(924,'太仆寺旗','0',162,0,'',1,0,'',NULL,0),(925,'镶黄旗','0',162,0,'',1,0,'',NULL,0),(926,'正镶白旗','0',162,0,'',1,0,'',NULL,0),(927,'正蓝旗','0',162,0,'',1,0,'',NULL,0),(928,'多伦县','0',162,0,'',1,0,'',NULL,0),(929,'阿拉善左旗','0',163,0,'',1,0,'',NULL,0),(930,'阿拉善右旗','0',163,0,'',1,0,'',NULL,0),(931,'额济纳旗','0',163,0,'',1,0,'',NULL,0),(932,'和平区','0',164,0,'',1,0,'',NULL,0),(933,'沈河区','0',164,0,'',1,0,'',NULL,0),(934,'大东区','0',164,0,'',1,0,'',NULL,0),(935,'皇姑区','0',164,0,'',1,0,'',NULL,0),(936,'铁西区','0',164,0,'',1,0,'',NULL,0),(937,'苏家屯区','0',164,0,'',1,0,'',NULL,0),(938,'东陵区','0',164,0,'',1,0,'',NULL,0),(939,'新城子区','0',164,0,'',1,0,'',NULL,0),(940,'于洪区','0',164,0,'',1,0,'',NULL,0),(941,'辽中县','0',164,0,'',1,0,'',NULL,0),(942,'康平县','0',164,0,'',1,0,'',NULL,0),(943,'法库县','0',164,0,'',1,0,'',NULL,0),(944,'新民市','0',164,0,'',1,0,'',NULL,0),(945,'中山区','0',165,0,'',1,0,'',NULL,0),(946,'西岗区','0',165,0,'',1,0,'',NULL,0),(947,'沙河口区','0',165,0,'',1,0,'',NULL,0),(948,'甘井子区','0',165,0,'',1,0,'',NULL,0),(949,'旅顺口区','0',165,0,'',1,0,'',NULL,0),(950,'金州区','0',165,0,'',1,0,'',NULL,0),(951,'长海县','0',165,0,'',1,0,'',NULL,0),(952,'瓦房店市','0',165,0,'',1,0,'',NULL,0),(953,'普兰店市','0',165,0,'',1,0,'',NULL,0),(954,'庄河市','0',165,0,'',1,0,'',NULL,0),(955,'铁东区','0',166,0,'',1,0,'',NULL,0),(956,'铁西区','0',166,0,'',1,0,'',NULL,0),(957,'立山区','0',166,0,'',1,0,'',NULL,0),(958,'千山区','0',166,0,'',1,0,'',NULL,0),(959,'台安县','0',166,0,'',1,0,'',NULL,0),(960,'岫岩满族自治县','0',166,0,'',1,0,'',NULL,0),(961,'海城市','0',166,0,'',1,0,'',NULL,0),(962,'新抚区','0',167,0,'',1,0,'',NULL,0),(963,'东洲区','0',167,0,'',1,0,'',NULL,0),(964,'望花区','0',167,0,'',1,0,'',NULL,0),(965,'顺城区','0',167,0,'',1,0,'',NULL,0),(966,'抚顺县','0',167,0,'',1,0,'',NULL,0),(967,'新宾满族自治县','0',167,0,'',1,0,'',NULL,0),(968,'清原满族自治县','0',167,0,'',1,0,'',NULL,0),(969,'平山区','0',168,0,'',1,0,'',NULL,0),(970,'溪湖区','0',168,0,'',1,0,'',NULL,0),(971,'明山区','0',168,0,'',1,0,'',NULL,0),(972,'南芬区','0',168,0,'',1,0,'',NULL,0),(973,'本溪满族自治县','0',168,0,'',1,0,'',NULL,0),(974,'桓仁满族自治县','0',168,0,'',1,0,'',NULL,0),(975,'元宝区','0',169,0,'',1,0,'',NULL,0),(976,'振兴区','0',169,0,'',1,0,'',NULL,0),(977,'振安区','0',169,0,'',1,0,'',NULL,0),(978,'宽甸满族自治县','0',169,0,'',1,0,'',NULL,0),(979,'东港市','0',169,0,'',1,0,'',NULL,0),(980,'凤城市','0',169,0,'',1,0,'',NULL,0),(981,'古塔区','0',170,0,'',1,0,'',NULL,0),(982,'凌河区','0',170,0,'',1,0,'',NULL,0),(983,'太和区','0',170,0,'',1,0,'',NULL,0),(984,'黑山县','0',170,0,'',1,0,'',NULL,0),(985,'义县','0',170,0,'',1,0,'',NULL,0),(986,'凌海市','0',170,0,'',1,0,'',NULL,0),(987,'北镇市','0',170,0,'',1,0,'',NULL,0),(988,'站前区','0',171,0,'',1,0,'',NULL,0),(989,'西市区','0',171,0,'',1,0,'',NULL,0),(990,'鲅鱼圈区','0',171,0,'',1,0,'',NULL,0),(991,'老边区','0',171,0,'',1,0,'',NULL,0),(992,'盖州市','0',171,0,'',1,0,'',NULL,0),(993,'大石桥市','0',171,0,'',1,0,'',NULL,0),(994,'海州区','0',172,0,'',1,0,'',NULL,0),(995,'新邱区','0',172,0,'',1,0,'',NULL,0),(996,'太平区','0',172,0,'',1,0,'',NULL,0),(997,'清河门区','0',172,0,'',1,0,'',NULL,0),(998,'细河区','0',172,0,'',1,0,'',NULL,0),(999,'阜新蒙古族自治县','0',172,0,'',1,0,'',NULL,0),(1000,'彰武县','0',172,0,'',1,0,'',NULL,0),(1001,'白塔区','0',173,0,'',1,0,'',NULL,0),(1002,'文圣区','0',173,0,'',1,0,'',NULL,0),(1003,'宏伟区','0',173,0,'',1,0,'',NULL,0),(1004,'弓长岭区','0',173,0,'',1,0,'',NULL,0),(1005,'太子河区','0',173,0,'',1,0,'',NULL,0),(1006,'辽阳县','0',173,0,'',1,0,'',NULL,0),(1007,'灯塔市','0',173,0,'',1,0,'',NULL,0),(1008,'双台子区','0',174,0,'',1,0,'',NULL,0),(1009,'兴隆台区','0',174,0,'',1,0,'',NULL,0),(1010,'大洼县','0',174,0,'',1,0,'',NULL,0),(1011,'盘山县','0',174,0,'',1,0,'',NULL,0),(1012,'银州区','0',175,0,'',1,0,'',NULL,0),(1013,'清河区','0',175,0,'',1,0,'',NULL,0),(1014,'铁岭县','0',175,0,'',1,0,'',NULL,0),(1015,'西丰县','0',175,0,'',1,0,'',NULL,0),(1016,'昌图县','0',175,0,'',1,0,'',NULL,0),(1017,'调兵山市','0',175,0,'',1,0,'',NULL,0),(1018,'开原市','0',175,0,'',1,0,'',NULL,0),(1019,'双塔区','0',176,0,'',1,0,'',NULL,0),(1020,'龙城区','0',176,0,'',1,0,'',NULL,0),(1021,'朝阳县','0',176,0,'',1,0,'',NULL,0),(1022,'建平县','0',176,0,'',1,0,'',NULL,0),(1023,'喀喇沁左翼蒙古族自治县','0',176,0,'',1,0,'',NULL,0),(1024,'北票市','0',176,0,'',1,0,'',NULL,0),(1025,'凌源市','0',176,0,'',1,0,'',NULL,0),(1026,'连山区','0',177,0,'',1,0,'',NULL,0),(1027,'龙港区','0',177,0,'',1,0,'',NULL,0),(1028,'南票区','0',177,0,'',1,0,'',NULL,0),(1029,'绥中县','0',177,0,'',1,0,'',NULL,0),(1030,'建昌县','0',177,0,'',1,0,'',NULL,0),(1031,'兴城市','0',177,0,'',1,0,'',NULL,0),(1032,'南关区','0',178,0,'',1,0,'',NULL,0),(1033,'宽城区','0',178,0,'',1,0,'',NULL,0),(1034,'朝阳区','0',178,0,'',1,0,'',NULL,0),(1035,'二道区','0',178,0,'',1,0,'',NULL,0),(1036,'绿园区','0',178,0,'',1,0,'',NULL,0),(1037,'双阳区','0',178,0,'',1,0,'',NULL,0),(1038,'农安县','0',178,0,'',1,0,'',NULL,0),(1039,'九台市','0',178,0,'',1,0,'',NULL,0),(1040,'榆树市','0',178,0,'',1,0,'',NULL,0),(1041,'德惠市','0',178,0,'',1,0,'',NULL,0),(1042,'昌邑区','0',179,0,'',1,0,'',NULL,0),(1043,'龙潭区','0',179,0,'',1,0,'',NULL,0),(1044,'船营区','0',179,0,'',1,0,'',NULL,0),(1045,'丰满区','0',179,0,'',1,0,'',NULL,0),(1046,'永吉县','0',179,0,'',1,0,'',NULL,0),(1047,'蛟河市','0',179,0,'',1,0,'',NULL,0),(1048,'桦甸市','0',179,0,'',1,0,'',NULL,0),(1049,'舒兰市','0',179,0,'',1,0,'',NULL,0),(1050,'磐石市','0',179,0,'',1,0,'',NULL,0),(1051,'铁西区','0',180,0,'',1,0,'',NULL,0),(1052,'铁东区','0',180,0,'',1,0,'',NULL,0),(1053,'梨树县','0',180,0,'',1,0,'',NULL,0),(1054,'伊通满族自治县','0',180,0,'',1,0,'',NULL,0),(1055,'公主岭市','0',180,0,'',1,0,'',NULL,0),(1056,'双辽市','0',180,0,'',1,0,'',NULL,0),(1057,'龙山区','0',181,0,'',1,0,'',NULL,0),(1058,'西安区','0',181,0,'',1,0,'',NULL,0),(1059,'东丰县','0',181,0,'',1,0,'',NULL,0),(1060,'东辽县','0',181,0,'',1,0,'',NULL,0),(1061,'东昌区','0',182,0,'',1,0,'',NULL,0),(1062,'二道江区','0',182,0,'',1,0,'',NULL,0),(1063,'通化县','0',182,0,'',1,0,'',NULL,0),(1064,'辉南县','0',182,0,'',1,0,'',NULL,0),(1065,'柳河县','0',182,0,'',1,0,'',NULL,0),(1066,'梅河口市','0',182,0,'',1,0,'',NULL,0),(1067,'集安市','0',182,0,'',1,0,'',NULL,0),(1068,'八道江区','0',183,0,'',1,0,'',NULL,0),(1069,'抚松县','0',183,0,'',1,0,'',NULL,0),(1070,'靖宇县','0',183,0,'',1,0,'',NULL,0),(1071,'长白朝鲜族自治县','0',183,0,'',1,0,'',NULL,0),(1072,'江源县','0',183,0,'',1,0,'',NULL,0),(1073,'临江市','0',183,0,'',1,0,'',NULL,0),(1074,'宁江区','0',184,0,'',1,0,'',NULL,0),(1075,'前郭尔罗斯蒙古族自治县','0',184,0,'',1,0,'',NULL,0),(1076,'长岭县','0',184,0,'',1,0,'',NULL,0),(1077,'乾安县','0',184,0,'',1,0,'',NULL,0),(1078,'扶余县','0',184,0,'',1,0,'',NULL,0),(1079,'洮北区','0',185,0,'',1,0,'',NULL,0),(1080,'镇赉县','0',185,0,'',1,0,'',NULL,0),(1081,'通榆县','0',185,0,'',1,0,'',NULL,0),(1082,'洮南市','0',185,0,'',1,0,'',NULL,0),(1083,'大安市','0',185,0,'',1,0,'',NULL,0),(1084,'延吉市','0',186,0,'',1,0,'',NULL,0),(1085,'图们市','0',186,0,'',1,0,'',NULL,0),(1086,'敦化市','0',186,0,'',1,0,'',NULL,0),(1087,'珲春市','0',186,0,'',1,0,'',NULL,0),(1088,'龙井市','0',186,0,'',1,0,'',NULL,0),(1089,'和龙市','0',186,0,'',1,0,'',NULL,0),(1090,'汪清县','0',186,0,'',1,0,'',NULL,0),(1091,'安图县','0',186,0,'',1,0,'',NULL,0),(1092,'道里区','0',187,0,'',1,0,'',NULL,0),(1093,'南岗区','0',187,0,'',1,0,'',NULL,0),(1094,'道外区','0',187,0,'',1,0,'',NULL,0),(1095,'香坊区','0',187,0,'',1,0,'',NULL,0),(1096,'动力区','0',187,0,'',1,0,'',NULL,0),(1097,'平房区','0',187,0,'',1,0,'',NULL,0),(1098,'松北区','0',187,0,'',1,0,'',NULL,0),(1099,'呼兰区','0',187,0,'',1,0,'',NULL,0),(1100,'依兰县','0',187,0,'',1,0,'',NULL,0),(1101,'方正县','0',187,0,'',1,0,'',NULL,0),(1102,'宾县','0',187,0,'',1,0,'',NULL,0),(1103,'巴彦县','0',187,0,'',1,0,'',NULL,0),(1104,'木兰县','0',187,0,'',1,0,'',NULL,0),(1105,'通河县','0',187,0,'',1,0,'',NULL,0),(1106,'延寿县','0',187,0,'',1,0,'',NULL,0),(1107,'阿城市','0',187,0,'',1,0,'',NULL,0),(1108,'双城市','0',187,0,'',1,0,'',NULL,0),(1109,'尚志市','0',187,0,'',1,0,'',NULL,0),(1110,'五常市','0',187,0,'',1,0,'',NULL,0),(1111,'龙沙区','0',188,0,'',1,0,'',NULL,0),(1112,'建华区','0',188,0,'',1,0,'',NULL,0),(1113,'铁锋区','0',188,0,'',1,0,'',NULL,0),(1114,'昂昂溪区','0',188,0,'',1,0,'',NULL,0),(1115,'富拉尔基区','0',188,0,'',1,0,'',NULL,0),(1116,'碾子山区','0',188,0,'',1,0,'',NULL,0),(1117,'梅里斯达斡尔族区','0',188,0,'',1,0,'',NULL,0),(1118,'龙江县','0',188,0,'',1,0,'',NULL,0),(1119,'依安县','0',188,0,'',1,0,'',NULL,0),(1120,'泰来县','0',188,0,'',1,0,'',NULL,0),(1121,'甘南县','0',188,0,'',1,0,'',NULL,0),(1122,'富裕县','0',188,0,'',1,0,'',NULL,0),(1123,'克山县','0',188,0,'',1,0,'',NULL,0),(1124,'克东县','0',188,0,'',1,0,'',NULL,0),(1125,'拜泉县','0',188,0,'',1,0,'',NULL,0),(1126,'讷河市','0',188,0,'',1,0,'',NULL,0),(1127,'鸡冠区','0',189,0,'',1,0,'',NULL,0),(1128,'恒山区','0',189,0,'',1,0,'',NULL,0),(1129,'滴道区','0',189,0,'',1,0,'',NULL,0),(1130,'梨树区','0',189,0,'',1,0,'',NULL,0),(1131,'城子河区','0',189,0,'',1,0,'',NULL,0),(1132,'麻山区','0',189,0,'',1,0,'',NULL,0),(1133,'鸡东县','0',189,0,'',1,0,'',NULL,0),(1134,'虎林市','0',189,0,'',1,0,'',NULL,0),(1135,'密山市','0',189,0,'',1,0,'',NULL,0),(1136,'向阳区','0',190,0,'',1,0,'',NULL,0),(1137,'工农区','0',190,0,'',1,0,'',NULL,0),(1138,'南山区','0',190,0,'',1,0,'',NULL,0),(1139,'兴安区','0',190,0,'',1,0,'',NULL,0),(1140,'东山区','0',190,0,'',1,0,'',NULL,0),(1141,'兴山区','0',190,0,'',1,0,'',NULL,0),(1142,'萝北县','0',190,0,'',1,0,'',NULL,0),(1143,'绥滨县','0',190,0,'',1,0,'',NULL,0),(1144,'尖山区','0',191,0,'',1,0,'',NULL,0),(1145,'岭东区','0',191,0,'',1,0,'',NULL,0),(1146,'四方台区','0',191,0,'',1,0,'',NULL,0),(1147,'宝山区','0',191,0,'',1,0,'',NULL,0),(1148,'集贤县','0',191,0,'',1,0,'',NULL,0),(1149,'友谊县','0',191,0,'',1,0,'',NULL,0),(1150,'宝清县','0',191,0,'',1,0,'',NULL,0),(1151,'饶河县','0',191,0,'',1,0,'',NULL,0),(1152,'萨尔图区','0',192,0,'',1,0,'',NULL,0),(1153,'龙凤区','0',192,0,'',1,0,'',NULL,0),(1154,'让胡路区','0',192,0,'',1,0,'',NULL,0),(1155,'红岗区','0',192,0,'',1,0,'',NULL,0),(1156,'大同区','0',192,0,'',1,0,'',NULL,0),(1157,'肇州县','0',192,0,'',1,0,'',NULL,0),(1158,'肇源县','0',192,0,'',1,0,'',NULL,0),(1159,'林甸县','0',192,0,'',1,0,'',NULL,0),(1160,'杜尔伯特蒙古族自治县','0',192,0,'',1,0,'',NULL,0),(1161,'伊春区','0',193,0,'',1,0,'',NULL,0),(1162,'南岔区','0',193,0,'',1,0,'',NULL,0),(1163,'友好区','0',193,0,'',1,0,'',NULL,0),(1164,'西林区','0',193,0,'',1,0,'',NULL,0),(1165,'翠峦区','0',193,0,'',1,0,'',NULL,0),(1166,'新青区','0',193,0,'',1,0,'',NULL,0),(1167,'美溪区','0',193,0,'',1,0,'',NULL,0),(1168,'金山屯区','0',193,0,'',1,0,'',NULL,0),(1169,'五营区','0',193,0,'',1,0,'',NULL,0),(1170,'乌马河区','0',193,0,'',1,0,'',NULL,0),(1171,'汤旺河区','0',193,0,'',1,0,'',NULL,0),(1172,'带岭区','0',193,0,'',1,0,'',NULL,0),(1173,'乌伊岭区','0',193,0,'',1,0,'',NULL,0),(1174,'红星区','0',193,0,'',1,0,'',NULL,0),(1175,'上甘岭区','0',193,0,'',1,0,'',NULL,0),(1176,'嘉荫县','0',193,0,'',1,0,'',NULL,0),(1177,'铁力市','0',193,0,'',1,0,'',NULL,0),(1178,'永红区','0',194,0,'',1,0,'',NULL,0),(1179,'向阳区','0',194,0,'',1,0,'',NULL,0),(1180,'前进区','0',194,0,'',1,0,'',NULL,0),(1181,'东风区','0',194,0,'',1,0,'',NULL,0),(1182,'郊区','0',194,0,'',1,0,'',NULL,0),(1183,'桦南县','0',194,0,'',1,0,'',NULL,0),(1184,'桦川县','0',194,0,'',1,0,'',NULL,0),(1185,'汤原县','0',194,0,'',1,0,'',NULL,0),(1186,'抚远县','0',194,0,'',1,0,'',NULL,0),(1187,'同江市','0',194,0,'',1,0,'',NULL,0),(1188,'富锦市','0',194,0,'',1,0,'',NULL,0),(1189,'新兴区','0',195,0,'',1,0,'',NULL,0),(1190,'桃山区','0',195,0,'',1,0,'',NULL,0),(1191,'茄子河区','0',195,0,'',1,0,'',NULL,0),(1192,'勃利县','0',195,0,'',1,0,'',NULL,0),(1193,'东安区','0',196,0,'',1,0,'',NULL,0),(1194,'阳明区','0',196,0,'',1,0,'',NULL,0),(1195,'爱民区','0',196,0,'',1,0,'',NULL,0),(1196,'西安区','0',196,0,'',1,0,'',NULL,0),(1197,'东宁县','0',196,0,'',1,0,'',NULL,0),(1198,'林口县','0',196,0,'',1,0,'',NULL,0),(1199,'绥芬河市','0',196,0,'',1,0,'',NULL,0),(1200,'海林市','0',196,0,'',1,0,'',NULL,0),(1201,'宁安市','0',196,0,'',1,0,'',NULL,0),(1202,'穆棱市','0',196,0,'',1,0,'',NULL,0),(1203,'爱辉区','0',197,0,'',1,0,'',NULL,0),(1204,'嫩江县','0',197,0,'',1,0,'',NULL,0),(1205,'逊克县','0',197,0,'',1,0,'',NULL,0),(1206,'孙吴县','0',197,0,'',1,0,'',NULL,0),(1207,'北安市','0',197,0,'',1,0,'',NULL,0),(1208,'五大连池市','0',197,0,'',1,0,'',NULL,0),(1209,'北林区','0',198,0,'',1,0,'',NULL,0),(1210,'望奎县','0',198,0,'',1,0,'',NULL,0),(1211,'兰西县','0',198,0,'',1,0,'',NULL,0),(1212,'青冈县','0',198,0,'',1,0,'',NULL,0),(1213,'庆安县','0',198,0,'',1,0,'',NULL,0),(1214,'明水县','0',198,0,'',1,0,'',NULL,0),(1215,'绥棱县','0',198,0,'',1,0,'',NULL,0),(1216,'安达市','0',198,0,'',1,0,'',NULL,0),(1217,'肇东市','0',198,0,'',1,0,'',NULL,0),(1218,'海伦市','0',198,0,'',1,0,'',NULL,0),(1219,'呼玛县','0',199,0,'',1,0,'',NULL,0),(1220,'塔河县','0',199,0,'',1,0,'',NULL,0),(1221,'漠河县','0',199,0,'',1,0,'',NULL,0),(1222,'玄武区','0',200,0,'',1,0,'',NULL,0),(1223,'白下区','0',200,0,'',1,0,'',NULL,0),(1224,'秦淮区','0',200,0,'',1,0,'',NULL,0),(1225,'建邺区','0',200,0,'',1,0,'',NULL,0),(1226,'鼓楼区','0',200,0,'',1,0,'',NULL,0),(1227,'下关区','0',200,0,'',1,0,'',NULL,0),(1228,'浦口区','0',200,0,'',1,0,'',NULL,0),(1229,'栖霞区','0',200,0,'',1,0,'',NULL,0),(1230,'雨花台区','0',200,0,'',1,0,'',NULL,0),(1231,'江宁区','0',200,0,'',1,0,'',NULL,0),(1232,'六合区','0',200,0,'',1,0,'',NULL,0),(1233,'溧水县','0',200,0,'',1,0,'',NULL,0),(1234,'高淳县','0',200,0,'',1,0,'',NULL,0),(1235,'崇安区','0',201,0,'',1,0,'',NULL,0),(1236,'南长区','0',201,0,'',1,0,'',NULL,0),(1237,'北塘区','0',201,0,'',1,0,'',NULL,0),(1238,'锡山区','0',201,0,'',1,0,'',NULL,0),(1239,'惠山区','0',201,0,'',1,0,'',NULL,0),(1240,'滨湖区','0',201,0,'',1,0,'',NULL,0),(1241,'江阴市','0',201,0,'',1,0,'',NULL,0),(1242,'宜兴市','0',201,0,'',1,0,'',NULL,0),(1243,'鼓楼区','0',202,0,'',1,0,'',NULL,0),(1244,'云龙区','0',202,0,'',1,0,'',NULL,0),(1245,'九里区','0',202,0,'',1,0,'',NULL,0),(1246,'贾汪区','0',202,0,'',1,0,'',NULL,0),(1247,'泉山区','0',202,0,'',1,0,'',NULL,0),(1248,'丰县','0',202,0,'',1,0,'',NULL,0),(1249,'沛县','0',202,0,'',1,0,'',NULL,0),(1250,'铜山县','0',202,0,'',1,0,'',NULL,0),(1251,'睢宁县','0',202,0,'',1,0,'',NULL,0),(1252,'新沂市','0',202,0,'',1,0,'',NULL,0),(1253,'邳州市','0',202,0,'',1,0,'',NULL,0),(1254,'天宁区','0',203,0,'',1,0,'',NULL,0),(1255,'钟楼区','0',203,0,'',1,0,'',NULL,0),(1256,'戚墅堰区','0',203,0,'',1,0,'',NULL,0),(1257,'新北区','0',203,0,'',1,0,'',NULL,0),(1258,'武进区','0',203,0,'',1,0,'',NULL,0),(1259,'溧阳市','0',203,0,'',1,0,'',NULL,0),(1260,'金坛市','0',203,0,'',1,0,'',NULL,0),(1261,'沧浪区','0',204,0,'',1,0,'',NULL,0),(1262,'平江区','0',204,0,'',1,0,'',NULL,0),(1263,'金阊区','0',204,0,'',1,0,'',NULL,0),(1264,'虎丘区','0',204,0,'',1,0,'',NULL,0),(1265,'吴中区','0',204,0,'',1,0,'',NULL,0),(1266,'相城区','0',204,0,'',1,0,'',NULL,0),(1267,'常熟市','0',204,0,'',1,0,'',NULL,0),(1268,'张家港市','0',204,0,'',1,0,'',NULL,0),(1269,'昆山市','0',204,0,'',1,0,'',NULL,0),(1270,'吴江市','0',204,0,'',1,0,'',NULL,0),(1271,'太仓市','0',204,0,'',1,0,'',NULL,0),(1272,'崇川区','0',205,0,'',1,0,'',NULL,0),(1273,'港闸区','0',205,0,'',1,0,'',NULL,0),(1274,'海安县','0',205,0,'',1,0,'',NULL,0),(1275,'如东县','0',205,0,'',1,0,'',NULL,0),(1276,'启东市','0',205,0,'',1,0,'',NULL,0),(1277,'如皋市','0',205,0,'',1,0,'',NULL,0),(1278,'通州市','0',205,0,'',1,0,'',NULL,0),(1279,'海门市','0',205,0,'',1,0,'',NULL,0),(1280,'连云区','0',206,0,'',1,0,'',NULL,0),(1281,'新浦区','0',206,0,'',1,0,'',NULL,0),(1282,'海州区','0',206,0,'',1,0,'',NULL,0),(1283,'赣榆县','0',206,0,'',1,0,'',NULL,0),(1284,'东海县','0',206,0,'',1,0,'',NULL,0),(1285,'灌云县','0',206,0,'',1,0,'',NULL,0),(1286,'灌南县','0',206,0,'',1,0,'',NULL,0),(1287,'清河区','0',207,0,'',1,0,'',NULL,0),(1288,'楚州区','0',207,0,'',1,0,'',NULL,0),(1289,'淮阴区','0',207,0,'',1,0,'',NULL,0),(1290,'清浦区','0',207,0,'',1,0,'',NULL,0),(1291,'涟水县','0',207,0,'',1,0,'',NULL,0),(1292,'洪泽县','0',207,0,'',1,0,'',NULL,0),(1293,'盱眙县','0',207,0,'',1,0,'',NULL,0),(1294,'金湖县','0',207,0,'',1,0,'',NULL,0),(1295,'亭湖区','0',208,0,'',1,0,'',NULL,0),(1296,'盐都区','0',208,0,'',1,0,'',NULL,0),(1297,'响水县','0',208,0,'',1,0,'',NULL,0),(1298,'滨海县','0',208,0,'',1,0,'',NULL,0),(1299,'阜宁县','0',208,0,'',1,0,'',NULL,0),(1300,'射阳县','0',208,0,'',1,0,'',NULL,0),(1301,'建湖县','0',208,0,'',1,0,'',NULL,0),(1302,'东台市','0',208,0,'',1,0,'',NULL,0),(1303,'大丰市','0',208,0,'',1,0,'',NULL,0),(1304,'广陵区','0',209,0,'',1,0,'',NULL,0),(1305,'邗江区','0',209,0,'',1,0,'',NULL,0),(1306,'维扬区','0',209,0,'',1,0,'',NULL,0),(1307,'宝应县','0',209,0,'',1,0,'',NULL,0),(1308,'仪征市','0',209,0,'',1,0,'',NULL,0),(1309,'高邮市','0',209,0,'',1,0,'',NULL,0),(1310,'江都市','0',209,0,'',1,0,'',NULL,0),(1311,'京口区','0',210,0,'',1,0,'',NULL,0),(1312,'润州区','0',210,0,'',1,0,'',NULL,0),(1313,'丹徒区','0',210,0,'',1,0,'',NULL,0),(1314,'丹阳市','0',210,0,'',1,0,'',NULL,0),(1315,'扬中市','0',210,0,'',1,0,'',NULL,0),(1316,'句容市','0',210,0,'',1,0,'',NULL,0),(1317,'海陵区','0',211,0,'',1,0,'',NULL,0),(1318,'高港区','0',211,0,'',1,0,'',NULL,0),(1319,'兴化市','0',211,0,'',1,0,'',NULL,0),(1320,'靖江市','0',211,0,'',1,0,'',NULL,0),(1321,'泰兴市','0',211,0,'',1,0,'',NULL,0),(1322,'姜堰市','0',211,0,'',1,0,'',NULL,0),(1323,'宿城区','0',212,0,'',1,0,'',NULL,0),(1324,'宿豫区','0',212,0,'',1,0,'',NULL,0),(1325,'沭阳县','0',212,0,'',1,0,'',NULL,0),(1326,'泗阳县','0',212,0,'',1,0,'',NULL,0),(1327,'泗洪县','0',212,0,'',1,0,'',NULL,0),(1328,'上城区','0',213,0,'',1,0,'',NULL,0),(1329,'下城区','0',213,0,'',1,0,'',NULL,0),(1330,'江干区','0',213,0,'',1,0,'',NULL,0),(1331,'拱墅区','0',213,0,'',1,0,'',NULL,0),(1332,'西湖区','0',213,0,'',1,0,'',NULL,0),(1333,'滨江区','0',213,0,'',1,0,'',NULL,0),(1334,'萧山区','0',213,0,'',1,0,'',NULL,0),(1335,'余杭区','0',213,0,'',1,0,'',NULL,0),(1336,'桐庐县','0',213,0,'',1,0,'',NULL,0),(1337,'淳安县','0',213,0,'',1,0,'',NULL,0),(1338,'建德市','0',213,0,'',1,0,'',NULL,0),(1339,'富阳市','0',213,0,'',1,0,'',NULL,0),(1340,'临安市','0',213,0,'',1,0,'',NULL,0),(1341,'海曙区','0',214,0,'',1,0,'',NULL,0),(1342,'江东区','0',214,0,'',1,0,'',NULL,0),(1343,'江北区','0',214,0,'',1,0,'',NULL,0),(1344,'北仑区','0',214,0,'',1,0,'',NULL,0),(1345,'镇海区','0',214,0,'',1,0,'',NULL,0),(1346,'鄞州区','0',214,0,'',1,0,'',NULL,0),(1347,'象山县','0',214,0,'',1,0,'',NULL,0),(1348,'宁海县','0',214,0,'',1,0,'',NULL,0),(1349,'余姚市','0',214,0,'',1,0,'',NULL,0),(1350,'慈溪市','0',214,0,'',1,0,'',NULL,0),(1351,'奉化市','0',214,0,'',1,0,'',NULL,0),(1352,'鹿城区','0',215,0,'',1,0,'',NULL,0),(1353,'龙湾区','0',215,0,'',1,0,'',NULL,0),(1354,'瓯海区','0',215,0,'',1,0,'',NULL,0),(1355,'洞头县','0',215,0,'',1,0,'',NULL,0),(1356,'永嘉县','0',215,0,'',1,0,'',NULL,0),(1357,'平阳县','0',215,0,'',1,0,'',NULL,0),(1358,'苍南县','0',215,0,'',1,0,'',NULL,0),(1359,'文成县','0',215,0,'',1,0,'',NULL,0),(1360,'泰顺县','0',215,0,'',1,0,'',NULL,0),(1361,'瑞安市','0',215,0,'',1,0,'',NULL,0),(1362,'乐清市','0',215,0,'',1,0,'',NULL,0),(1363,'秀城区','0',216,0,'',1,0,'',NULL,0),(1364,'秀洲区','0',216,0,'',1,0,'',NULL,0),(1365,'嘉善县','0',216,0,'',1,0,'',NULL,0),(1366,'海盐县','0',216,0,'',1,0,'',NULL,0),(1367,'海宁市','0',216,0,'',1,0,'',NULL,0),(1368,'平湖市','0',216,0,'',1,0,'',NULL,0),(1369,'桐乡市','0',216,0,'',1,0,'',NULL,0),(1370,'吴兴区','0',217,0,'',1,0,'',NULL,0),(1371,'南浔区','0',217,0,'',1,0,'',NULL,0),(1372,'德清县','0',217,0,'',1,0,'',NULL,0),(1373,'长兴县','0',217,0,'',1,0,'',NULL,0),(1374,'安吉县','0',217,0,'',1,0,'',NULL,0),(1375,'越城区','0',218,0,'',1,0,'',NULL,0),(1376,'绍兴县','0',218,0,'',1,0,'',NULL,0),(1377,'新昌县','0',218,0,'',1,0,'',NULL,0),(1378,'诸暨市','0',218,0,'',1,0,'',NULL,0),(1379,'上虞市','0',218,0,'',1,0,'',NULL,0),(1380,'嵊州市','0',218,0,'',1,0,'',NULL,0),(1381,'婺城区','0',219,0,'',1,0,'',NULL,0),(1382,'金东区','0',219,0,'',1,0,'',NULL,0),(1383,'武义县','0',219,0,'',1,0,'',NULL,0),(1384,'浦江县','0',219,0,'',1,0,'',NULL,0),(1385,'磐安县','0',219,0,'',1,0,'',NULL,0),(1386,'兰溪市','0',219,0,'',1,0,'',NULL,0),(1387,'义乌市','0',219,0,'',1,0,'',NULL,0),(1388,'东阳市','0',219,0,'',1,0,'',NULL,0),(1389,'永康市','0',219,0,'',1,0,'',NULL,0),(1390,'柯城区','0',220,0,'',1,0,'',NULL,0),(1391,'衢江区','0',220,0,'',1,0,'',NULL,0),(1392,'常山县','0',220,0,'',1,0,'',NULL,0),(1393,'开化县','0',220,0,'',1,0,'',NULL,0),(1394,'龙游县','0',220,0,'',1,0,'',NULL,0),(1395,'江山市','0',220,0,'',1,0,'',NULL,0),(1396,'定海区','0',221,0,'',1,0,'',NULL,0),(1397,'普陀区','0',221,0,'',1,0,'',NULL,0),(1398,'岱山县','0',221,0,'',1,0,'',NULL,0),(1399,'嵊泗县','0',221,0,'',1,0,'',NULL,0),(1400,'椒江区','0',222,0,'',1,0,'',NULL,0),(1401,'黄岩区','0',222,0,'',1,0,'',NULL,0),(1402,'路桥区','0',222,0,'',1,0,'',NULL,0),(1403,'玉环县','0',222,0,'',1,0,'',NULL,0),(1404,'三门县','0',222,0,'',1,0,'',NULL,0),(1405,'天台县','0',222,0,'',1,0,'',NULL,0),(1406,'仙居县','0',222,0,'',1,0,'',NULL,0),(1407,'温岭市','0',222,0,'',1,0,'',NULL,0),(1408,'临海市','0',222,0,'',1,0,'',NULL,0),(1409,'莲都区','0',223,0,'',1,0,'',NULL,0),(1410,'青田县','0',223,0,'',1,0,'',NULL,0),(1411,'缙云县','0',223,0,'',1,0,'',NULL,0),(1412,'遂昌县','0',223,0,'',1,0,'',NULL,0),(1413,'松阳县','0',223,0,'',1,0,'',NULL,0),(1414,'云和县','0',223,0,'',1,0,'',NULL,0),(1415,'庆元县','0',223,0,'',1,0,'',NULL,0),(1416,'景宁畲族自治县','0',223,0,'',1,0,'',NULL,0),(1417,'龙泉市','0',223,0,'',1,0,'',NULL,0),(1418,'瑶海区','0',224,0,'',1,0,'',NULL,0),(1419,'庐阳区','0',224,0,'',1,0,'',NULL,0),(1420,'蜀山区','0',224,0,'',1,0,'',NULL,0),(1421,'包河区','0',224,0,'',1,0,'',NULL,0),(1422,'长丰县','0',224,0,'',1,0,'',NULL,0),(1423,'肥东县','0',224,0,'',1,0,'',NULL,0),(1424,'肥西县','0',224,0,'',1,0,'',NULL,0),(1425,'镜湖区','0',225,0,'',1,0,'',NULL,0),(1426,'弋江区','0',225,0,'',1,0,'',NULL,0),(1427,'鸠江区','0',225,0,'',1,0,'',NULL,0),(1428,'三山区','0',225,0,'',1,0,'',NULL,0),(1429,'芜湖县','0',225,0,'',1,0,'',NULL,0),(1430,'繁昌县','0',225,0,'',1,0,'',NULL,0),(1431,'南陵县','0',225,0,'',1,0,'',NULL,0),(1432,'龙子湖区','0',226,0,'',1,0,'',NULL,0),(1433,'蚌山区','0',226,0,'',1,0,'',NULL,0),(1434,'禹会区','0',226,0,'',1,0,'',NULL,0),(1435,'淮上区','0',226,0,'',1,0,'',NULL,0),(1436,'怀远县','0',226,0,'',1,0,'',NULL,0),(1437,'五河县','0',226,0,'',1,0,'',NULL,0),(1438,'固镇县','0',226,0,'',1,0,'',NULL,0),(1439,'大通区','0',227,0,'',1,0,'',NULL,0),(1440,'田家庵区','0',227,0,'',1,0,'',NULL,0),(1441,'谢家集区','0',227,0,'',1,0,'',NULL,0),(1442,'八公山区','0',227,0,'',1,0,'',NULL,0),(1443,'潘集区','0',227,0,'',1,0,'',NULL,0),(1444,'凤台县','0',227,0,'',1,0,'',NULL,0),(1445,'金家庄区','0',228,0,'',1,0,'',NULL,0),(1446,'花山区','0',228,0,'',1,0,'',NULL,0),(1447,'雨山区','0',228,0,'',1,0,'',NULL,0),(1448,'当涂县','0',228,0,'',1,0,'',NULL,0),(1449,'杜集区','0',229,0,'',1,0,'',NULL,0),(1450,'相山区','0',229,0,'',1,0,'',NULL,0),(1451,'烈山区','0',229,0,'',1,0,'',NULL,0),(1452,'濉溪县','0',229,0,'',1,0,'',NULL,0),(1453,'铜官山区','0',230,0,'',1,0,'',NULL,0),(1454,'狮子山区','0',230,0,'',1,0,'',NULL,0),(1455,'郊区','0',230,0,'',1,0,'',NULL,0),(1456,'铜陵县','0',230,0,'',1,0,'',NULL,0),(1457,'迎江区','0',231,0,'',1,0,'',NULL,0),(1458,'大观区','0',231,0,'',1,0,'',NULL,0),(1459,'宜秀区','0',231,0,'',1,0,'',NULL,0),(1460,'怀宁县','0',231,0,'',1,0,'',NULL,0),(1461,'枞阳县','0',231,0,'',1,0,'',NULL,0),(1462,'潜山县','0',231,0,'',1,0,'',NULL,0),(1463,'太湖县','0',231,0,'',1,0,'',NULL,0),(1464,'宿松县','0',231,0,'',1,0,'',NULL,0),(1465,'望江县','0',231,0,'',1,0,'',NULL,0),(1466,'岳西县','0',231,0,'',1,0,'',NULL,0),(1467,'桐城市','0',231,0,'',1,0,'',NULL,0),(1468,'屯溪区','0',232,0,'',1,0,'',NULL,0),(1469,'黄山区','0',232,0,'',1,0,'',NULL,0),(1470,'徽州区','0',232,0,'',1,0,'',NULL,0),(1471,'歙县','0',232,0,'',1,0,'',NULL,0),(1472,'休宁县','0',232,0,'',1,0,'',NULL,0),(1473,'黟县','0',232,0,'',1,0,'',NULL,0),(1474,'祁门县','0',232,0,'',1,0,'',NULL,0),(1475,'琅琊区','0',233,0,'',1,0,'',NULL,0),(1476,'南谯区','0',233,0,'',1,0,'',NULL,0),(1477,'来安县','0',233,0,'',1,0,'',NULL,0),(1478,'全椒县','0',233,0,'',1,0,'',NULL,0),(1479,'定远县','0',233,0,'',1,0,'',NULL,0),(1480,'凤阳县','0',233,0,'',1,0,'',NULL,0),(1481,'天长市','0',233,0,'',1,0,'',NULL,0),(1482,'明光市','0',233,0,'',1,0,'',NULL,0),(1483,'颍州区','0',234,0,'',1,0,'',NULL,0),(1484,'颍东区','0',234,0,'',1,0,'',NULL,0),(1485,'颍泉区','0',234,0,'',1,0,'',NULL,0),(1486,'临泉县','0',234,0,'',1,0,'',NULL,0),(1487,'太和县','0',234,0,'',1,0,'',NULL,0),(1488,'阜南县','0',234,0,'',1,0,'',NULL,0),(1489,'颍上县','0',234,0,'',1,0,'',NULL,0),(1490,'界首市','0',234,0,'',1,0,'',NULL,0),(1491,'埇桥区','0',235,0,'',1,0,'',NULL,0),(1492,'砀山县','0',235,0,'',1,0,'',NULL,0),(1493,'萧县','0',235,0,'',1,0,'',NULL,0),(1494,'灵璧县','0',235,0,'',1,0,'',NULL,0),(1495,'泗县','0',235,0,'',1,0,'',NULL,0),(1496,'居巢区','0',236,0,'',1,0,'',NULL,0),(1497,'庐江县','0',236,0,'',1,0,'',NULL,0),(1498,'无为县','0',236,0,'',1,0,'',NULL,0),(1499,'含山县','0',236,0,'',1,0,'',NULL,0),(1500,'和县','0',236,0,'',1,0,'',NULL,0),(1501,'金安区','0',237,0,'',1,0,'',NULL,0),(1502,'裕安区','0',237,0,'',1,0,'',NULL,0),(1503,'寿县','0',237,0,'',1,0,'',NULL,0),(1504,'霍邱县','0',237,0,'',1,0,'',NULL,0),(1505,'舒城县','0',237,0,'',1,0,'',NULL,0),(1506,'金寨县','0',237,0,'',1,0,'',NULL,0),(1507,'霍山县','0',237,0,'',1,0,'',NULL,0),(1508,'谯城区','0',238,0,'',1,0,'',NULL,0),(1509,'涡阳县','0',238,0,'',1,0,'',NULL,0),(1510,'蒙城县','0',238,0,'',1,0,'',NULL,0),(1511,'利辛县','0',238,0,'',1,0,'',NULL,0),(1512,'贵池区','0',239,0,'',1,0,'',NULL,0),(1513,'东至县','0',239,0,'',1,0,'',NULL,0),(1514,'石台县','0',239,0,'',1,0,'',NULL,0),(1515,'青阳县','0',239,0,'',1,0,'',NULL,0),(1516,'宣州区','0',240,0,'',1,0,'',NULL,0),(1517,'郎溪县','0',240,0,'',1,0,'',NULL,0),(1518,'广德县','0',240,0,'',1,0,'',NULL,0),(1519,'泾县','0',240,0,'',1,0,'',NULL,0),(1520,'绩溪县','0',240,0,'',1,0,'',NULL,0),(1521,'旌德县','0',240,0,'',1,0,'',NULL,0),(1522,'宁国市','0',240,0,'',1,0,'',NULL,0),(1523,'鼓楼区','0',241,0,'',1,0,'',NULL,0),(1524,'台江区','0',241,0,'',1,0,'',NULL,0),(1525,'仓山区','0',241,0,'',1,0,'',NULL,0),(1526,'马尾区','0',241,0,'',1,0,'',NULL,0),(1527,'晋安区','0',241,0,'',1,0,'',NULL,0),(1528,'闽侯县','0',241,0,'',1,0,'',NULL,0),(1529,'连江县','0',241,0,'',1,0,'',NULL,0),(1530,'罗源县','0',241,0,'',1,0,'',NULL,0),(1531,'闽清县','0',241,0,'',1,0,'',NULL,0),(1532,'永泰县','0',241,0,'',1,0,'',NULL,0),(1533,'平潭县','0',241,0,'',1,0,'',NULL,0),(1534,'福清市','0',241,0,'',1,0,'',NULL,0),(1535,'长乐市','0',241,0,'',1,0,'',NULL,0),(1536,'思明区','0',242,0,'',1,0,'',NULL,0),(1537,'海沧区','0',242,0,'',1,0,'',NULL,0),(1538,'湖里区','0',242,0,'',1,0,'',NULL,0),(1539,'集美区','0',242,0,'',1,0,'',NULL,0),(1540,'同安区','0',242,0,'',1,0,'',NULL,0),(1541,'翔安区','0',242,0,'',1,0,'',NULL,0),(1542,'城厢区','0',243,0,'',1,0,'',NULL,0),(1543,'涵江区','0',243,0,'',1,0,'',NULL,0),(1544,'荔城区','0',243,0,'',1,0,'',NULL,0),(1545,'秀屿区','0',243,0,'',1,0,'',NULL,0),(1546,'仙游县','0',243,0,'',1,0,'',NULL,0),(1547,'梅列区','0',244,0,'',1,0,'',NULL,0),(1548,'三元区','0',244,0,'',1,0,'',NULL,0),(1549,'明溪县','0',244,0,'',1,0,'',NULL,0),(1550,'清流县','0',244,0,'',1,0,'',NULL,0),(1551,'宁化县','0',244,0,'',1,0,'',NULL,0),(1552,'大田县','0',244,0,'',1,0,'',NULL,0),(1553,'尤溪县','0',244,0,'',1,0,'',NULL,0),(1554,'沙县','0',244,0,'',1,0,'',NULL,0),(1555,'将乐县','0',244,0,'',1,0,'',NULL,0),(1556,'泰宁县','0',244,0,'',1,0,'',NULL,0),(1557,'建宁县','0',244,0,'',1,0,'',NULL,0),(1558,'永安市','0',244,0,'',1,0,'',NULL,0),(1559,'鲤城区','0',245,0,'',1,0,'',NULL,0),(1560,'丰泽区','0',245,0,'',1,0,'',NULL,0),(1561,'洛江区','0',245,0,'',1,0,'',NULL,0),(1562,'泉港区','0',245,0,'',1,0,'',NULL,0),(1563,'惠安县','0',245,0,'',1,0,'',NULL,0),(1564,'安溪县','0',245,0,'',1,0,'',NULL,0),(1565,'永春县','0',245,0,'',1,0,'',NULL,0),(1566,'德化县','0',245,0,'',1,0,'',NULL,0),(1567,'金门县','0',245,0,'',1,0,'',NULL,0),(1568,'石狮市','0',245,0,'',1,0,'',NULL,0),(1569,'晋江市','0',245,0,'',1,0,'',NULL,0),(1570,'南安市','0',245,0,'',1,0,'',NULL,0),(1571,'芗城区','0',246,0,'',1,0,'',NULL,0),(1572,'龙文区','0',246,0,'',1,0,'',NULL,0),(1573,'云霄县','0',246,0,'',1,0,'',NULL,0),(1574,'漳浦县','0',246,0,'',1,0,'',NULL,0),(1575,'诏安县','0',246,0,'',1,0,'',NULL,0),(1576,'长泰县','0',246,0,'',1,0,'',NULL,0),(1577,'东山县','0',246,0,'',1,0,'',NULL,0),(1578,'南靖县','0',246,0,'',1,0,'',NULL,0),(1579,'平和县','0',246,0,'',1,0,'',NULL,0),(1580,'华安县','0',246,0,'',1,0,'',NULL,0),(1581,'龙海市','0',246,0,'',1,0,'',NULL,0),(1582,'延平区','0',247,0,'',1,0,'',NULL,0),(1583,'顺昌县','0',247,0,'',1,0,'',NULL,0),(1584,'浦城县','0',247,0,'',1,0,'',NULL,0),(1585,'光泽县','0',247,0,'',1,0,'',NULL,0),(1586,'松溪县','0',247,0,'',1,0,'',NULL,0),(1587,'政和县','0',247,0,'',1,0,'',NULL,0),(1588,'邵武市','0',247,0,'',1,0,'',NULL,0),(1589,'武夷山市','0',247,0,'',1,0,'',NULL,0),(1590,'建瓯市','0',247,0,'',1,0,'',NULL,0),(1591,'建阳市','0',247,0,'',1,0,'',NULL,0),(1592,'新罗区','0',248,0,'',1,0,'',NULL,0),(1593,'长汀县','0',248,0,'',1,0,'',NULL,0),(1594,'永定县','0',248,0,'',1,0,'',NULL,0),(1595,'上杭县','0',248,0,'',1,0,'',NULL,0),(1596,'武平县','0',248,0,'',1,0,'',NULL,0),(1597,'连城县','0',248,0,'',1,0,'',NULL,0),(1598,'漳平市','0',248,0,'',1,0,'',NULL,0),(1599,'蕉城区','0',249,0,'',1,0,'',NULL,0),(1600,'霞浦县','0',249,0,'',1,0,'',NULL,0),(1601,'古田县','0',249,0,'',1,0,'',NULL,0),(1602,'屏南县','0',249,0,'',1,0,'',NULL,0),(1603,'寿宁县','0',249,0,'',1,0,'',NULL,0),(1604,'周宁县','0',249,0,'',1,0,'',NULL,0),(1605,'柘荣县','0',249,0,'',1,0,'',NULL,0),(1606,'福安市','0',249,0,'',1,0,'',NULL,0),(1607,'福鼎市','0',249,0,'',1,0,'',NULL,0),(1608,'东湖区','0',250,0,'',1,0,'',NULL,0),(1609,'西湖区','0',250,0,'',1,0,'',NULL,0),(1610,'青云谱区','0',250,0,'',1,0,'',NULL,0),(1611,'湾里区','0',250,0,'',1,0,'',NULL,0),(1612,'青山湖区','0',250,0,'',1,0,'',NULL,0),(1613,'南昌县','0',250,0,'',1,0,'',NULL,0),(1614,'新建县','0',250,0,'',1,0,'',NULL,0),(1615,'安义县','0',250,0,'',1,0,'',NULL,0),(1616,'进贤县','0',250,0,'',1,0,'',NULL,0),(1617,'昌江区','0',251,0,'',1,0,'',NULL,0),(1618,'珠山区','0',251,0,'',1,0,'',NULL,0),(1619,'浮梁县','0',251,0,'',1,0,'',NULL,0),(1620,'乐平市','0',251,0,'',1,0,'',NULL,0),(1621,'安源区','0',252,0,'',1,0,'',NULL,0),(1622,'湘东区','0',252,0,'',1,0,'',NULL,0),(1623,'莲花县','0',252,0,'',1,0,'',NULL,0),(1624,'上栗县','0',252,0,'',1,0,'',NULL,0),(1625,'芦溪县','0',252,0,'',1,0,'',NULL,0),(1626,'庐山区','0',253,0,'',1,0,'',NULL,0),(1627,'浔阳区','0',253,0,'',1,0,'',NULL,0),(1628,'九江县','0',253,0,'',1,0,'',NULL,0),(1629,'武宁县','0',253,0,'',1,0,'',NULL,0),(1630,'修水县','0',253,0,'',1,0,'',NULL,0),(1631,'永修县','0',253,0,'',1,0,'',NULL,0),(1632,'德安县','0',253,0,'',1,0,'',NULL,0),(1633,'星子县','0',253,0,'',1,0,'',NULL,0),(1634,'都昌县','0',253,0,'',1,0,'',NULL,0),(1635,'湖口县','0',253,0,'',1,0,'',NULL,0),(1636,'彭泽县','0',253,0,'',1,0,'',NULL,0),(1637,'瑞昌市','0',253,0,'',1,0,'',NULL,0),(1638,'渝水区','0',254,0,'',1,0,'',NULL,0),(1639,'分宜县','0',254,0,'',1,0,'',NULL,0),(1640,'月湖区','0',255,0,'',1,0,'',NULL,0),(1641,'余江县','0',255,0,'',1,0,'',NULL,0),(1642,'贵溪市','0',255,0,'',1,0,'',NULL,0),(1643,'章贡区','0',256,0,'',1,0,'',NULL,0),(1644,'赣县','0',256,0,'',1,0,'',NULL,0),(1645,'信丰县','0',256,0,'',1,0,'',NULL,0),(1646,'大余县','0',256,0,'',1,0,'',NULL,0),(1647,'上犹县','0',256,0,'',1,0,'',NULL,0),(1648,'崇义县','0',256,0,'',1,0,'',NULL,0),(1649,'安远县','0',256,0,'',1,0,'',NULL,0),(1650,'龙南县','0',256,0,'',1,0,'',NULL,0),(1651,'定南县','0',256,0,'',1,0,'',NULL,0),(1652,'全南县','0',256,0,'',1,0,'',NULL,0),(1653,'宁都县','0',256,0,'',1,0,'',NULL,0),(1654,'于都县','0',256,0,'',1,0,'',NULL,0),(1655,'兴国县','0',256,0,'',1,0,'',NULL,0),(1656,'会昌县','0',256,0,'',1,0,'',NULL,0),(1657,'寻乌县','0',256,0,'',1,0,'',NULL,0),(1658,'石城县','0',256,0,'',1,0,'',NULL,0),(1659,'瑞金市','0',256,0,'',1,0,'',NULL,0),(1660,'南康市','0',256,0,'',1,0,'',NULL,0),(1661,'吉州区','0',257,0,'',1,0,'',NULL,0),(1662,'青原区','0',257,0,'',1,0,'',NULL,0),(1663,'吉安县','0',257,0,'',1,0,'',NULL,0),(1664,'吉水县','0',257,0,'',1,0,'',NULL,0),(1665,'峡江县','0',257,0,'',1,0,'',NULL,0),(1666,'新干县','0',257,0,'',1,0,'',NULL,0),(1667,'永丰县','0',257,0,'',1,0,'',NULL,0),(1668,'泰和县','0',257,0,'',1,0,'',NULL,0),(1669,'遂川县','0',257,0,'',1,0,'',NULL,0),(1670,'万安县','0',257,0,'',1,0,'',NULL,0),(1671,'安福县','0',257,0,'',1,0,'',NULL,0),(1672,'永新县','0',257,0,'',1,0,'',NULL,0),(1673,'井冈山市','0',257,0,'',1,0,'',NULL,0),(1674,'袁州区','0',258,0,'',1,0,'',NULL,0),(1675,'奉新县','0',258,0,'',1,0,'',NULL,0),(1676,'万载县','0',258,0,'',1,0,'',NULL,0),(1677,'上高县','0',258,0,'',1,0,'',NULL,0),(1678,'宜丰县','0',258,0,'',1,0,'',NULL,0),(1679,'靖安县','0',258,0,'',1,0,'',NULL,0),(1680,'铜鼓县','0',258,0,'',1,0,'',NULL,0),(1681,'丰城市','0',258,0,'',1,0,'',NULL,0),(1682,'樟树市','0',258,0,'',1,0,'',NULL,0),(1683,'高安市','0',258,0,'',1,0,'',NULL,0),(1684,'临川区','0',259,0,'',1,0,'',NULL,0),(1685,'南城县','0',259,0,'',1,0,'',NULL,0),(1686,'黎川县','0',259,0,'',1,0,'',NULL,0),(1687,'南丰县','0',259,0,'',1,0,'',NULL,0),(1688,'崇仁县','0',259,0,'',1,0,'',NULL,0),(1689,'乐安县','0',259,0,'',1,0,'',NULL,0),(1690,'宜黄县','0',259,0,'',1,0,'',NULL,0),(1691,'金溪县','0',259,0,'',1,0,'',NULL,0),(1692,'资溪县','0',259,0,'',1,0,'',NULL,0),(1693,'东乡县','0',259,0,'',1,0,'',NULL,0),(1694,'广昌县','0',259,0,'',1,0,'',NULL,0),(1695,'信州区','0',260,0,'',1,0,'',NULL,0),(1696,'上饶县','0',260,0,'',1,0,'',NULL,0),(1697,'广丰县','0',260,0,'',1,0,'',NULL,0),(1698,'玉山县','0',260,0,'',1,0,'',NULL,0),(1699,'铅山县','0',260,0,'',1,0,'',NULL,0),(1700,'横峰县','0',260,0,'',1,0,'',NULL,0),(1701,'弋阳县','0',260,0,'',1,0,'',NULL,0),(1702,'余干县','0',260,0,'',1,0,'',NULL,0),(1703,'鄱阳县','0',260,0,'',1,0,'',NULL,0),(1704,'万年县','0',260,0,'',1,0,'',NULL,0),(1705,'婺源县','0',260,0,'',1,0,'',NULL,0),(1706,'德兴市','0',260,0,'',1,0,'',NULL,0),(1707,'历下区','0',261,0,'',1,0,'',NULL,0),(1708,'市中区','0',261,0,'',1,0,'',NULL,0),(1709,'槐荫区','0',261,0,'',1,0,'',NULL,0),(1710,'天桥区','0',261,0,'',1,0,'',NULL,0),(1711,'历城区','0',261,0,'',1,0,'',NULL,0),(1712,'长清区','0',261,0,'',1,0,'',NULL,0),(1713,'平阴县','0',261,0,'',1,0,'',NULL,0),(1714,'济阳县','0',261,0,'',1,0,'',NULL,0),(1715,'商河县','0',261,0,'',1,0,'',NULL,0),(1716,'章丘市','0',261,0,'',1,0,'',NULL,0),(1717,'市南区','0',262,0,'',1,0,'',NULL,0),(1718,'市北区','0',262,0,'',1,0,'',NULL,0),(1719,'四方区','0',262,0,'',1,0,'',NULL,0),(1720,'黄岛区','0',262,0,'',1,0,'',NULL,0),(1721,'崂山区','0',262,0,'',1,0,'',NULL,0),(1722,'李沧区','0',262,0,'',1,0,'',NULL,0),(1723,'城阳区','0',262,0,'',1,0,'',NULL,0),(1724,'胶州市','0',262,0,'',1,0,'',NULL,0),(1725,'即墨市','0',262,0,'',1,0,'',NULL,0),(1726,'平度市','0',262,0,'',1,0,'',NULL,0),(1727,'胶南市','0',262,0,'',1,0,'',NULL,0),(1728,'莱西市','0',262,0,'',1,0,'',NULL,0),(1729,'淄川区','0',263,0,'',1,0,'',NULL,0),(1730,'张店区','0',263,0,'',1,0,'',NULL,0),(1731,'博山区','0',263,0,'',1,0,'',NULL,0),(1732,'临淄区','0',263,0,'',1,0,'',NULL,0),(1733,'周村区','0',263,0,'',1,0,'',NULL,0),(1734,'桓台县','0',263,0,'',1,0,'',NULL,0),(1735,'高青县','0',263,0,'',1,0,'',NULL,0),(1736,'沂源县','0',263,0,'',1,0,'',NULL,0),(1737,'市中区','0',264,0,'',1,0,'',NULL,0),(1738,'薛城区','0',264,0,'',1,0,'',NULL,0),(1739,'峄城区','0',264,0,'',1,0,'',NULL,0),(1740,'台儿庄区','0',264,0,'',1,0,'',NULL,0),(1741,'山亭区','0',264,0,'',1,0,'',NULL,0),(1742,'滕州市','0',264,0,'',1,0,'',NULL,0),(1743,'东营区','0',265,0,'',1,0,'',NULL,0),(1744,'河口区','0',265,0,'',1,0,'',NULL,0),(1745,'垦利县','0',265,0,'',1,0,'',NULL,0),(1746,'利津县','0',265,0,'',1,0,'',NULL,0),(1747,'广饶县','0',265,0,'',1,0,'',NULL,0),(1748,'芝罘区','0',266,0,'',1,0,'',NULL,0),(1749,'福山区','0',266,0,'',1,0,'',NULL,0),(1750,'牟平区','0',266,0,'',1,0,'',NULL,0),(1751,'莱山区','0',266,0,'',1,0,'',NULL,0),(1752,'长岛县','0',266,0,'',1,0,'',NULL,0),(1753,'龙口市','0',266,0,'',1,0,'',NULL,0),(1754,'莱阳市','0',266,0,'',1,0,'',NULL,0),(1755,'莱州市','0',266,0,'',1,0,'',NULL,0),(1756,'蓬莱市','0',266,0,'',1,0,'',NULL,0),(1757,'招远市','0',266,0,'',1,0,'',NULL,0),(1758,'栖霞市','0',266,0,'',1,0,'',NULL,0),(1759,'海阳市','0',266,0,'',1,0,'',NULL,0),(1760,'潍城区','0',267,0,'',1,0,'',NULL,0),(1761,'寒亭区','0',267,0,'',1,0,'',NULL,0),(1762,'坊子区','0',267,0,'',1,0,'',NULL,0),(1763,'奎文区','0',267,0,'',1,0,'',NULL,0),(1764,'临朐县','0',267,0,'',1,0,'',NULL,0),(1765,'昌乐县','0',267,0,'',1,0,'',NULL,0),(1766,'青州市','0',267,0,'',1,0,'',NULL,0),(1767,'诸城市','0',267,0,'',1,0,'',NULL,0),(1768,'寿光市','0',267,0,'',1,0,'',NULL,0),(1769,'安丘市','0',267,0,'',1,0,'',NULL,0),(1770,'高密市','0',267,0,'',1,0,'',NULL,0),(1771,'昌邑市','0',267,0,'',1,0,'',NULL,0),(1772,'市中区','0',268,0,'',1,0,'',NULL,0),(1773,'任城区','0',268,0,'',1,0,'',NULL,0),(1774,'微山县','0',268,0,'',1,0,'',NULL,0),(1775,'鱼台县','0',268,0,'',1,0,'',NULL,0),(1776,'金乡县','0',268,0,'',1,0,'',NULL,0),(1777,'嘉祥县','0',268,0,'',1,0,'',NULL,0),(1778,'汶上县','0',268,0,'',1,0,'',NULL,0),(1779,'泗水县','0',268,0,'',1,0,'',NULL,0),(1780,'梁山县','0',268,0,'',1,0,'',NULL,0),(1781,'曲阜市','0',268,0,'',1,0,'',NULL,0),(1782,'兖州市','0',268,0,'',1,0,'',NULL,0),(1783,'邹城市','0',268,0,'',1,0,'',NULL,0),(1784,'泰山区','0',269,0,'',1,0,'',NULL,0),(1785,'岱岳区','0',269,0,'',1,0,'',NULL,0),(1786,'宁阳县','0',269,0,'',1,0,'',NULL,0),(1787,'东平县','0',269,0,'',1,0,'',NULL,0),(1788,'新泰市','0',269,0,'',1,0,'',NULL,0),(1789,'肥城市','0',269,0,'',1,0,'',NULL,0),(1790,'环翠区','0',270,0,'',1,0,'',NULL,0),(1791,'文登市','0',270,0,'',1,0,'',NULL,0),(1792,'荣成市','0',270,0,'',1,0,'',NULL,0),(1793,'乳山市','0',270,0,'',1,0,'',NULL,0),(1794,'东港区','0',271,0,'',1,0,'',NULL,0),(1795,'岚山区','0',271,0,'',1,0,'',NULL,0),(1796,'五莲县','0',271,0,'',1,0,'',NULL,0),(1797,'莒县','0',271,0,'',1,0,'',NULL,0),(1798,'莱城区','0',272,0,'',1,0,'',NULL,0),(1799,'钢城区','0',272,0,'',1,0,'',NULL,0),(1800,'兰山区','0',273,0,'',1,0,'',NULL,0),(1801,'罗庄区','0',273,0,'',1,0,'',NULL,0),(1802,'河东区','0',273,0,'',1,0,'',NULL,0),(1803,'沂南县','0',273,0,'',1,0,'',NULL,0),(1804,'郯城县','0',273,0,'',1,0,'',NULL,0),(1805,'沂水县','0',273,0,'',1,0,'',NULL,0),(1806,'苍山县','0',273,0,'',1,0,'',NULL,0),(1807,'费县','0',273,0,'',1,0,'',NULL,0),(1808,'平邑县','0',273,0,'',1,0,'',NULL,0),(1809,'莒南县','0',273,0,'',1,0,'',NULL,0),(1810,'蒙阴县','0',273,0,'',1,0,'',NULL,0),(1811,'临沭县','0',273,0,'',1,0,'',NULL,0),(1812,'德城区','0',274,0,'',1,0,'',NULL,0),(1813,'陵县','0',274,0,'',1,0,'',NULL,0),(1814,'宁津县','0',274,0,'',1,0,'',NULL,0),(1815,'庆云县','0',274,0,'',1,0,'',NULL,0),(1816,'临邑县','0',274,0,'',1,0,'',NULL,0),(1817,'齐河县','0',274,0,'',1,0,'',NULL,0),(1818,'平原县','0',274,0,'',1,0,'',NULL,0),(1819,'夏津县','0',274,0,'',1,0,'',NULL,0),(1820,'武城县','0',274,0,'',1,0,'',NULL,0),(1821,'乐陵市','0',274,0,'',1,0,'',NULL,0),(1822,'禹城市','0',274,0,'',1,0,'',NULL,0),(1823,'东昌府区','0',275,0,'',1,0,'',NULL,0),(1824,'阳谷县','0',275,0,'',1,0,'',NULL,0),(1825,'莘县','0',275,0,'',1,0,'',NULL,0),(1826,'茌平县','0',275,0,'',1,0,'',NULL,0),(1827,'东阿县','0',275,0,'',1,0,'',NULL,0),(1828,'冠县','0',275,0,'',1,0,'',NULL,0),(1829,'高唐县','0',275,0,'',1,0,'',NULL,0),(1830,'临清市','0',275,0,'',1,0,'',NULL,0),(1831,'滨城区','0',276,0,'',1,0,'',NULL,0),(1832,'惠民县','0',276,0,'',1,0,'',NULL,0),(1833,'阳信县','0',276,0,'',1,0,'',NULL,0),(1834,'无棣县','0',276,0,'',1,0,'',NULL,0),(1835,'沾化县','0',276,0,'',1,0,'',NULL,0),(1836,'博兴县','0',276,0,'',1,0,'',NULL,0),(1837,'邹平县','0',276,0,'',1,0,'',NULL,0),(1838,'牡丹区','0',277,0,'',1,0,'',NULL,0),(1839,'曹县','0',277,0,'',1,0,'',NULL,0),(1840,'单县','0',277,0,'',1,0,'',NULL,0),(1841,'成武县','0',277,0,'',1,0,'',NULL,0),(1842,'巨野县','0',277,0,'',1,0,'',NULL,0),(1843,'郓城县','0',277,0,'',1,0,'',NULL,0),(1844,'鄄城县','0',277,0,'',1,0,'',NULL,0),(1845,'定陶县','0',277,0,'',1,0,'',NULL,0),(1846,'东明县','0',277,0,'',1,0,'',NULL,0),(1847,'中原区','0',278,0,'',1,0,'',NULL,0),(1848,'二七区','0',278,0,'',1,0,'',NULL,0),(1849,'管城回族区','0',278,0,'',1,0,'',NULL,0),(1850,'金水区','0',278,0,'',1,0,'',NULL,0),(1851,'上街区','0',278,0,'',1,0,'',NULL,0),(1852,'惠济区','0',278,0,'',1,0,'',NULL,0),(1853,'中牟县','0',278,0,'',1,0,'',NULL,0),(1854,'巩义市','0',278,0,'',1,0,'',NULL,0),(1855,'荥阳市','0',278,0,'',1,0,'',NULL,0),(1856,'新密市','0',278,0,'',1,0,'',NULL,0),(1857,'新郑市','0',278,0,'',1,0,'',NULL,0),(1858,'登封市','0',278,0,'',1,0,'',NULL,0),(1859,'龙亭区','0',279,0,'',1,0,'',NULL,0),(1860,'顺河回族区','0',279,0,'',1,0,'',NULL,0),(1861,'鼓楼区','0',279,0,'',1,0,'',NULL,0),(1862,'禹王台区','0',279,0,'',1,0,'',NULL,0),(1863,'金明区','0',279,0,'',1,0,'',NULL,0),(1864,'杞县','0',279,0,'',1,0,'',NULL,0),(1865,'通许县','0',279,0,'',1,0,'',NULL,0),(1866,'尉氏县','0',279,0,'',1,0,'',NULL,0),(1867,'开封县','0',279,0,'',1,0,'',NULL,0),(1868,'兰考县','0',279,0,'',1,0,'',NULL,0),(1869,'老城区','0',280,0,'',1,0,'',NULL,0),(1870,'西工区','0',280,0,'',1,0,'',NULL,0),(1871,'廛河回族区','0',280,0,'',1,0,'',NULL,0),(1872,'涧西区','0',280,0,'',1,0,'',NULL,0),(1873,'吉利区','0',280,0,'',1,0,'',NULL,0),(1874,'洛龙区','0',280,0,'',1,0,'',NULL,0),(1875,'孟津县','0',280,0,'',1,0,'',NULL,0),(1876,'新安县','0',280,0,'',1,0,'',NULL,0),(1877,'栾川县','0',280,0,'',1,0,'',NULL,0),(1878,'嵩县','0',280,0,'',1,0,'',NULL,0),(1879,'汝阳县','0',280,0,'',1,0,'',NULL,0),(1880,'宜阳县','0',280,0,'',1,0,'',NULL,0),(1881,'洛宁县','0',280,0,'',1,0,'',NULL,0),(1882,'伊川县','0',280,0,'',1,0,'',NULL,0),(1883,'偃师市','0',280,0,'',1,0,'',NULL,0),(1884,'新华区','0',281,0,'',1,0,'',NULL,0),(1885,'卫东区','0',281,0,'',1,0,'',NULL,0),(1886,'石龙区','0',281,0,'',1,0,'',NULL,0),(1887,'湛河区','0',281,0,'',1,0,'',NULL,0),(1888,'宝丰县','0',281,0,'',1,0,'',NULL,0),(1889,'叶县','0',281,0,'',1,0,'',NULL,0),(1890,'鲁山县','0',281,0,'',1,0,'',NULL,0),(1891,'郏县','0',281,0,'',1,0,'',NULL,0),(1892,'舞钢市','0',281,0,'',1,0,'',NULL,0),(1893,'汝州市','0',281,0,'',1,0,'',NULL,0),(1894,'文峰区','0',282,0,'',1,0,'',NULL,0),(1895,'北关区','0',282,0,'',1,0,'',NULL,0),(1896,'殷都区','0',282,0,'',1,0,'',NULL,0),(1897,'龙安区','0',282,0,'',1,0,'',NULL,0),(1898,'安阳县','0',282,0,'',1,0,'',NULL,0),(1899,'汤阴县','0',282,0,'',1,0,'',NULL,0),(1900,'滑县','0',282,0,'',1,0,'',NULL,0),(1901,'内黄县','0',282,0,'',1,0,'',NULL,0),(1902,'林州市','0',282,0,'',1,0,'',NULL,0),(1903,'鹤山区','0',283,0,'',1,0,'',NULL,0),(1904,'山城区','0',283,0,'',1,0,'',NULL,0),(1905,'淇滨区','0',283,0,'',1,0,'',NULL,0),(1906,'浚县','0',283,0,'',1,0,'',NULL,0),(1907,'淇县','0',283,0,'',1,0,'',NULL,0),(1908,'红旗区','0',284,0,'',1,0,'',NULL,0),(1909,'卫滨区','0',284,0,'',1,0,'',NULL,0),(1910,'凤泉区','0',284,0,'',1,0,'',NULL,0),(1911,'牧野区','0',284,0,'',1,0,'',NULL,0),(1912,'新乡县','0',284,0,'',1,0,'',NULL,0),(1913,'获嘉县','0',284,0,'',1,0,'',NULL,0),(1914,'原阳县','0',284,0,'',1,0,'',NULL,0),(1915,'延津县','0',284,0,'',1,0,'',NULL,0),(1916,'封丘县','0',284,0,'',1,0,'',NULL,0),(1917,'长垣县','0',284,0,'',1,0,'',NULL,0),(1918,'卫辉市','0',284,0,'',1,0,'',NULL,0),(1919,'辉县市','0',284,0,'',1,0,'',NULL,0),(1920,'解放区','0',285,0,'',1,0,'',NULL,0),(1921,'中站区','0',285,0,'',1,0,'',NULL,0),(1922,'马村区','0',285,0,'',1,0,'',NULL,0),(1923,'山阳区','0',285,0,'',1,0,'',NULL,0),(1924,'修武县','0',285,0,'',1,0,'',NULL,0),(1925,'博爱县','0',285,0,'',1,0,'',NULL,0),(1926,'武陟县','0',285,0,'',1,0,'',NULL,0),(1927,'温县','0',285,0,'',1,0,'',NULL,0),(1928,'济源市','0',285,0,'',1,0,'',NULL,0),(1929,'沁阳市','0',285,0,'',1,0,'',NULL,0),(1930,'孟州市','0',285,0,'',1,0,'',NULL,0),(1931,'华龙区','0',286,0,'',1,0,'',NULL,0),(1932,'清丰县','0',286,0,'',1,0,'',NULL,0),(1933,'南乐县','0',286,0,'',1,0,'',NULL,0),(1934,'范县','0',286,0,'',1,0,'',NULL,0),(1935,'台前县','0',286,0,'',1,0,'',NULL,0),(1936,'濮阳县','0',286,0,'',1,0,'',NULL,0),(1937,'魏都区','0',287,0,'',1,0,'',NULL,0),(1938,'许昌县','0',287,0,'',1,0,'',NULL,0),(1939,'鄢陵县','0',287,0,'',1,0,'',NULL,0),(1940,'襄城县','0',287,0,'',1,0,'',NULL,0),(1941,'禹州市','0',287,0,'',1,0,'',NULL,0),(1942,'长葛市','0',287,0,'',1,0,'',NULL,0),(1943,'源汇区','0',288,0,'',1,0,'',NULL,0),(1944,'郾城区','0',288,0,'',1,0,'',NULL,0),(1945,'召陵区','0',288,0,'',1,0,'',NULL,0),(1946,'舞阳县','0',288,0,'',1,0,'',NULL,0),(1947,'临颍县','0',288,0,'',1,0,'',NULL,0),(1948,'湖滨区','0',289,0,'',1,0,'',NULL,0),(1949,'渑池县','0',289,0,'',1,0,'',NULL,0),(1950,'陕县','0',289,0,'',1,0,'',NULL,0),(1951,'卢氏县','0',289,0,'',1,0,'',NULL,0),(1952,'义马市','0',289,0,'',1,0,'',NULL,0),(1953,'灵宝市','0',289,0,'',1,0,'',NULL,0),(1954,'宛城区','0',290,0,'',1,0,'',NULL,0),(1955,'卧龙区','0',290,0,'',1,0,'',NULL,0),(1956,'南召县','0',290,0,'',1,0,'',NULL,0),(1957,'方城县','0',290,0,'',1,0,'',NULL,0),(1958,'西峡县','0',290,0,'',1,0,'',NULL,0),(1959,'镇平县','0',290,0,'',1,0,'',NULL,0),(1960,'内乡县','0',290,0,'',1,0,'',NULL,0),(1961,'淅川县','0',290,0,'',1,0,'',NULL,0),(1962,'社旗县','0',290,0,'',1,0,'',NULL,0),(1963,'唐河县','0',290,0,'',1,0,'',NULL,0),(1964,'新野县','0',290,0,'',1,0,'',NULL,0),(1965,'桐柏县','0',290,0,'',1,0,'',NULL,0),(1966,'邓州市','0',290,0,'',1,0,'',NULL,0),(1967,'梁园区','0',291,0,'',1,0,'',NULL,0),(1968,'睢阳区','0',291,0,'',1,0,'',NULL,0),(1969,'民权县','0',291,0,'',1,0,'',NULL,0),(1970,'睢县','0',291,0,'',1,0,'',NULL,0),(1971,'宁陵县','0',291,0,'',1,0,'',NULL,0),(1972,'柘城县','0',291,0,'',1,0,'',NULL,0),(1973,'虞城县','0',291,0,'',1,0,'',NULL,0),(1974,'夏邑县','0',291,0,'',1,0,'',NULL,0),(1975,'永城市','0',291,0,'',1,0,'',NULL,0),(1976,'浉河区','0',292,0,'',1,0,'',NULL,0),(1977,'平桥区','0',292,0,'',1,0,'',NULL,0),(1978,'罗山县','0',292,0,'',1,0,'',NULL,0),(1979,'光山县','0',292,0,'',1,0,'',NULL,0),(1980,'新县','0',292,0,'',1,0,'',NULL,0),(1981,'商城县','0',292,0,'',1,0,'',NULL,0),(1982,'固始县','0',292,0,'',1,0,'',NULL,0),(1983,'潢川县','0',292,0,'',1,0,'',NULL,0),(1984,'淮滨县','0',292,0,'',1,0,'',NULL,0),(1985,'息县','0',292,0,'',1,0,'',NULL,0),(1986,'川汇区','0',293,0,'',1,0,'',NULL,0),(1987,'扶沟县','0',293,0,'',1,0,'',NULL,0),(1988,'西华县','0',293,0,'',1,0,'',NULL,0),(1989,'商水县','0',293,0,'',1,0,'',NULL,0),(1990,'沈丘县','0',293,0,'',1,0,'',NULL,0),(1991,'郸城县','0',293,0,'',1,0,'',NULL,0),(1992,'淮阳县','0',293,0,'',1,0,'',NULL,0),(1993,'太康县','0',293,0,'',1,0,'',NULL,0),(1994,'鹿邑县','0',293,0,'',1,0,'',NULL,0),(1995,'项城市','0',293,0,'',1,0,'',NULL,0),(1996,'驿城区','0',294,0,'',1,0,'',NULL,0),(1997,'西平县','0',294,0,'',1,0,'',NULL,0),(1998,'上蔡县','0',294,0,'',1,0,'',NULL,0),(1999,'平舆县','0',294,0,'',1,0,'',NULL,0),(2000,'正阳县','0',294,0,'',1,0,'',NULL,0),(2001,'确山县','0',294,0,'',1,0,'',NULL,0),(2002,'泌阳县','0',294,0,'',1,0,'',NULL,0),(2003,'汝南县','0',294,0,'',1,0,'',NULL,0),(2004,'遂平县','0',294,0,'',1,0,'',NULL,0),(2005,'新蔡县','0',294,0,'',1,0,'',NULL,0),(2006,'江岸区','0',295,0,'',1,0,'',NULL,0),(2007,'江汉区','0',295,0,'',1,0,'',NULL,0),(2008,'硚口区','0',295,0,'',1,0,'',NULL,0),(2009,'汉阳区','0',295,0,'',1,0,'',NULL,0),(2010,'武昌区','0',295,0,'',1,0,'',NULL,0),(2011,'青山区','0',295,0,'',1,0,'',NULL,0),(2012,'洪山区','0',295,0,'',1,0,'',NULL,0),(2013,'东西湖区','0',295,0,'',1,0,'',NULL,0),(2014,'汉南区','0',295,0,'',1,0,'',NULL,0),(2015,'蔡甸区','0',295,0,'',1,0,'',NULL,0),(2016,'江夏区','0',295,0,'',1,0,'',NULL,0),(2017,'黄陂区','0',295,0,'',1,0,'',NULL,0),(2018,'新洲区','0',295,0,'',1,0,'',NULL,0),(2019,'黄石港区','0',296,0,'',1,0,'',NULL,0),(2020,'西塞山区','0',296,0,'',1,0,'',NULL,0),(2021,'下陆区','0',296,0,'',1,0,'',NULL,0),(2022,'铁山区','0',296,0,'',1,0,'',NULL,0),(2023,'阳新县','0',296,0,'',1,0,'',NULL,0),(2024,'大冶市','0',296,0,'',1,0,'',NULL,0),(2025,'茅箭区','0',297,0,'',1,0,'',NULL,0),(2026,'张湾区','0',297,0,'',1,0,'',NULL,0),(2027,'郧县','0',297,0,'',1,0,'',NULL,0),(2028,'郧西县','0',297,0,'',1,0,'',NULL,0),(2029,'竹山县','0',297,0,'',1,0,'',NULL,0),(2030,'竹溪县','0',297,0,'',1,0,'',NULL,0),(2031,'房县','0',297,0,'',1,0,'',NULL,0),(2032,'丹江口市','0',297,0,'',1,0,'',NULL,0),(2033,'西陵区','0',298,0,'',1,0,'',NULL,0),(2034,'伍家岗区','0',298,0,'',1,0,'',NULL,0),(2035,'点军区','0',298,0,'',1,0,'',NULL,0),(2036,'猇亭区','0',298,0,'',1,0,'',NULL,0),(2037,'夷陵区','0',298,0,'',1,0,'',NULL,0),(2038,'远安县','0',298,0,'',1,0,'',NULL,0),(2039,'兴山县','0',298,0,'',1,0,'',NULL,0),(2040,'秭归县','0',298,0,'',1,0,'',NULL,0),(2041,'长阳土家族自治县','0',298,0,'',1,0,'',NULL,0),(2042,'五峰土家族自治县','0',298,0,'',1,0,'',NULL,0),(2043,'宜都市','0',298,0,'',1,0,'',NULL,0),(2044,'当阳市','0',298,0,'',1,0,'',NULL,0),(2045,'枝江市','0',298,0,'',1,0,'',NULL,0),(2046,'襄城区','0',299,0,'',1,0,'',NULL,0),(2047,'樊城区','0',299,0,'',1,0,'',NULL,0),(2048,'襄阳区','0',299,0,'',1,0,'',NULL,0),(2049,'南漳县','0',299,0,'',1,0,'',NULL,0),(2050,'谷城县','0',299,0,'',1,0,'',NULL,0),(2051,'保康县','0',299,0,'',1,0,'',NULL,0),(2052,'老河口市','0',299,0,'',1,0,'',NULL,0),(2053,'枣阳市','0',299,0,'',1,0,'',NULL,0),(2054,'宜城市','0',299,0,'',1,0,'',NULL,0),(2055,'梁子湖区','0',300,0,'',1,0,'',NULL,0),(2056,'华容区','0',300,0,'',1,0,'',NULL,0),(2057,'鄂城区','0',300,0,'',1,0,'',NULL,0),(2058,'东宝区','0',301,0,'',1,0,'',NULL,0),(2059,'掇刀区','0',301,0,'',1,0,'',NULL,0),(2060,'京山县','0',301,0,'',1,0,'',NULL,0),(2061,'沙洋县','0',301,0,'',1,0,'',NULL,0),(2062,'钟祥市','0',301,0,'',1,0,'',NULL,0),(2063,'孝南区','0',302,0,'',1,0,'',NULL,0),(2064,'孝昌县','0',302,0,'',1,0,'',NULL,0),(2065,'大悟县','0',302,0,'',1,0,'',NULL,0),(2066,'云梦县','0',302,0,'',1,0,'',NULL,0),(2067,'应城市','0',302,0,'',1,0,'',NULL,0),(2068,'安陆市','0',302,0,'',1,0,'',NULL,0),(2069,'汉川市','0',302,0,'',1,0,'',NULL,0),(2070,'沙市区','0',303,0,'',1,0,'',NULL,0),(2071,'荆州区','0',303,0,'',1,0,'',NULL,0),(2072,'公安县','0',303,0,'',1,0,'',NULL,0),(2073,'监利县','0',303,0,'',1,0,'',NULL,0),(2074,'江陵县','0',303,0,'',1,0,'',NULL,0),(2075,'石首市','0',303,0,'',1,0,'',NULL,0),(2076,'洪湖市','0',303,0,'',1,0,'',NULL,0),(2077,'松滋市','0',303,0,'',1,0,'',NULL,0),(2078,'黄州区','0',304,0,'',1,0,'',NULL,0),(2079,'团风县','0',304,0,'',1,0,'',NULL,0),(2080,'红安县','0',304,0,'',1,0,'',NULL,0),(2081,'罗田县','0',304,0,'',1,0,'',NULL,0),(2082,'英山县','0',304,0,'',1,0,'',NULL,0),(2083,'浠水县','0',304,0,'',1,0,'',NULL,0),(2084,'蕲春县','0',304,0,'',1,0,'',NULL,0),(2085,'黄梅县','0',304,0,'',1,0,'',NULL,0),(2086,'麻城市','0',304,0,'',1,0,'',NULL,0),(2087,'武穴市','0',304,0,'',1,0,'',NULL,0),(2088,'咸安区','0',305,0,'',1,0,'',NULL,0),(2089,'嘉鱼县','0',305,0,'',1,0,'',NULL,0),(2090,'通城县','0',305,0,'',1,0,'',NULL,0),(2091,'崇阳县','0',305,0,'',1,0,'',NULL,0),(2092,'通山县','0',305,0,'',1,0,'',NULL,0),(2093,'赤壁市','0',305,0,'',1,0,'',NULL,0),(2094,'曾都区','0',306,0,'',1,0,'',NULL,0),(2095,'广水市','0',306,0,'',1,0,'',NULL,0),(2096,'恩施市','0',307,0,'',1,0,'',NULL,0),(2097,'利川市','0',307,0,'',1,0,'',NULL,0),(2098,'建始县','0',307,0,'',1,0,'',NULL,0),(2099,'巴东县','0',307,0,'',1,0,'',NULL,0),(2100,'宣恩县','0',307,0,'',1,0,'',NULL,0),(2101,'咸丰县','0',307,0,'',1,0,'',NULL,0),(2102,'来凤县','0',307,0,'',1,0,'',NULL,0),(2103,'鹤峰县','0',307,0,'',1,0,'',NULL,0),(2104,'芙蓉区','0',312,0,'',1,0,'',NULL,0),(2105,'天心区','0',312,0,'',1,0,'',NULL,0),(2106,'岳麓区','0',312,0,'',1,0,'',NULL,0),(2107,'开福区','0',312,0,'',1,0,'',NULL,0),(2108,'雨花区','0',312,0,'',1,0,'',NULL,0),(2109,'长沙县','0',312,0,'',1,0,'',NULL,0),(2110,'望城县','0',312,0,'',1,0,'',NULL,0),(2111,'宁乡县','0',312,0,'',1,0,'',NULL,0),(2112,'浏阳市','0',312,0,'',1,0,'',NULL,0),(2113,'荷塘区','0',313,0,'',1,0,'',NULL,0),(2114,'芦淞区','0',313,0,'',1,0,'',NULL,0),(2115,'石峰区','0',313,0,'',1,0,'',NULL,0),(2116,'天元区','0',313,0,'',1,0,'',NULL,0),(2117,'株洲县','0',313,0,'',1,0,'',NULL,0),(2118,'攸县','0',313,0,'',1,0,'',NULL,0),(2119,'茶陵县','0',313,0,'',1,0,'',NULL,0),(2120,'炎陵县','0',313,0,'',1,0,'',NULL,0),(2121,'醴陵市','0',313,0,'',1,0,'',NULL,0),(2122,'雨湖区','0',314,0,'',1,0,'',NULL,0),(2123,'岳塘区','0',314,0,'',1,0,'',NULL,0),(2124,'湘潭县','0',314,0,'',1,0,'',NULL,0),(2125,'湘乡市','0',314,0,'',1,0,'',NULL,0),(2126,'韶山市','0',314,0,'',1,0,'',NULL,0),(2127,'珠晖区','0',315,0,'',1,0,'',NULL,0),(2128,'雁峰区','0',315,0,'',1,0,'',NULL,0),(2129,'石鼓区','0',315,0,'',1,0,'',NULL,0),(2130,'蒸湘区','0',315,0,'',1,0,'',NULL,0),(2131,'南岳区','0',315,0,'',1,0,'',NULL,0),(2132,'衡阳县','0',315,0,'',1,0,'',NULL,0),(2133,'衡南县','0',315,0,'',1,0,'',NULL,0),(2134,'衡山县','0',315,0,'',1,0,'',NULL,0),(2135,'衡东县','0',315,0,'',1,0,'',NULL,0),(2136,'祁东县','0',315,0,'',1,0,'',NULL,0),(2137,'耒阳市','0',315,0,'',1,0,'',NULL,0),(2138,'常宁市','0',315,0,'',1,0,'',NULL,0),(2139,'双清区','0',316,0,'',1,0,'',NULL,0),(2140,'大祥区','0',316,0,'',1,0,'',NULL,0),(2141,'北塔区','0',316,0,'',1,0,'',NULL,0),(2142,'邵东县','0',316,0,'',1,0,'',NULL,0),(2143,'新邵县','0',316,0,'',1,0,'',NULL,0),(2144,'邵阳县','0',316,0,'',1,0,'',NULL,0),(2145,'隆回县','0',316,0,'',1,0,'',NULL,0),(2146,'洞口县','0',316,0,'',1,0,'',NULL,0),(2147,'绥宁县','0',316,0,'',1,0,'',NULL,0),(2148,'新宁县','0',316,0,'',1,0,'',NULL,0),(2149,'城步苗族自治县','0',316,0,'',1,0,'',NULL,0),(2150,'武冈市','0',316,0,'',1,0,'',NULL,0),(2151,'岳阳楼区','0',317,0,'',1,0,'',NULL,0),(2152,'云溪区','0',317,0,'',1,0,'',NULL,0),(2153,'君山区','0',317,0,'',1,0,'',NULL,0),(2154,'岳阳县','0',317,0,'',1,0,'',NULL,0),(2155,'华容县','0',317,0,'',1,0,'',NULL,0),(2156,'湘阴县','0',317,0,'',1,0,'',NULL,0),(2157,'平江县','0',317,0,'',1,0,'',NULL,0),(2158,'汨罗市','0',317,0,'',1,0,'',NULL,0),(2159,'临湘市','0',317,0,'',1,0,'',NULL,0),(2160,'武陵区','0',318,0,'',1,0,'',NULL,0),(2161,'鼎城区','0',318,0,'',1,0,'',NULL,0),(2162,'安乡县','0',318,0,'',1,0,'',NULL,0),(2163,'汉寿县','0',318,0,'',1,0,'',NULL,0),(2164,'澧县','0',318,0,'',1,0,'',NULL,0),(2165,'临澧县','0',318,0,'',1,0,'',NULL,0),(2166,'桃源县','0',318,0,'',1,0,'',NULL,0),(2167,'石门县','0',318,0,'',1,0,'',NULL,0),(2168,'津市市','0',318,0,'',1,0,'',NULL,0),(2169,'永定区','0',319,0,'',1,0,'',NULL,0),(2170,'武陵源区','0',319,0,'',1,0,'',NULL,0),(2171,'慈利县','0',319,0,'',1,0,'',NULL,0),(2172,'桑植县','0',319,0,'',1,0,'',NULL,0),(2173,'资阳区','0',320,0,'',1,0,'',NULL,0),(2174,'赫山区','0',320,0,'',1,0,'',NULL,0),(2175,'南县','0',320,0,'',1,0,'',NULL,0),(2176,'桃江县','0',320,0,'',1,0,'',NULL,0),(2177,'安化县','0',320,0,'',1,0,'',NULL,0),(2178,'沅江市','0',320,0,'',1,0,'',NULL,0),(2179,'北湖区','0',321,0,'',1,0,'',NULL,0),(2180,'苏仙区','0',321,0,'',1,0,'',NULL,0),(2181,'桂阳县','0',321,0,'',1,0,'',NULL,0),(2182,'宜章县','0',321,0,'',1,0,'',NULL,0),(2183,'永兴县','0',321,0,'',1,0,'',NULL,0),(2184,'嘉禾县','0',321,0,'',1,0,'',NULL,0),(2185,'临武县','0',321,0,'',1,0,'',NULL,0),(2186,'汝城县','0',321,0,'',1,0,'',NULL,0),(2187,'桂东县','0',321,0,'',1,0,'',NULL,0),(2188,'安仁县','0',321,0,'',1,0,'',NULL,0),(2189,'资兴市','0',321,0,'',1,0,'',NULL,0),(2190,'零陵区','0',322,0,'',1,0,'',NULL,0),(2191,'冷水滩区','0',322,0,'',1,0,'',NULL,0),(2192,'祁阳县','0',322,0,'',1,0,'',NULL,0),(2193,'东安县','0',322,0,'',1,0,'',NULL,0),(2194,'双牌县','0',322,0,'',1,0,'',NULL,0),(2195,'道县','0',322,0,'',1,0,'',NULL,0),(2196,'江永县','0',322,0,'',1,0,'',NULL,0),(2197,'宁远县','0',322,0,'',1,0,'',NULL,0),(2198,'蓝山县','0',322,0,'',1,0,'',NULL,0),(2199,'新田县','0',322,0,'',1,0,'',NULL,0),(2200,'江华瑶族自治县','0',322,0,'',1,0,'',NULL,0),(2201,'鹤城区','0',323,0,'',1,0,'',NULL,0),(2202,'中方县','0',323,0,'',1,0,'',NULL,0),(2203,'沅陵县','0',323,0,'',1,0,'',NULL,0),(2204,'辰溪县','0',323,0,'',1,0,'',NULL,0),(2205,'溆浦县','0',323,0,'',1,0,'',NULL,0),(2206,'会同县','0',323,0,'',1,0,'',NULL,0),(2207,'麻阳苗族自治县','0',323,0,'',1,0,'',NULL,0),(2208,'新晃侗族自治县','0',323,0,'',1,0,'',NULL,0),(2209,'芷江侗族自治县','0',323,0,'',1,0,'',NULL,0),(2210,'靖州苗族侗族自治县','0',323,0,'',1,0,'',NULL,0),(2211,'通道侗族自治县','0',323,0,'',1,0,'',NULL,0),(2212,'洪江市','0',323,0,'',1,0,'',NULL,0),(2213,'娄星区','0',324,0,'',1,0,'',NULL,0),(2214,'双峰县','0',324,0,'',1,0,'',NULL,0),(2215,'新化县','0',324,0,'',1,0,'',NULL,0),(2216,'冷水江市','0',324,0,'',1,0,'',NULL,0),(2217,'涟源市','0',324,0,'',1,0,'',NULL,0),(2218,'吉首市','0',325,0,'',1,0,'',NULL,0),(2219,'泸溪县','0',325,0,'',1,0,'',NULL,0),(2220,'凤凰县','0',325,0,'',1,0,'',NULL,0),(2221,'花垣县','0',325,0,'',1,0,'',NULL,0),(2222,'保靖县','0',325,0,'',1,0,'',NULL,0),(2223,'古丈县','0',325,0,'',1,0,'',NULL,0),(2224,'永顺县','0',325,0,'',1,0,'',NULL,0),(2225,'龙山县','0',325,0,'',1,0,'',NULL,0),(2226,'荔湾区','0',326,0,'',1,0,'',NULL,0),(2227,'越秀区','0',326,0,'',1,0,'',NULL,0),(2228,'海珠区','0',326,0,'',1,0,'',NULL,0),(2229,'天河区','0',326,0,'',1,0,'',NULL,0),(2230,'白云区','0',326,0,'',1,0,'',NULL,0),(2231,'黄埔区','0',326,0,'',1,0,'',NULL,0),(2232,'番禺区','0',326,0,'',1,0,'',NULL,0),(2233,'花都区','0',326,0,'',1,0,'',NULL,0),(2234,'南沙区','0',326,0,'',1,0,'',NULL,0),(2235,'萝岗区','0',326,0,'',1,0,'',NULL,0),(2236,'增城市','0',326,0,'',1,0,'',NULL,0),(2237,'从化市','0',326,0,'',1,0,'',NULL,0),(2238,'武江区','0',327,0,'',1,0,'',NULL,0),(2239,'浈江区','0',327,0,'',1,0,'',NULL,0),(2240,'曲江区','0',327,0,'',1,0,'',NULL,0),(2241,'始兴县','0',327,0,'',1,0,'',NULL,0),(2242,'仁化县','0',327,0,'',1,0,'',NULL,0),(2243,'翁源县','0',327,0,'',1,0,'',NULL,0),(2244,'乳源瑶族自治县','0',327,0,'',1,0,'',NULL,0),(2245,'新丰县','0',327,0,'',1,0,'',NULL,0),(2246,'乐昌市','0',327,0,'',1,0,'',NULL,0),(2247,'南雄市','0',327,0,'',1,0,'',NULL,0),(2248,'罗湖区','0',328,0,'',1,0,'',NULL,0),(2249,'福田区','0',328,0,'',1,0,'',NULL,0),(2250,'南山区','0',328,0,'',1,0,'',NULL,0),(2251,'宝安区','0',328,0,'',1,0,'',NULL,0),(2252,'龙岗区','0',328,0,'',1,0,'',NULL,0),(2253,'盐田区','0',328,0,'',1,0,'',NULL,0),(2254,'香洲区','0',329,0,'',1,0,'',NULL,0),(2255,'斗门区','0',329,0,'',1,0,'',NULL,0),(2256,'金湾区','0',329,0,'',1,0,'',NULL,0),(2257,'龙湖区','0',330,0,'',1,0,'',NULL,0),(2258,'金平区','0',330,0,'',1,0,'',NULL,0),(2259,'濠江区','0',330,0,'',1,0,'',NULL,0),(2260,'潮阳区','0',330,0,'',1,0,'',NULL,0),(2261,'潮南区','0',330,0,'',1,0,'',NULL,0),(2262,'澄海区','0',330,0,'',1,0,'',NULL,0),(2263,'南澳县','0',330,0,'',1,0,'',NULL,0),(2264,'禅城区','0',331,0,'',1,0,'',NULL,0),(2265,'南海区','0',331,0,'',1,0,'',NULL,0),(2266,'顺德区','0',331,0,'',1,0,'',NULL,0),(2267,'三水区','0',331,0,'',1,0,'',NULL,0),(2268,'高明区','0',331,0,'',1,0,'',NULL,0),(2269,'蓬江区','0',332,0,'',1,0,'',NULL,0),(2270,'江海区','0',332,0,'',1,0,'',NULL,0),(2271,'新会区','0',332,0,'',1,0,'',NULL,0),(2272,'台山市','0',332,0,'',1,0,'',NULL,0),(2273,'开平市','0',332,0,'',1,0,'',NULL,0),(2274,'鹤山市','0',332,0,'',1,0,'',NULL,0),(2275,'恩平市','0',332,0,'',1,0,'',NULL,0),(2276,'赤坎区','0',333,0,'',1,0,'',NULL,0),(2277,'霞山区','0',333,0,'',1,0,'',NULL,0),(2278,'坡头区','0',333,0,'',1,0,'',NULL,0),(2279,'麻章区','0',333,0,'',1,0,'',NULL,0),(2280,'遂溪县','0',333,0,'',1,0,'',NULL,0),(2281,'徐闻县','0',333,0,'',1,0,'',NULL,0),(2282,'廉江市','0',333,0,'',1,0,'',NULL,0),(2283,'雷州市','0',333,0,'',1,0,'',NULL,0),(2284,'吴川市','0',333,0,'',1,0,'',NULL,0),(2285,'茂南区','0',334,0,'',1,0,'',NULL,0),(2286,'茂港区','0',334,0,'',1,0,'',NULL,0),(2287,'电白县','0',334,0,'',1,0,'',NULL,0),(2288,'高州市','0',334,0,'',1,0,'',NULL,0),(2289,'化州市','0',334,0,'',1,0,'',NULL,0),(2290,'信宜市','0',334,0,'',1,0,'',NULL,0),(2291,'端州区','0',335,0,'',1,0,'',NULL,0),(2292,'鼎湖区','0',335,0,'',1,0,'',NULL,0),(2293,'广宁县','0',335,0,'',1,0,'',NULL,0),(2294,'怀集县','0',335,0,'',1,0,'',NULL,0),(2295,'封开县','0',335,0,'',1,0,'',NULL,0),(2296,'德庆县','0',335,0,'',1,0,'',NULL,0),(2297,'高要市','0',335,0,'',1,0,'',NULL,0),(2298,'四会市','0',335,0,'',1,0,'',NULL,0),(2299,'惠城区','0',336,0,'',1,0,'',NULL,0),(2300,'惠阳区','0',336,0,'',1,0,'',NULL,0),(2301,'博罗县','0',336,0,'',1,0,'',NULL,0),(2302,'惠东县','0',336,0,'',1,0,'',NULL,0),(2303,'龙门县','0',336,0,'',1,0,'',NULL,0),(2304,'梅江区','0',337,0,'',1,0,'',NULL,0),(2305,'梅县','0',337,0,'',1,0,'',NULL,0),(2306,'大埔县','0',337,0,'',1,0,'',NULL,0),(2307,'丰顺县','0',337,0,'',1,0,'',NULL,0),(2308,'五华县','0',337,0,'',1,0,'',NULL,0),(2309,'平远县','0',337,0,'',1,0,'',NULL,0),(2310,'蕉岭县','0',337,0,'',1,0,'',NULL,0),(2311,'兴宁市','0',337,0,'',1,0,'',NULL,0),(2312,'城区','0',338,0,'',1,0,'',NULL,0),(2313,'海丰县','0',338,0,'',1,0,'',NULL,0),(2314,'陆河县','0',338,0,'',1,0,'',NULL,0),(2315,'陆丰市','0',338,0,'',1,0,'',NULL,0),(2316,'源城区','0',339,0,'',1,0,'',NULL,0),(2317,'紫金县','0',339,0,'',1,0,'',NULL,0),(2318,'龙川县','0',339,0,'',1,0,'',NULL,0),(2319,'连平县','0',339,0,'',1,0,'',NULL,0),(2320,'和平县','0',339,0,'',1,0,'',NULL,0),(2321,'东源县','0',339,0,'',1,0,'',NULL,0),(2322,'江城区','0',340,0,'',1,0,'',NULL,0),(2323,'阳西县','0',340,0,'',1,0,'',NULL,0),(2324,'阳东县','0',340,0,'',1,0,'',NULL,0),(2325,'阳春市','0',340,0,'',1,0,'',NULL,0),(2326,'清城区','0',341,0,'',1,0,'',NULL,0),(2327,'佛冈县','0',341,0,'',1,0,'',NULL,0),(2328,'阳山县','0',341,0,'',1,0,'',NULL,0),(2329,'连山壮族瑶族自治县','0',341,0,'',1,0,'',NULL,0),(2330,'连南瑶族自治县','0',341,0,'',1,0,'',NULL,0),(2331,'清新县','0',341,0,'',1,0,'',NULL,0),(2332,'英德市','0',341,0,'',1,0,'',NULL,0),(2333,'连州市','0',341,0,'',1,0,'',NULL,0),(2334,'湘桥区','0',344,0,'',1,0,'',NULL,0),(2335,'潮安县','0',344,0,'',1,0,'',NULL,0),(2336,'饶平县','0',344,0,'',1,0,'',NULL,0),(2337,'榕城区','0',345,0,'',1,0,'',NULL,0),(2338,'揭东县','0',345,0,'',1,0,'',NULL,0),(2339,'揭西县','0',345,0,'',1,0,'',NULL,0),(2340,'惠来县','0',345,0,'',1,0,'',NULL,0),(2341,'普宁市','0',345,0,'',1,0,'',NULL,0),(2342,'云城区','0',346,0,'',1,0,'',NULL,0),(2343,'新兴县','0',346,0,'',1,0,'',NULL,0),(2344,'郁南县','0',346,0,'',1,0,'',NULL,0),(2345,'云安县','0',346,0,'',1,0,'',NULL,0),(2346,'罗定市','0',346,0,'',1,0,'',NULL,0),(2347,'兴宁区','0',347,0,'',1,0,'',NULL,0),(2348,'青秀区','0',347,0,'',1,0,'',NULL,0),(2349,'江南区','0',347,0,'',1,0,'',NULL,0),(2350,'西乡塘区','0',347,0,'',1,0,'',NULL,0),(2351,'良庆区','0',347,0,'',1,0,'',NULL,0),(2352,'邕宁区','0',347,0,'',1,0,'',NULL,0),(2353,'武鸣县','0',347,0,'',1,0,'',NULL,0),(2354,'隆安县','0',347,0,'',1,0,'',NULL,0),(2355,'马山县','0',347,0,'',1,0,'',NULL,0),(2356,'上林县','0',347,0,'',1,0,'',NULL,0),(2357,'宾阳县','0',347,0,'',1,0,'',NULL,0),(2358,'横县','0',347,0,'',1,0,'',NULL,0),(2359,'城中区','0',348,0,'',1,0,'',NULL,0),(2360,'鱼峰区','0',348,0,'',1,0,'',NULL,0),(2361,'柳南区','0',348,0,'',1,0,'',NULL,0),(2362,'柳北区','0',348,0,'',1,0,'',NULL,0),(2363,'柳江县','0',348,0,'',1,0,'',NULL,0),(2364,'柳城县','0',348,0,'',1,0,'',NULL,0),(2365,'鹿寨县','0',348,0,'',1,0,'',NULL,0),(2366,'融安县','0',348,0,'',1,0,'',NULL,0),(2367,'融水苗族自治县','0',348,0,'',1,0,'',NULL,0),(2368,'三江侗族自治县','0',348,0,'',1,0,'',NULL,0),(2369,'秀峰区','0',349,0,'',1,0,'',NULL,0),(2370,'叠彩区','0',349,0,'',1,0,'',NULL,0),(2371,'象山区','0',349,0,'',1,0,'',NULL,0),(2372,'七星区','0',349,0,'',1,0,'',NULL,0),(2373,'雁山区','0',349,0,'',1,0,'',NULL,0),(2374,'阳朔县','0',349,0,'',1,0,'',NULL,0),(2375,'临桂县','0',349,0,'',1,0,'',NULL,0),(2376,'灵川县','0',349,0,'',1,0,'',NULL,0),(2377,'全州县','0',349,0,'',1,0,'',NULL,0),(2378,'兴安县','0',349,0,'',1,0,'',NULL,0),(2379,'永福县','0',349,0,'',1,0,'',NULL,0),(2380,'灌阳县','0',349,0,'',1,0,'',NULL,0),(2381,'龙胜各族自治县','0',349,0,'',1,0,'',NULL,0),(2382,'资源县','0',349,0,'',1,0,'',NULL,0),(2383,'平乐县','0',349,0,'',1,0,'',NULL,0),(2384,'荔蒲县','0',349,0,'',1,0,'',NULL,0),(2385,'恭城瑶族自治县','0',349,0,'',1,0,'',NULL,0),(2386,'万秀区','0',350,0,'',1,0,'',NULL,0),(2387,'蝶山区','0',350,0,'',1,0,'',NULL,0),(2388,'长洲区','0',350,0,'',1,0,'',NULL,0),(2389,'苍梧县','0',350,0,'',1,0,'',NULL,0),(2390,'藤县','0',350,0,'',1,0,'',NULL,0),(2391,'蒙山县','0',350,0,'',1,0,'',NULL,0),(2392,'岑溪市','0',350,0,'',1,0,'',NULL,0),(2393,'海城区','0',351,0,'',1,0,'',NULL,0),(2394,'银海区','0',351,0,'',1,0,'',NULL,0),(2395,'铁山港区','0',351,0,'',1,0,'',NULL,0),(2396,'合浦县','0',351,0,'',1,0,'',NULL,0),(2397,'港口区','0',352,0,'',1,0,'',NULL,0),(2398,'防城区','0',352,0,'',1,0,'',NULL,0),(2399,'上思县','0',352,0,'',1,0,'',NULL,0),(2400,'东兴市','0',352,0,'',1,0,'',NULL,0),(2401,'钦南区','0',353,0,'',1,0,'',NULL,0),(2402,'钦北区','0',353,0,'',1,0,'',NULL,0),(2403,'灵山县','0',353,0,'',1,0,'',NULL,0),(2404,'浦北县','0',353,0,'',1,0,'',NULL,0),(2405,'港北区','0',354,0,'',1,0,'',NULL,0),(2406,'港南区','0',354,0,'',1,0,'',NULL,0),(2407,'覃塘区','0',354,0,'',1,0,'',NULL,0),(2408,'平南县','0',354,0,'',1,0,'',NULL,0),(2409,'桂平市','0',354,0,'',1,0,'',NULL,0),(2410,'玉州区','0',355,0,'',1,0,'',NULL,0),(2411,'容县','0',355,0,'',1,0,'',NULL,0),(2412,'陆川县','0',355,0,'',1,0,'',NULL,0),(2413,'博白县','0',355,0,'',1,0,'',NULL,0),(2414,'兴业县','0',355,0,'',1,0,'',NULL,0),(2415,'北流市','0',355,0,'',1,0,'',NULL,0),(2416,'右江区','0',356,0,'',1,0,'',NULL,0),(2417,'田阳县','0',356,0,'',1,0,'',NULL,0),(2418,'田东县','0',356,0,'',1,0,'',NULL,0),(2419,'平果县','0',356,0,'',1,0,'',NULL,0),(2420,'德保县','0',356,0,'',1,0,'',NULL,0),(2421,'靖西县','0',356,0,'',1,0,'',NULL,0),(2422,'那坡县','0',356,0,'',1,0,'',NULL,0),(2423,'凌云县','0',356,0,'',1,0,'',NULL,0),(2424,'乐业县','0',356,0,'',1,0,'',NULL,0),(2425,'田林县','0',356,0,'',1,0,'',NULL,0),(2426,'西林县','0',356,0,'',1,0,'',NULL,0),(2427,'隆林各族自治县','0',356,0,'',1,0,'',NULL,0),(2428,'八步区','0',357,0,'',1,0,'',NULL,0),(2429,'昭平县','0',357,0,'',1,0,'',NULL,0),(2430,'钟山县','0',357,0,'',1,0,'',NULL,0),(2431,'富川瑶族自治县','0',357,0,'',1,0,'',NULL,0),(2432,'金城江区','0',358,0,'',1,0,'',NULL,0),(2433,'南丹县','0',358,0,'',1,0,'',NULL,0),(2434,'天峨县','0',358,0,'',1,0,'',NULL,0),(2435,'凤山县','0',358,0,'',1,0,'',NULL,0),(2436,'东兰县','0',358,0,'',1,0,'',NULL,0),(2437,'罗城仫佬族自治县','0',358,0,'',1,0,'',NULL,0),(2438,'环江毛南族自治县','0',358,0,'',1,0,'',NULL,0),(2439,'巴马瑶族自治县','0',358,0,'',1,0,'',NULL,0),(2440,'都安瑶族自治县','0',358,0,'',1,0,'',NULL,0),(2441,'大化瑶族自治县','0',358,0,'',1,0,'',NULL,0),(2442,'宜州市','0',358,0,'',1,0,'',NULL,0),(2443,'兴宾区','0',359,0,'',1,0,'',NULL,0),(2444,'忻城县','0',359,0,'',1,0,'',NULL,0),(2445,'象州县','0',359,0,'',1,0,'',NULL,0),(2446,'武宣县','0',359,0,'',1,0,'',NULL,0),(2447,'金秀瑶族自治县','0',359,0,'',1,0,'',NULL,0),(2448,'合山市','0',359,0,'',1,0,'',NULL,0),(2449,'江洲区','0',360,0,'',1,0,'',NULL,0),(2450,'扶绥县','0',360,0,'',1,0,'',NULL,0),(2451,'宁明县','0',360,0,'',1,0,'',NULL,0),(2452,'龙州县','0',360,0,'',1,0,'',NULL,0),(2453,'大新县','0',360,0,'',1,0,'',NULL,0),(2454,'天等县','0',360,0,'',1,0,'',NULL,0),(2455,'凭祥市','0',360,0,'',1,0,'',NULL,0),(2456,'秀英区','0',361,0,'',1,0,'',NULL,0),(2457,'龙华区','0',361,0,'',1,0,'',NULL,0),(2458,'琼山区','0',361,0,'',1,0,'',NULL,0),(2459,'美兰区','0',361,0,'',1,0,'',NULL,0),(2460,'锦江区','0',382,0,'',1,0,'',NULL,0),(2461,'青羊区','0',382,0,'',1,0,'',NULL,0),(2462,'金牛区','0',382,0,'',1,0,'',NULL,0),(2463,'武侯区','0',382,0,'',1,0,'',NULL,0),(2464,'成华区','0',382,0,'',1,0,'',NULL,0),(2465,'龙泉驿区','0',382,0,'',1,0,'',NULL,0),(2466,'青白江区','0',382,0,'',1,0,'',NULL,0),(2467,'新都区','0',382,0,'',1,0,'',NULL,0),(2468,'温江区','0',382,0,'',1,0,'',NULL,0),(2469,'金堂县','0',382,0,'',1,0,'',NULL,0),(2470,'双流县','0',382,0,'',1,0,'',NULL,0),(2471,'郫县','0',382,0,'',1,0,'',NULL,0),(2472,'大邑县','0',382,0,'',1,0,'',NULL,0),(2473,'蒲江县','0',382,0,'',1,0,'',NULL,0),(2474,'新津县','0',382,0,'',1,0,'',NULL,0),(2475,'都江堰市','0',382,0,'',1,0,'',NULL,0),(2476,'彭州市','0',382,0,'',1,0,'',NULL,0),(2477,'邛崃市','0',382,0,'',1,0,'',NULL,0),(2478,'崇州市','0',382,0,'',1,0,'',NULL,0),(2479,'自流井区','0',383,0,'',1,0,'',NULL,0),(2480,'贡井区','0',383,0,'',1,0,'',NULL,0),(2481,'大安区','0',383,0,'',1,0,'',NULL,0),(2482,'沿滩区','0',383,0,'',1,0,'',NULL,0),(2483,'荣县','0',383,0,'',1,0,'',NULL,0),(2484,'富顺县','0',383,0,'',1,0,'',NULL,0),(2485,'东区','0',384,0,'',1,0,'',NULL,0),(2486,'西区','0',384,0,'',1,0,'',NULL,0),(2487,'仁和区','0',384,0,'',1,0,'',NULL,0),(2488,'米易县','0',384,0,'',1,0,'',NULL,0),(2489,'盐边县','0',384,0,'',1,0,'',NULL,0),(2490,'江阳区','0',385,0,'',1,0,'',NULL,0),(2491,'纳溪区','0',385,0,'',1,0,'',NULL,0),(2492,'龙马潭区','0',385,0,'',1,0,'',NULL,0),(2493,'泸县','0',385,0,'',1,0,'',NULL,0),(2494,'合江县','0',385,0,'',1,0,'',NULL,0),(2495,'叙永县','0',385,0,'',1,0,'',NULL,0),(2496,'古蔺县','0',385,0,'',1,0,'',NULL,0),(2497,'旌阳区','0',386,0,'',1,0,'',NULL,0),(2498,'中江县','0',386,0,'',1,0,'',NULL,0),(2499,'罗江县','0',386,0,'',1,0,'',NULL,0),(2500,'广汉市','0',386,0,'',1,0,'',NULL,0),(2501,'什邡市','0',386,0,'',1,0,'',NULL,0),(2502,'绵竹市','0',386,0,'',1,0,'',NULL,0),(2503,'涪城区','0',387,0,'',1,0,'',NULL,0),(2504,'游仙区','0',387,0,'',1,0,'',NULL,0),(2505,'三台县','0',387,0,'',1,0,'',NULL,0),(2506,'盐亭县','0',387,0,'',1,0,'',NULL,0),(2507,'安县','0',387,0,'',1,0,'',NULL,0),(2508,'梓潼县','0',387,0,'',1,0,'',NULL,0),(2509,'北川羌族自治县','0',387,0,'',1,0,'',NULL,0),(2510,'平武县','0',387,0,'',1,0,'',NULL,0),(2511,'江油市','0',387,0,'',1,0,'',NULL,0),(2512,'市中区','0',388,0,'',1,0,'',NULL,0),(2513,'元坝区','0',388,0,'',1,0,'',NULL,0),(2514,'朝天区','0',388,0,'',1,0,'',NULL,0),(2515,'旺苍县','0',388,0,'',1,0,'',NULL,0),(2516,'青川县','0',388,0,'',1,0,'',NULL,0),(2517,'剑阁县','0',388,0,'',1,0,'',NULL,0),(2518,'苍溪县','0',388,0,'',1,0,'',NULL,0),(2519,'船山区','0',389,0,'',1,0,'',NULL,0),(2520,'安居区','0',389,0,'',1,0,'',NULL,0),(2521,'蓬溪县','0',389,0,'',1,0,'',NULL,0),(2522,'射洪县','0',389,0,'',1,0,'',NULL,0),(2523,'大英县','0',389,0,'',1,0,'',NULL,0),(2524,'市中区','0',390,0,'',1,0,'',NULL,0),(2525,'东兴区','0',390,0,'',1,0,'',NULL,0),(2526,'威远县','0',390,0,'',1,0,'',NULL,0),(2527,'资中县','0',390,0,'',1,0,'',NULL,0),(2528,'隆昌县','0',390,0,'',1,0,'',NULL,0),(2529,'市中区','0',391,0,'',1,0,'',NULL,0),(2530,'沙湾区','0',391,0,'',1,0,'',NULL,0),(2531,'五通桥区','0',391,0,'',1,0,'',NULL,0),(2532,'金口河区','0',391,0,'',1,0,'',NULL,0),(2533,'犍为县','0',391,0,'',1,0,'',NULL,0),(2534,'井研县','0',391,0,'',1,0,'',NULL,0),(2535,'夹江县','0',391,0,'',1,0,'',NULL,0),(2536,'沐川县','0',391,0,'',1,0,'',NULL,0),(2537,'峨边彝族自治县','0',391,0,'',1,0,'',NULL,0),(2538,'马边彝族自治县','0',391,0,'',1,0,'',NULL,0),(2539,'峨眉山市','0',391,0,'',1,0,'',NULL,0),(2540,'顺庆区','0',392,0,'',1,0,'',NULL,0),(2541,'高坪区','0',392,0,'',1,0,'',NULL,0),(2542,'嘉陵区','0',392,0,'',1,0,'',NULL,0),(2543,'南部县','0',392,0,'',1,0,'',NULL,0),(2544,'营山县','0',392,0,'',1,0,'',NULL,0),(2545,'蓬安县','0',392,0,'',1,0,'',NULL,0),(2546,'仪陇县','0',392,0,'',1,0,'',NULL,0),(2547,'西充县','0',392,0,'',1,0,'',NULL,0),(2548,'阆中市','0',392,0,'',1,0,'',NULL,0),(2549,'东坡区','0',393,0,'',1,0,'',NULL,0),(2550,'仁寿县','0',393,0,'',1,0,'',NULL,0),(2551,'彭山县','0',393,0,'',1,0,'',NULL,0),(2552,'洪雅县','0',393,0,'',1,0,'',NULL,0),(2553,'丹棱县','0',393,0,'',1,0,'',NULL,0),(2554,'青神县','0',393,0,'',1,0,'',NULL,0),(2555,'翠屏区','0',394,0,'',1,0,'',NULL,0),(2556,'宜宾县','0',394,0,'',1,0,'',NULL,0),(2557,'南溪县','0',394,0,'',1,0,'',NULL,0),(2558,'江安县','0',394,0,'',1,0,'',NULL,0),(2559,'长宁县','0',394,0,'',1,0,'',NULL,0),(2560,'高县','0',394,0,'',1,0,'',NULL,0),(2561,'珙县','0',394,0,'',1,0,'',NULL,0),(2562,'筠连县','0',394,0,'',1,0,'',NULL,0),(2563,'兴文县','0',394,0,'',1,0,'',NULL,0),(2564,'屏山县','0',394,0,'',1,0,'',NULL,0),(2565,'广安区','0',395,0,'',1,0,'',NULL,0),(2566,'岳池县','0',395,0,'',1,0,'',NULL,0),(2567,'武胜县','0',395,0,'',1,0,'',NULL,0),(2568,'邻水县','0',395,0,'',1,0,'',NULL,0),(2569,'华蓥市','0',395,0,'',1,0,'',NULL,0),(2570,'通川区','0',396,0,'',1,0,'',NULL,0),(2571,'达县','0',396,0,'',1,0,'',NULL,0),(2572,'宣汉县','0',396,0,'',1,0,'',NULL,0),(2573,'开江县','0',396,0,'',1,0,'',NULL,0),(2574,'大竹县','0',396,0,'',1,0,'',NULL,0),(2575,'渠县','0',396,0,'',1,0,'',NULL,0),(2576,'万源市','0',396,0,'',1,0,'',NULL,0),(2577,'雨城区','0',397,0,'',1,0,'',NULL,0),(2578,'名山县','0',397,0,'',1,0,'',NULL,0),(2579,'荥经县','0',397,0,'',1,0,'',NULL,0),(2580,'汉源县','0',397,0,'',1,0,'',NULL,0),(2581,'石棉县','0',397,0,'',1,0,'',NULL,0),(2582,'天全县','0',397,0,'',1,0,'',NULL,0),(2583,'芦山县','0',397,0,'',1,0,'',NULL,0),(2584,'宝兴县','0',397,0,'',1,0,'',NULL,0),(2585,'巴州区','0',398,0,'',1,0,'',NULL,0),(2586,'通江县','0',398,0,'',1,0,'',NULL,0),(2587,'南江县','0',398,0,'',1,0,'',NULL,0),(2588,'平昌县','0',398,0,'',1,0,'',NULL,0),(2589,'雁江区','0',399,0,'',1,0,'',NULL,0),(2590,'安岳县','0',399,0,'',1,0,'',NULL,0),(2591,'乐至县','0',399,0,'',1,0,'',NULL,0),(2592,'简阳市','0',399,0,'',1,0,'',NULL,0),(2593,'汶川县','0',400,0,'',1,0,'',NULL,0),(2594,'理县','0',400,0,'',1,0,'',NULL,0),(2595,'茂县','0',400,0,'',1,0,'',NULL,0),(2596,'松潘县','0',400,0,'',1,0,'',NULL,0),(2597,'九寨沟县','0',400,0,'',1,0,'',NULL,0),(2598,'金川县','0',400,0,'',1,0,'',NULL,0),(2599,'小金县','0',400,0,'',1,0,'',NULL,0),(2600,'黑水县','0',400,0,'',1,0,'',NULL,0),(2601,'马尔康县','0',400,0,'',1,0,'',NULL,0),(2602,'壤塘县','0',400,0,'',1,0,'',NULL,0),(2603,'阿坝县','0',400,0,'',1,0,'',NULL,0),(2604,'若尔盖县','0',400,0,'',1,0,'',NULL,0),(2605,'红原县','0',400,0,'',1,0,'',NULL,0),(2606,'康定县','0',401,0,'',1,0,'',NULL,0),(2607,'泸定县','0',401,0,'',1,0,'',NULL,0),(2608,'丹巴县','0',401,0,'',1,0,'',NULL,0),(2609,'九龙县','0',401,0,'',1,0,'',NULL,0),(2610,'雅江县','0',401,0,'',1,0,'',NULL,0),(2611,'道孚县','0',401,0,'',1,0,'',NULL,0),(2612,'炉霍县','0',401,0,'',1,0,'',NULL,0),(2613,'甘孜县','0',401,0,'',1,0,'',NULL,0),(2614,'新龙县','0',401,0,'',1,0,'',NULL,0),(2615,'德格县','0',401,0,'',1,0,'',NULL,0),(2616,'白玉县','0',401,0,'',1,0,'',NULL,0),(2617,'石渠县','0',401,0,'',1,0,'',NULL,0),(2618,'色达县','0',401,0,'',1,0,'',NULL,0),(2619,'理塘县','0',401,0,'',1,0,'',NULL,0),(2620,'巴塘县','0',401,0,'',1,0,'',NULL,0),(2621,'乡城县','0',401,0,'',1,0,'',NULL,0),(2622,'稻城县','0',401,0,'',1,0,'',NULL,0),(2623,'得荣县','0',401,0,'',1,0,'',NULL,0),(2624,'西昌市','0',402,0,'',1,0,'',NULL,0),(2625,'木里藏族自治县','0',402,0,'',1,0,'',NULL,0),(2626,'盐源县','0',402,0,'',1,0,'',NULL,0),(2627,'德昌县','0',402,0,'',1,0,'',NULL,0),(2628,'会理县','0',402,0,'',1,0,'',NULL,0),(2629,'会东县','0',402,0,'',1,0,'',NULL,0),(2630,'宁南县','0',402,0,'',1,0,'',NULL,0),(2631,'普格县','0',402,0,'',1,0,'',NULL,0),(2632,'布拖县','0',402,0,'',1,0,'',NULL,0),(2633,'金阳县','0',402,0,'',1,0,'',NULL,0),(2634,'昭觉县','0',402,0,'',1,0,'',NULL,0),(2635,'喜德县','0',402,0,'',1,0,'',NULL,0),(2636,'冕宁县','0',402,0,'',1,0,'',NULL,0),(2637,'越西县','0',402,0,'',1,0,'',NULL,0),(2638,'甘洛县','0',402,0,'',1,0,'',NULL,0),(2639,'美姑县','0',402,0,'',1,0,'',NULL,0),(2640,'雷波县','0',402,0,'',1,0,'',NULL,0),(2641,'南明区','0',403,0,'',1,0,'',NULL,0),(2642,'云岩区','0',403,0,'',1,0,'',NULL,0),(2643,'花溪区','0',403,0,'',1,0,'',NULL,0),(2644,'乌当区','0',403,0,'',1,0,'',NULL,0),(2645,'白云区','0',403,0,'',1,0,'',NULL,0),(2646,'小河区','0',403,0,'',1,0,'',NULL,0),(2647,'开阳县','0',403,0,'',1,0,'',NULL,0),(2648,'息烽县','0',403,0,'',1,0,'',NULL,0),(2649,'修文县','0',403,0,'',1,0,'',NULL,0),(2650,'清镇市','0',403,0,'',1,0,'',NULL,0),(2651,'钟山区','0',404,0,'',1,0,'',NULL,0),(2652,'六枝特区','0',404,0,'',1,0,'',NULL,0),(2653,'水城县','0',404,0,'',1,0,'',NULL,0),(2654,'盘县','0',404,0,'',1,0,'',NULL,0),(2655,'红花岗区','0',405,0,'',1,0,'',NULL,0),(2656,'汇川区','0',405,0,'',1,0,'',NULL,0),(2657,'遵义县','0',405,0,'',1,0,'',NULL,0),(2658,'桐梓县','0',405,0,'',1,0,'',NULL,0),(2659,'绥阳县','0',405,0,'',1,0,'',NULL,0),(2660,'正安县','0',405,0,'',1,0,'',NULL,0),(2661,'道真仡佬族苗族自治县','0',405,0,'',1,0,'',NULL,0),(2662,'务川仡佬族苗族自治县','0',405,0,'',1,0,'',NULL,0),(2663,'凤冈县','0',405,0,'',1,0,'',NULL,0),(2664,'湄潭县','0',405,0,'',1,0,'',NULL,0),(2665,'余庆县','0',405,0,'',1,0,'',NULL,0),(2666,'习水县','0',405,0,'',1,0,'',NULL,0),(2667,'赤水市','0',405,0,'',1,0,'',NULL,0),(2668,'仁怀市','0',405,0,'',1,0,'',NULL,0),(2669,'西秀区','0',406,0,'',1,0,'',NULL,0),(2670,'平坝县','0',406,0,'',1,0,'',NULL,0),(2671,'普定县','0',406,0,'',1,0,'',NULL,0),(2672,'镇宁布依族苗族自治县','0',406,0,'',1,0,'',NULL,0),(2673,'关岭布依族苗族自治县','0',406,0,'',1,0,'',NULL,0),(2674,'紫云苗族布依族自治县','0',406,0,'',1,0,'',NULL,0),(2675,'铜仁市','0',407,0,'',1,0,'',NULL,0),(2676,'江口县','0',407,0,'',1,0,'',NULL,0),(2677,'玉屏侗族自治县','0',407,0,'',1,0,'',NULL,0),(2678,'石阡县','0',407,0,'',1,0,'',NULL,0),(2679,'思南县','0',407,0,'',1,0,'',NULL,0),(2680,'印江土家族苗族自治县','0',407,0,'',1,0,'',NULL,0),(2681,'德江县','0',407,0,'',1,0,'',NULL,0),(2682,'沿河土家族自治县','0',407,0,'',1,0,'',NULL,0),(2683,'松桃苗族自治县','0',407,0,'',1,0,'',NULL,0),(2684,'万山特区','0',407,0,'',1,0,'',NULL,0),(2685,'兴义市','0',408,0,'',1,0,'',NULL,0),(2686,'兴仁县','0',408,0,'',1,0,'',NULL,0),(2687,'普安县','0',408,0,'',1,0,'',NULL,0),(2688,'晴隆县','0',408,0,'',1,0,'',NULL,0),(2689,'贞丰县','0',408,0,'',1,0,'',NULL,0),(2690,'望谟县','0',408,0,'',1,0,'',NULL,0),(2691,'册亨县','0',408,0,'',1,0,'',NULL,0),(2692,'安龙县','0',408,0,'',1,0,'',NULL,0),(2693,'毕节市','0',409,0,'',1,0,'',NULL,0),(2694,'大方县','0',409,0,'',1,0,'',NULL,0),(2695,'黔西县','0',409,0,'',1,0,'',NULL,0),(2696,'金沙县','0',409,0,'',1,0,'',NULL,0),(2697,'织金县','0',409,0,'',1,0,'',NULL,0),(2698,'纳雍县','0',409,0,'',1,0,'',NULL,0),(2699,'威宁彝族回族苗族自治县','0',409,0,'',1,0,'',NULL,0),(2700,'赫章县','0',409,0,'',1,0,'',NULL,0),(2701,'凯里市','0',410,0,'',1,0,'',NULL,0),(2702,'黄平县','0',410,0,'',1,0,'',NULL,0),(2703,'施秉县','0',410,0,'',1,0,'',NULL,0),(2704,'三穗县','0',410,0,'',1,0,'',NULL,0),(2705,'镇远县','0',410,0,'',1,0,'',NULL,0),(2706,'岑巩县','0',410,0,'',1,0,'',NULL,0),(2707,'天柱县','0',410,0,'',1,0,'',NULL,0),(2708,'锦屏县','0',410,0,'',1,0,'',NULL,0),(2709,'剑河县','0',410,0,'',1,0,'',NULL,0),(2710,'台江县','0',410,0,'',1,0,'',NULL,0),(2711,'黎平县','0',410,0,'',1,0,'',NULL,0),(2712,'榕江县','0',410,0,'',1,0,'',NULL,0),(2713,'从江县','0',410,0,'',1,0,'',NULL,0),(2714,'雷山县','0',410,0,'',1,0,'',NULL,0),(2715,'麻江县','0',410,0,'',1,0,'',NULL,0),(2716,'丹寨县','0',410,0,'',1,0,'',NULL,0),(2717,'都匀市','0',411,0,'',1,0,'',NULL,0),(2718,'福泉市','0',411,0,'',1,0,'',NULL,0),(2719,'荔波县','0',411,0,'',1,0,'',NULL,0),(2720,'贵定县','0',411,0,'',1,0,'',NULL,0),(2721,'瓮安县','0',411,0,'',1,0,'',NULL,0),(2722,'独山县','0',411,0,'',1,0,'',NULL,0),(2723,'平塘县','0',411,0,'',1,0,'',NULL,0),(2724,'罗甸县','0',411,0,'',1,0,'',NULL,0),(2725,'长顺县','0',411,0,'',1,0,'',NULL,0),(2726,'龙里县','0',411,0,'',1,0,'',NULL,0),(2727,'惠水县','0',411,0,'',1,0,'',NULL,0),(2728,'三都水族自治县','0',411,0,'',1,0,'',NULL,0),(2729,'五华区','0',412,0,'',1,0,'',NULL,0),(2730,'盘龙区','0',412,0,'',1,0,'',NULL,0),(2731,'官渡区','0',412,0,'',1,0,'',NULL,0),(2732,'西山区','0',412,0,'',1,0,'',NULL,0),(2733,'东川区','0',412,0,'',1,0,'',NULL,0),(2734,'呈贡县','0',412,0,'',1,0,'',NULL,0),(2735,'晋宁县','0',412,0,'',1,0,'',NULL,0),(2736,'富民县','0',412,0,'',1,0,'',NULL,0),(2737,'宜良县','0',412,0,'',1,0,'',NULL,0),(2738,'石林彝族自治县','0',412,0,'',1,0,'',NULL,0),(2739,'嵩明县','0',412,0,'',1,0,'',NULL,0),(2740,'禄劝彝族苗族自治县','0',412,0,'',1,0,'',NULL,0),(2741,'寻甸回族彝族自治县','0',412,0,'',1,0,'',NULL,0),(2742,'安宁市','0',412,0,'',1,0,'',NULL,0),(2743,'麒麟区','0',413,0,'',1,0,'',NULL,0),(2744,'马龙县','0',413,0,'',1,0,'',NULL,0),(2745,'陆良县','0',413,0,'',1,0,'',NULL,0),(2746,'师宗县','0',413,0,'',1,0,'',NULL,0),(2747,'罗平县','0',413,0,'',1,0,'',NULL,0),(2748,'富源县','0',413,0,'',1,0,'',NULL,0),(2749,'会泽县','0',413,0,'',1,0,'',NULL,0),(2750,'沾益县','0',413,0,'',1,0,'',NULL,0),(2751,'宣威市','0',413,0,'',1,0,'',NULL,0),(2752,'红塔区','0',414,0,'',1,0,'',NULL,0),(2753,'江川县','0',414,0,'',1,0,'',NULL,0),(2754,'澄江县','0',414,0,'',1,0,'',NULL,0),(2755,'通海县','0',414,0,'',1,0,'',NULL,0),(2756,'华宁县','0',414,0,'',1,0,'',NULL,0),(2757,'易门县','0',414,0,'',1,0,'',NULL,0),(2758,'峨山彝族自治县','0',414,0,'',1,0,'',NULL,0),(2759,'新平彝族傣族自治县','0',414,0,'',1,0,'',NULL,0),(2760,'元江哈尼族彝族傣族自治县','0',414,0,'',1,0,'',NULL,0),(2761,'隆阳区','0',415,0,'',1,0,'',NULL,0),(2762,'施甸县','0',415,0,'',1,0,'',NULL,0),(2763,'腾冲县','0',415,0,'',1,0,'',NULL,0),(2764,'龙陵县','0',415,0,'',1,0,'',NULL,0),(2765,'昌宁县','0',415,0,'',1,0,'',NULL,0),(2766,'昭阳区','0',416,0,'',1,0,'',NULL,0),(2767,'鲁甸县','0',416,0,'',1,0,'',NULL,0),(2768,'巧家县','0',416,0,'',1,0,'',NULL,0),(2769,'盐津县','0',416,0,'',1,0,'',NULL,0),(2770,'大关县','0',416,0,'',1,0,'',NULL,0),(2771,'永善县','0',416,0,'',1,0,'',NULL,0),(2772,'绥江县','0',416,0,'',1,0,'',NULL,0),(2773,'镇雄县','0',416,0,'',1,0,'',NULL,0),(2774,'彝良县','0',416,0,'',1,0,'',NULL,0),(2775,'威信县','0',416,0,'',1,0,'',NULL,0),(2776,'水富县','0',416,0,'',1,0,'',NULL,0),(2777,'古城区','0',417,0,'',1,0,'',NULL,0),(2778,'玉龙纳西族自治县','0',417,0,'',1,0,'',NULL,0),(2779,'永胜县','0',417,0,'',1,0,'',NULL,0),(2780,'华坪县','0',417,0,'',1,0,'',NULL,0),(2781,'宁蒗彝族自治县','0',417,0,'',1,0,'',NULL,0),(2782,'翠云区','0',418,0,'',1,0,'',NULL,0),(2783,'普洱哈尼族彝族自治县','0',418,0,'',1,0,'',NULL,0),(2784,'墨江哈尼族自治县','0',418,0,'',1,0,'',NULL,0),(2785,'景东彝族自治县','0',418,0,'',1,0,'',NULL,0),(2786,'景谷傣族彝族自治县','0',418,0,'',1,0,'',NULL,0),(2787,'镇沅彝族哈尼族拉祜族自治县','0',418,0,'',1,0,'',NULL,0),(2788,'江城哈尼族彝族自治县','0',418,0,'',1,0,'',NULL,0),(2789,'孟连傣族拉祜族佤族自治县','0',418,0,'',1,0,'',NULL,0),(2790,'澜沧拉祜族自治县','0',418,0,'',1,0,'',NULL,0),(2791,'西盟佤族自治县','0',418,0,'',1,0,'',NULL,0),(2792,'临翔区','0',419,0,'',1,0,'',NULL,0),(2793,'凤庆县','0',419,0,'',1,0,'',NULL,0),(2794,'云县','0',419,0,'',1,0,'',NULL,0),(2795,'永德县','0',419,0,'',1,0,'',NULL,0),(2796,'镇康县','0',419,0,'',1,0,'',NULL,0),(2797,'双江拉祜族佤族布朗族傣族自治县','0',419,0,'',1,0,'',NULL,0),(2798,'耿马傣族佤族自治县','0',419,0,'',1,0,'',NULL,0),(2799,'沧源佤族自治县','0',420,0,'',1,0,'',NULL,0),(2800,'楚雄市','0',420,0,'',1,0,'',NULL,0),(2801,'双柏县','0',420,0,'',1,0,'',NULL,0),(2802,'牟定县','0',420,0,'',1,0,'',NULL,0),(2803,'南华县','0',420,0,'',1,0,'',NULL,0),(2804,'姚安县','0',420,0,'',1,0,'',NULL,0),(2805,'大姚县','0',420,0,'',1,0,'',NULL,0),(2806,'永仁县','0',420,0,'',1,0,'',NULL,0),(2807,'元谋县','0',420,0,'',1,0,'',NULL,0),(2808,'武定县','0',420,0,'',1,0,'',NULL,0),(2809,'禄丰县','0',420,0,'',1,0,'',NULL,0),(2810,'个旧市','0',421,0,'',1,0,'',NULL,0),(2811,'开远市','0',421,0,'',1,0,'',NULL,0),(2812,'蒙自县','0',421,0,'',1,0,'',NULL,0),(2813,'屏边苗族自治县','0',421,0,'',1,0,'',NULL,0),(2814,'建水县','0',421,0,'',1,0,'',NULL,0),(2815,'石屏县','0',421,0,'',1,0,'',NULL,0),(2816,'弥勒县','0',421,0,'',1,0,'',NULL,0),(2817,'泸西县','0',421,0,'',1,0,'',NULL,0),(2818,'元阳县','0',421,0,'',1,0,'',NULL,0),(2819,'红河县','0',421,0,'',1,0,'',NULL,0),(2820,'金平苗族瑶族傣族自治县','0',421,0,'',1,0,'',NULL,0),(2821,'绿春县','0',421,0,'',1,0,'',NULL,0),(2822,'河口瑶族自治县','0',421,0,'',1,0,'',NULL,0),(2823,'文山县','0',422,0,'',1,0,'',NULL,0),(2824,'砚山县','0',422,0,'',1,0,'',NULL,0),(2825,'西畴县','0',422,0,'',1,0,'',NULL,0),(2826,'麻栗坡县','0',422,0,'',1,0,'',NULL,0),(2827,'马关县','0',422,0,'',1,0,'',NULL,0),(2828,'丘北县','0',422,0,'',1,0,'',NULL,0),(2829,'广南县','0',422,0,'',1,0,'',NULL,0),(2830,'富宁县','0',422,0,'',1,0,'',NULL,0),(2831,'景洪市','0',423,0,'',1,0,'',NULL,0),(2832,'勐海县','0',423,0,'',1,0,'',NULL,0),(2833,'勐腊县','0',423,0,'',1,0,'',NULL,0),(2834,'大理市','0',424,0,'',1,0,'',NULL,0),(2835,'漾濞彝族自治县','0',424,0,'',1,0,'',NULL,0),(2836,'祥云县','0',424,0,'',1,0,'',NULL,0),(2837,'宾川县','0',424,0,'',1,0,'',NULL,0),(2838,'弥渡县','0',424,0,'',1,0,'',NULL,0),(2839,'南涧彝族自治县','0',424,0,'',1,0,'',NULL,0),(2840,'巍山彝族回族自治县','0',424,0,'',1,0,'',NULL,0),(2841,'永平县','0',424,0,'',1,0,'',NULL,0),(2842,'云龙县','0',424,0,'',1,0,'',NULL,0),(2843,'洱源县','0',424,0,'',1,0,'',NULL,0),(2844,'剑川县','0',424,0,'',1,0,'',NULL,0),(2845,'鹤庆县','0',424,0,'',1,0,'',NULL,0),(2846,'瑞丽市','0',425,0,'',1,0,'',NULL,0),(2847,'潞西市','0',425,0,'',1,0,'',NULL,0),(2848,'梁河县','0',425,0,'',1,0,'',NULL,0),(2849,'盈江县','0',425,0,'',1,0,'',NULL,0),(2850,'陇川县','0',425,0,'',1,0,'',NULL,0),(2851,'泸水县','0',426,0,'',1,0,'',NULL,0),(2852,'福贡县','0',426,0,'',1,0,'',NULL,0),(2853,'贡山独龙族怒族自治县','0',426,0,'',1,0,'',NULL,0),(2854,'兰坪白族普米族自治县','0',426,0,'',1,0,'',NULL,0),(2855,'香格里拉县','0',427,0,'',1,0,'',NULL,0),(2856,'德钦县','0',427,0,'',1,0,'',NULL,0),(2857,'维西傈僳族自治县','0',427,0,'',1,0,'',NULL,0),(2858,'城关区','0',428,0,'',1,0,'',NULL,0),(2859,'林周县','0',428,0,'',1,0,'',NULL,0),(2860,'当雄县','0',428,0,'',1,0,'',NULL,0),(2861,'尼木县','0',428,0,'',1,0,'',NULL,0),(2862,'曲水县','0',428,0,'',1,0,'',NULL,0),(2863,'堆龙德庆县','0',428,0,'',1,0,'',NULL,0),(2864,'达孜县','0',428,0,'',1,0,'',NULL,0),(2865,'墨竹工卡县','0',428,0,'',1,0,'',NULL,0),(2866,'昌都县','0',429,0,'',1,0,'',NULL,0),(2867,'江达县','0',429,0,'',1,0,'',NULL,0),(2868,'贡觉县','0',429,0,'',1,0,'',NULL,0),(2869,'类乌齐县','0',429,0,'',1,0,'',NULL,0),(2870,'丁青县','0',429,0,'',1,0,'',NULL,0),(2871,'察雅县','0',429,0,'',1,0,'',NULL,0),(2872,'八宿县','0',429,0,'',1,0,'',NULL,0),(2873,'左贡县','0',429,0,'',1,0,'',NULL,0),(2874,'芒康县','0',429,0,'',1,0,'',NULL,0),(2875,'洛隆县','0',429,0,'',1,0,'',NULL,0),(2876,'边坝县','0',429,0,'',1,0,'',NULL,0),(2877,'乃东县','0',430,0,'',1,0,'',NULL,0),(2878,'扎囊县','0',430,0,'',1,0,'',NULL,0),(2879,'贡嘎县','0',430,0,'',1,0,'',NULL,0),(2880,'桑日县','0',430,0,'',1,0,'',NULL,0),(2881,'琼结县','0',430,0,'',1,0,'',NULL,0),(2882,'曲松县','0',430,0,'',1,0,'',NULL,0),(2883,'措美县','0',430,0,'',1,0,'',NULL,0),(2884,'洛扎县','0',430,0,'',1,0,'',NULL,0),(2885,'加查县','0',430,0,'',1,0,'',NULL,0),(2886,'隆子县','0',430,0,'',1,0,'',NULL,0),(2887,'错那县','0',430,0,'',1,0,'',NULL,0),(2888,'浪卡子县','0',430,0,'',1,0,'',NULL,0),(2889,'日喀则市','0',431,0,'',1,0,'',NULL,0),(2890,'南木林县','0',431,0,'',1,0,'',NULL,0),(2891,'江孜县','0',431,0,'',1,0,'',NULL,0),(2892,'定日县','0',431,0,'',1,0,'',NULL,0),(2893,'萨迦县','0',431,0,'',1,0,'',NULL,0),(2894,'拉孜县','0',431,0,'',1,0,'',NULL,0),(2895,'昂仁县','0',431,0,'',1,0,'',NULL,0),(2896,'谢通门县','0',431,0,'',1,0,'',NULL,0),(2897,'白朗县','0',431,0,'',1,0,'',NULL,0),(2898,'仁布县','0',431,0,'',1,0,'',NULL,0),(2899,'康马县','0',431,0,'',1,0,'',NULL,0),(2900,'定结县','0',431,0,'',1,0,'',NULL,0),(2901,'仲巴县','0',431,0,'',1,0,'',NULL,0),(2902,'亚东县','0',431,0,'',1,0,'',NULL,0),(2903,'吉隆县','0',431,0,'',1,0,'',NULL,0),(2904,'聂拉木县','0',431,0,'',1,0,'',NULL,0),(2905,'萨嘎县','0',431,0,'',1,0,'',NULL,0),(2906,'岗巴县','0',431,0,'',1,0,'',NULL,0),(2907,'那曲县','0',432,0,'',1,0,'',NULL,0),(2908,'嘉黎县','0',432,0,'',1,0,'',NULL,0),(2909,'比如县','0',432,0,'',1,0,'',NULL,0),(2910,'聂荣县','0',432,0,'',1,0,'',NULL,0),(2911,'安多县','0',432,0,'',1,0,'',NULL,0),(2912,'申扎县','0',432,0,'',1,0,'',NULL,0),(2913,'索县','0',432,0,'',1,0,'',NULL,0),(2914,'班戈县','0',432,0,'',1,0,'',NULL,0),(2915,'巴青县','0',432,0,'',1,0,'',NULL,0),(2916,'尼玛县','0',432,0,'',1,0,'',NULL,0),(2917,'普兰县','0',433,0,'',1,0,'',NULL,0),(2918,'札达县','0',433,0,'',1,0,'',NULL,0),(2919,'噶尔县','0',433,0,'',1,0,'',NULL,0),(2920,'日土县','0',433,0,'',1,0,'',NULL,0),(2921,'革吉县','0',433,0,'',1,0,'',NULL,0),(2922,'改则县','0',433,0,'',1,0,'',NULL,0),(2923,'措勤县','0',433,0,'',1,0,'',NULL,0),(2924,'林芝县','0',434,0,'',1,0,'',NULL,0),(2925,'工布江达县','0',434,0,'',1,0,'',NULL,0),(2926,'米林县','0',434,0,'',1,0,'',NULL,0),(2927,'墨脱县','0',434,0,'',1,0,'',NULL,0),(2928,'波密县','0',434,0,'',1,0,'',NULL,0),(2929,'察隅县','0',434,0,'',1,0,'',NULL,0),(2930,'朗县','0',434,0,'',1,0,'',NULL,0),(2931,'新城区','0',435,0,'',1,0,'',NULL,0),(2932,'碑林区','0',435,0,'',1,0,'',NULL,0),(2933,'莲湖区','0',435,0,'',1,0,'',NULL,0),(2934,'灞桥区','0',435,0,'',1,0,'',NULL,0),(2935,'未央区','0',435,0,'',1,0,'',NULL,0),(2936,'雁塔区','0',435,0,'',1,0,'',NULL,0),(2937,'阎良区','0',435,0,'',1,0,'',NULL,0),(2938,'临潼区','0',435,0,'',1,0,'',NULL,0),(2939,'长安区','0',435,0,'',1,0,'',NULL,0),(2940,'蓝田县','0',435,0,'',1,0,'',NULL,0),(2941,'周至县','0',435,0,'',1,0,'',NULL,0),(2942,'户县','0',435,0,'',1,0,'',NULL,0),(2943,'高陵县','0',435,0,'',1,0,'',NULL,0),(2944,'王益区','0',436,0,'',1,0,'',NULL,0),(2945,'印台区','0',436,0,'',1,0,'',NULL,0),(2946,'耀州区','0',436,0,'',1,0,'',NULL,0),(2947,'宜君县','0',436,0,'',1,0,'',NULL,0),(2948,'渭滨区','0',437,0,'',1,0,'',NULL,0),(2949,'金台区','0',437,0,'',1,0,'',NULL,0),(2950,'陈仓区','0',437,0,'',1,0,'',NULL,0),(2951,'凤翔县','0',437,0,'',1,0,'',NULL,0),(2952,'岐山县','0',437,0,'',1,0,'',NULL,0),(2953,'扶风县','0',437,0,'',1,0,'',NULL,0),(2954,'眉县','0',437,0,'',1,0,'',NULL,0),(2955,'陇县','0',437,0,'',1,0,'',NULL,0),(2956,'千阳县','0',437,0,'',1,0,'',NULL,0),(2957,'麟游县','0',437,0,'',1,0,'',NULL,0),(2958,'凤县','0',437,0,'',1,0,'',NULL,0),(2959,'太白县','0',437,0,'',1,0,'',NULL,0),(2960,'秦都区','0',438,0,'',1,0,'',NULL,0),(2961,'杨凌区','0',438,0,'',1,0,'',NULL,0),(2962,'渭城区','0',438,0,'',1,0,'',NULL,0),(2963,'三原县','0',438,0,'',1,0,'',NULL,0),(2964,'泾阳县','0',438,0,'',1,0,'',NULL,0),(2965,'乾县','0',438,0,'',1,0,'',NULL,0),(2966,'礼泉县','0',438,0,'',1,0,'',NULL,0),(2967,'永寿县','0',438,0,'',1,0,'',NULL,0),(2968,'彬县','0',438,0,'',1,0,'',NULL,0),(2969,'长武县','0',438,0,'',1,0,'',NULL,0),(2970,'旬邑县','0',438,0,'',1,0,'',NULL,0),(2971,'淳化县','0',438,0,'',1,0,'',NULL,0),(2972,'武功县','0',438,0,'',1,0,'',NULL,0),(2973,'兴平市','0',438,0,'',1,0,'',NULL,0),(2974,'临渭区','0',439,0,'',1,0,'',NULL,0),(2975,'华县','0',439,0,'',1,0,'',NULL,0),(2976,'潼关县','0',439,0,'',1,0,'',NULL,0),(2977,'大荔县','0',439,0,'',1,0,'',NULL,0),(2978,'合阳县','0',439,0,'',1,0,'',NULL,0),(2979,'澄城县','0',439,0,'',1,0,'',NULL,0),(2980,'蒲城县','0',439,0,'',1,0,'',NULL,0),(2981,'白水县','0',439,0,'',1,0,'',NULL,0),(2982,'富平县','0',439,0,'',1,0,'',NULL,0),(2983,'韩城市','0',439,0,'',1,0,'',NULL,0),(2984,'华阴市','0',439,0,'',1,0,'',NULL,0),(2985,'宝塔区','0',440,0,'',1,0,'',NULL,0),(2986,'延长县','0',440,0,'',1,0,'',NULL,0),(2987,'延川县','0',440,0,'',1,0,'',NULL,0),(2988,'子长县','0',440,0,'',1,0,'',NULL,0),(2989,'安塞县','0',440,0,'',1,0,'',NULL,0),(2990,'志丹县','0',440,0,'',1,0,'',NULL,0),(2991,'吴起县','0',440,0,'',1,0,'',NULL,0),(2992,'甘泉县','0',440,0,'',1,0,'',NULL,0),(2993,'富县','0',440,0,'',1,0,'',NULL,0),(2994,'洛川县','0',440,0,'',1,0,'',NULL,0),(2995,'宜川县','0',440,0,'',1,0,'',NULL,0),(2996,'黄龙县','0',440,0,'',1,0,'',NULL,0),(2997,'黄陵县','0',440,0,'',1,0,'',NULL,0),(2998,'汉台区','0',441,0,'',1,0,'',NULL,0),(2999,'南郑县','0',441,0,'',1,0,'',NULL,0),(3000,'城固县','0',441,0,'',1,0,'',NULL,0),(3001,'洋县','0',441,0,'',1,0,'',NULL,0),(3002,'西乡县','0',441,0,'',1,0,'',NULL,0),(3003,'勉县','0',441,0,'',1,0,'',NULL,0),(3004,'宁强县','0',441,0,'',1,0,'',NULL,0),(3005,'略阳县','0',441,0,'',1,0,'',NULL,0),(3006,'镇巴县','0',441,0,'',1,0,'',NULL,0),(3007,'留坝县','0',441,0,'',1,0,'',NULL,0),(3008,'佛坪县','0',441,0,'',1,0,'',NULL,0),(3009,'榆阳区','0',442,0,'',1,0,'',NULL,0),(3010,'神木县','0',442,0,'',1,0,'',NULL,0),(3011,'府谷县','0',442,0,'',1,0,'',NULL,0),(3012,'横山县','0',442,0,'',1,0,'',NULL,0),(3013,'靖边县','0',442,0,'',1,0,'',NULL,0),(3014,'定边县','0',442,0,'',1,0,'',NULL,0),(3015,'绥德县','0',442,0,'',1,0,'',NULL,0),(3016,'米脂县','0',442,0,'',1,0,'',NULL,0),(3017,'佳县','0',442,0,'',1,0,'',NULL,0),(3018,'吴堡县','0',442,0,'',1,0,'',NULL,0),(3019,'清涧县','0',442,0,'',1,0,'',NULL,0),(3020,'子洲县','0',442,0,'',1,0,'',NULL,0),(3021,'汉滨区','0',443,0,'',1,0,'',NULL,0),(3022,'汉阴县','0',443,0,'',1,0,'',NULL,0),(3023,'石泉县','0',443,0,'',1,0,'',NULL,0),(3024,'宁陕县','0',443,0,'',1,0,'',NULL,0),(3025,'紫阳县','0',443,0,'',1,0,'',NULL,0),(3026,'岚皋县','0',443,0,'',1,0,'',NULL,0),(3027,'平利县','0',443,0,'',1,0,'',NULL,0),(3028,'镇坪县','0',443,0,'',1,0,'',NULL,0),(3029,'旬阳县','0',443,0,'',1,0,'',NULL,0),(3030,'白河县','0',443,0,'',1,0,'',NULL,0),(3031,'商州区','0',444,0,'',1,0,'',NULL,0),(3032,'洛南县','0',444,0,'',1,0,'',NULL,0),(3033,'丹凤县','0',444,0,'',1,0,'',NULL,0),(3034,'商南县','0',444,0,'',1,0,'',NULL,0),(3035,'山阳县','0',444,0,'',1,0,'',NULL,0),(3036,'镇安县','0',444,0,'',1,0,'',NULL,0),(3037,'柞水县','0',444,0,'',1,0,'',NULL,0),(3038,'城关区','0',445,0,'',1,0,'',NULL,0),(3039,'七里河区','0',445,0,'',1,0,'',NULL,0),(3040,'西固区','0',445,0,'',1,0,'',NULL,0),(3041,'安宁区','0',445,0,'',1,0,'',NULL,0),(3042,'红古区','0',445,0,'',1,0,'',NULL,0),(3043,'永登县','0',445,0,'',1,0,'',NULL,0),(3044,'皋兰县','0',445,0,'',1,0,'',NULL,0),(3045,'榆中县','0',445,0,'',1,0,'',NULL,0),(3046,'金川区','0',447,0,'',1,0,'',NULL,0),(3047,'永昌县','0',447,0,'',1,0,'',NULL,0),(3048,'白银区','0',448,0,'',1,0,'',NULL,0),(3049,'平川区','0',448,0,'',1,0,'',NULL,0),(3050,'靖远县','0',448,0,'',1,0,'',NULL,0),(3051,'会宁县','0',448,0,'',1,0,'',NULL,0),(3052,'景泰县','0',448,0,'',1,0,'',NULL,0),(3053,'秦城区','0',449,0,'',1,0,'',NULL,0),(3054,'北道区','0',449,0,'',1,0,'',NULL,0),(3055,'清水县','0',449,0,'',1,0,'',NULL,0),(3056,'秦安县','0',449,0,'',1,0,'',NULL,0),(3057,'甘谷县','0',449,0,'',1,0,'',NULL,0),(3058,'武山县','0',449,0,'',1,0,'',NULL,0),(3059,'张家川回族自治县','0',449,0,'',1,0,'',NULL,0),(3060,'凉州区','0',450,0,'',1,0,'',NULL,0),(3061,'民勤县','0',450,0,'',1,0,'',NULL,0),(3062,'古浪县','0',450,0,'',1,0,'',NULL,0),(3063,'天祝藏族自治县','0',450,0,'',1,0,'',NULL,0),(3064,'甘州区','0',451,0,'',1,0,'',NULL,0),(3065,'肃南裕固族自治县','0',451,0,'',1,0,'',NULL,0),(3066,'民乐县','0',451,0,'',1,0,'',NULL,0),(3067,'临泽县','0',451,0,'',1,0,'',NULL,0),(3068,'高台县','0',451,0,'',1,0,'',NULL,0),(3069,'山丹县','0',451,0,'',1,0,'',NULL,0),(3070,'崆峒区','0',452,0,'',1,0,'',NULL,0),(3071,'泾川县','0',452,0,'',1,0,'',NULL,0),(3072,'灵台县','0',452,0,'',1,0,'',NULL,0),(3073,'崇信县','0',452,0,'',1,0,'',NULL,0),(3074,'华亭县','0',452,0,'',1,0,'',NULL,0),(3075,'庄浪县','0',452,0,'',1,0,'',NULL,0),(3076,'静宁县','0',452,0,'',1,0,'',NULL,0),(3077,'肃州区','0',453,0,'',1,0,'',NULL,0),(3078,'金塔县','0',453,0,'',1,0,'',NULL,0),(3079,'瓜州县','0',453,0,'',1,0,'',NULL,0),(3080,'肃北蒙古族自治县','0',453,0,'',1,0,'',NULL,0),(3081,'阿克塞哈萨克族自治县','0',453,0,'',1,0,'',NULL,0),(3082,'玉门市','0',453,0,'',1,0,'',NULL,0),(3083,'敦煌市','0',453,0,'',1,0,'',NULL,0),(3084,'西峰区','0',454,0,'',1,0,'',NULL,0),(3085,'庆城县','0',454,0,'',1,0,'',NULL,0),(3086,'环县','0',454,0,'',1,0,'',NULL,0),(3087,'华池县','0',454,0,'',1,0,'',NULL,0),(3088,'合水县','0',454,0,'',1,0,'',NULL,0),(3089,'正宁县','0',454,0,'',1,0,'',NULL,0),(3090,'宁县','0',454,0,'',1,0,'',NULL,0),(3091,'镇原县','0',454,0,'',1,0,'',NULL,0),(3092,'安定区','0',455,0,'',1,0,'',NULL,0),(3093,'通渭县','0',455,0,'',1,0,'',NULL,0),(3094,'陇西县','0',455,0,'',1,0,'',NULL,0),(3095,'渭源县','0',455,0,'',1,0,'',NULL,0),(3096,'临洮县','0',455,0,'',1,0,'',NULL,0),(3097,'漳县','0',455,0,'',1,0,'',NULL,0),(3098,'岷县','0',455,0,'',1,0,'',NULL,0),(3099,'武都区','0',456,0,'',1,0,'',NULL,0),(3100,'成县','0',456,0,'',1,0,'',NULL,0),(3101,'文县','0',456,0,'',1,0,'',NULL,0),(3102,'宕昌县','0',456,0,'',1,0,'',NULL,0),(3103,'康县','0',456,0,'',1,0,'',NULL,0),(3104,'西和县','0',456,0,'',1,0,'',NULL,0),(3105,'礼县','0',456,0,'',1,0,'',NULL,0),(3106,'徽县','0',456,0,'',1,0,'',NULL,0),(3107,'两当县','0',456,0,'',1,0,'',NULL,0),(3108,'临夏市','0',457,0,'',1,0,'',NULL,0),(3109,'临夏县','0',457,0,'',1,0,'',NULL,0),(3110,'康乐县','0',457,0,'',1,0,'',NULL,0),(3111,'永靖县','0',457,0,'',1,0,'',NULL,0),(3112,'广河县','0',457,0,'',1,0,'',NULL,0),(3113,'和政县','0',457,0,'',1,0,'',NULL,0),(3114,'东乡族自治县','0',457,0,'',1,0,'',NULL,0),(3115,'积石山保安族东乡族撒拉族自治县','0',457,0,'',1,0,'',NULL,0),(3116,'合作市','0',458,0,'',1,0,'',NULL,0),(3117,'临潭县','0',458,0,'',1,0,'',NULL,0),(3118,'卓尼县','0',458,0,'',1,0,'',NULL,0),(3119,'舟曲县','0',458,0,'',1,0,'',NULL,0),(3120,'迭部县','0',458,0,'',1,0,'',NULL,0),(3121,'玛曲县','0',458,0,'',1,0,'',NULL,0),(3122,'碌曲县','0',458,0,'',1,0,'',NULL,0),(3123,'夏河县','0',458,0,'',1,0,'',NULL,0),(3124,'城东区','0',459,0,'',1,0,'',NULL,0),(3125,'城中区','0',459,0,'',1,0,'',NULL,0),(3126,'城西区','0',459,0,'',1,0,'',NULL,0),(3127,'城北区','0',459,0,'',1,0,'',NULL,0),(3128,'大通回族土族自治县','0',459,0,'',1,0,'',NULL,0),(3129,'湟中县','0',459,0,'',1,0,'',NULL,0),(3130,'湟源县','0',459,0,'',1,0,'',NULL,0),(3131,'平安县','0',460,0,'',1,0,'',NULL,0),(3132,'民和回族土族自治县','0',460,0,'',1,0,'',NULL,0),(3133,'乐都县','0',460,0,'',1,0,'',NULL,0),(3134,'互助土族自治县','0',460,0,'',1,0,'',NULL,0),(3135,'化隆回族自治县','0',460,0,'',1,0,'',NULL,0),(3136,'循化撒拉族自治县','0',460,0,'',1,0,'',NULL,0),(3137,'门源回族自治县','0',461,0,'',1,0,'',NULL,0),(3138,'祁连县','0',461,0,'',1,0,'',NULL,0),(3139,'海晏县','0',461,0,'',1,0,'',NULL,0),(3140,'刚察县','0',461,0,'',1,0,'',NULL,0),(3141,'同仁县','0',462,0,'',1,0,'',NULL,0),(3142,'尖扎县','0',462,0,'',1,0,'',NULL,0),(3143,'泽库县','0',462,0,'',1,0,'',NULL,0),(3144,'河南蒙古族自治县','0',462,0,'',1,0,'',NULL,0),(3145,'共和县','0',463,0,'',1,0,'',NULL,0),(3146,'同德县','0',463,0,'',1,0,'',NULL,0),(3147,'贵德县','0',463,0,'',1,0,'',NULL,0),(3148,'兴海县','0',463,0,'',1,0,'',NULL,0),(3149,'贵南县','0',463,0,'',1,0,'',NULL,0),(3150,'玛沁县','0',464,0,'',1,0,'',NULL,0),(3151,'班玛县','0',464,0,'',1,0,'',NULL,0),(3152,'甘德县','0',464,0,'',1,0,'',NULL,0),(3153,'达日县','0',464,0,'',1,0,'',NULL,0),(3154,'久治县','0',464,0,'',1,0,'',NULL,0),(3155,'玛多县','0',464,0,'',1,0,'',NULL,0),(3156,'玉树县','0',465,0,'',1,0,'',NULL,0),(3157,'杂多县','0',465,0,'',1,0,'',NULL,0),(3158,'称多县','0',465,0,'',1,0,'',NULL,0),(3159,'治多县','0',465,0,'',1,0,'',NULL,0),(3160,'囊谦县','0',465,0,'',1,0,'',NULL,0),(3161,'曲麻莱县','0',465,0,'',1,0,'',NULL,0),(3162,'格尔木市','0',466,0,'',1,0,'',NULL,0),(3163,'德令哈市','0',466,0,'',1,0,'',NULL,0),(3164,'乌兰县','0',466,0,'',1,0,'',NULL,0),(3165,'都兰县','0',466,0,'',1,0,'',NULL,0),(3166,'天峻县','0',466,0,'',1,0,'',NULL,0),(3167,'兴庆区','0',467,0,'',1,0,'',NULL,0),(3168,'西夏区','0',467,0,'',1,0,'',NULL,0),(3169,'金凤区','0',467,0,'',1,0,'',NULL,0),(3170,'永宁县','0',467,0,'',1,0,'',NULL,0),(3171,'贺兰县','0',467,0,'',1,0,'',NULL,0),(3172,'灵武市','0',467,0,'',1,0,'',NULL,0),(3173,'大武口区','0',468,0,'',1,0,'',NULL,0),(3174,'惠农区','0',468,0,'',1,0,'',NULL,0),(3175,'平罗县','0',468,0,'',1,0,'',NULL,0),(3176,'利通区','0',469,0,'',1,0,'',NULL,0),(3177,'盐池县','0',469,0,'',1,0,'',NULL,0),(3178,'同心县','0',469,0,'',1,0,'',NULL,0),(3179,'青铜峡市','0',469,0,'',1,0,'',NULL,0),(3180,'原州区','0',470,0,'',1,0,'',NULL,0),(3181,'西吉县','0',470,0,'',1,0,'',NULL,0),(3182,'隆德县','0',470,0,'',1,0,'',NULL,0),(3183,'泾源县','0',470,0,'',1,0,'',NULL,0),(3184,'彭阳县','0',470,0,'',1,0,'',NULL,0),(3185,'沙坡头区','0',471,0,'',1,0,'',NULL,0),(3186,'中宁县','0',471,0,'',1,0,'',NULL,0),(3187,'海原县','0',471,0,'',1,0,'',NULL,0),(3188,'天山区','0',472,0,'',1,0,'',NULL,0),(3189,'沙依巴克区','0',472,0,'',1,0,'',NULL,0),(3190,'新市区','0',472,0,'',1,0,'',NULL,0),(3191,'水磨沟区','0',472,0,'',1,0,'',NULL,0),(3192,'头屯河区','0',472,0,'',1,0,'',NULL,0),(3193,'达坂城区','0',472,0,'',1,0,'',NULL,0),(3194,'东山区','0',472,0,'',1,0,'',NULL,0),(3195,'乌鲁木齐县','0',472,0,'',1,0,'',NULL,0),(3196,'独山子区','0',473,0,'',1,0,'',NULL,0),(3197,'克拉玛依区','0',473,0,'',1,0,'',NULL,0),(3198,'白碱滩区','0',473,0,'',1,0,'',NULL,0),(3199,'乌尔禾区','0',473,0,'',1,0,'',NULL,0),(3200,'吐鲁番市','0',474,0,'',1,0,'',NULL,0),(3201,'鄯善县','0',474,0,'',1,0,'',NULL,0),(3202,'托克逊县','0',474,0,'',1,0,'',NULL,0),(3203,'哈密市','0',475,0,'',1,0,'',NULL,0),(3204,'巴里坤哈萨克自治县','0',475,0,'',1,0,'',NULL,0),(3205,'伊吾县','0',475,0,'',1,0,'',NULL,0),(3206,'昌吉市','0',476,0,'',1,0,'',NULL,0),(3207,'阜康市','0',476,0,'',1,0,'',NULL,0),(3208,'米泉市','0',476,0,'',1,0,'',NULL,0),(3209,'呼图壁县','0',476,0,'',1,0,'',NULL,0),(3210,'玛纳斯县','0',476,0,'',1,0,'',NULL,0),(3211,'奇台县','0',476,0,'',1,0,'',NULL,0),(3212,'吉木萨尔县','0',476,0,'',1,0,'',NULL,0),(3213,'木垒哈萨克自治县','0',476,0,'',1,0,'',NULL,0),(3214,'博乐市','0',477,0,'',1,0,'',NULL,0),(3215,'精河县','0',477,0,'',1,0,'',NULL,0),(3216,'温泉县','0',477,0,'',1,0,'',NULL,0),(3217,'库尔勒市','0',478,0,'',1,0,'',NULL,0),(3218,'轮台县','0',478,0,'',1,0,'',NULL,0),(3219,'尉犁县','0',478,0,'',1,0,'',NULL,0),(3220,'若羌县','0',478,0,'',1,0,'',NULL,0),(3221,'且末县','0',478,0,'',1,0,'',NULL,0),(3222,'焉耆回族自治县','0',478,0,'',1,0,'',NULL,0),(3223,'和静县','0',478,0,'',1,0,'',NULL,0),(3224,'和硕县','0',478,0,'',1,0,'',NULL,0),(3225,'博湖县','0',478,0,'',1,0,'',NULL,0),(3226,'阿克苏市','0',479,0,'',1,0,'',NULL,0),(3227,'温宿县','0',479,0,'',1,0,'',NULL,0),(3228,'库车县','0',479,0,'',1,0,'',NULL,0),(3229,'沙雅县','0',479,0,'',1,0,'',NULL,0),(3230,'新和县','0',479,0,'',1,0,'',NULL,0),(3231,'拜城县','0',479,0,'',1,0,'',NULL,0),(3232,'乌什县','0',479,0,'',1,0,'',NULL,0),(3233,'阿瓦提县','0',479,0,'',1,0,'',NULL,0),(3234,'柯坪县','0',479,0,'',1,0,'',NULL,0),(3235,'阿图什市','0',480,0,'',1,0,'',NULL,0),(3236,'阿克陶县','0',480,0,'',1,0,'',NULL,0),(3237,'阿合奇县','0',480,0,'',1,0,'',NULL,0),(3238,'乌恰县','0',480,0,'',1,0,'',NULL,0),(3239,'喀什市','0',481,0,'',1,0,'',NULL,0),(3240,'疏附县','0',481,0,'',1,0,'',NULL,0),(3241,'疏勒县','0',481,0,'',1,0,'',NULL,0),(3242,'英吉沙县','0',481,0,'',1,0,'',NULL,0),(3243,'泽普县','0',481,0,'',1,0,'',NULL,0),(3244,'莎车县','0',481,0,'',1,0,'',NULL,0),(3245,'叶城县','0',481,0,'',1,0,'',NULL,0),(3246,'麦盖提县','0',481,0,'',1,0,'',NULL,0),(3247,'岳普湖县','0',481,0,'',1,0,'',NULL,0),(3248,'伽师县','0',481,0,'',1,0,'',NULL,0),(3249,'巴楚县','0',481,0,'',1,0,'',NULL,0),(3250,'塔什库尔干塔吉克自治县','0',481,0,'',1,0,'',NULL,0),(3251,'和田市','0',482,0,'',1,0,'',NULL,0),(3252,'和田县','0',482,0,'',1,0,'',NULL,0),(3253,'墨玉县','0',482,0,'',1,0,'',NULL,0),(3254,'皮山县','0',482,0,'',1,0,'',NULL,0),(3255,'洛浦县','0',482,0,'',1,0,'',NULL,0),(3256,'策勒县','0',482,0,'',1,0,'',NULL,0),(3257,'于田县','0',482,0,'',1,0,'',NULL,0),(3258,'民丰县','0',482,0,'',1,0,'',NULL,0),(3259,'伊宁市','0',483,0,'',1,0,'',NULL,0),(3260,'奎屯市','0',483,0,'',1,0,'',NULL,0),(3261,'伊宁县','0',483,0,'',1,0,'',NULL,0),(3262,'察布查尔锡伯自治县','0',483,0,'',1,0,'',NULL,0),(3263,'霍城县','0',483,0,'',1,0,'',NULL,0),(3264,'巩留县','0',483,0,'',1,0,'',NULL,0),(3265,'新源县','0',483,0,'',1,0,'',NULL,0),(3266,'昭苏县','0',483,0,'',1,0,'',NULL,0),(3267,'特克斯县','0',483,0,'',1,0,'',NULL,0),(3268,'尼勒克县','0',483,0,'',1,0,'',NULL,0),(3269,'塔城市','0',484,0,'',1,0,'',NULL,0),(3270,'乌苏市','0',484,0,'',1,0,'',NULL,0),(3271,'额敏县','0',484,0,'',1,0,'',NULL,0),(3272,'沙湾县','0',484,0,'',1,0,'',NULL,0),(3273,'托里县','0',484,0,'',1,0,'',NULL,0),(3274,'裕民县','0',484,0,'',1,0,'',NULL,0),(3275,'和布克赛尔蒙古自治县','0',484,0,'',1,0,'',NULL,0),(3276,'阿勒泰市','0',485,0,'',1,0,'',NULL,0),(3277,'布尔津县','0',485,0,'',1,0,'',NULL,0),(3278,'富蕴县','0',485,0,'',1,0,'',NULL,0),(3279,'福海县','0',485,0,'',1,0,'',NULL,0),(3280,'哈巴河县','0',485,0,'',1,0,'',NULL,0),(3281,'青河县','0',485,0,'',1,0,'',NULL,0),(3282,'吉木乃县','0',485,0,'',1,0,'',NULL,0),(3358,'钓鱼岛','',0,0,'',1,0,'',NULL,0),(3359,'钓鱼岛','',3358,0,'',1,0,'',NULL,0);
/*!40000 ALTER TABLE `v9_linkage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_log`
--

DROP TABLE IF EXISTS `v9_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_log` (
  `logid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field` varchar(15) NOT NULL,
  `value` int(10) unsigned NOT NULL DEFAULT '0',
  `module` varchar(15) NOT NULL,
  `file` varchar(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `querystring` varchar(255) NOT NULL,
  `data` mediumtext NOT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(20) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`logid`),
  KEY `module` (`module`,`file`,`action`),
  KEY `username` (`username`,`action`)
) ENGINE=MyISAM AUTO_INCREMENT=433 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_log`
--

LOCK TABLES `v9_log` WRITE;
/*!40000 ALTER TABLE `v9_log` DISABLE KEYS */;
INSERT INTO `v9_log` VALUES (1,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2017-04-19 16:39:50'),(2,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2017-04-19 16:39:57'),(3,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:18:14'),(4,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:18:25'),(5,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:18:35'),(6,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:18:45'),(7,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:18:54'),(8,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:19:00'),(9,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:19:09'),(10,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:21:20'),(11,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:21:27'),(12,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:21:35'),(13,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:21:51'),(14,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:22:02'),(15,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:22:14'),(16,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:22:28'),(17,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:23:48'),(18,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:24:14'),(19,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:24:23'),(20,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:24:29'),(21,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:24:35'),(22,'',0,'admin','','menu','?m=admin&c=menu&a=delete','',1,'admin','127.0.0.1','2017-04-19 17:28:48'),(23,'',0,'pay','','payment','?m=pay&c=payment&a=pay_list','',1,'admin','127.0.0.1','2017-04-19 17:28:57'),(24,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:29:13'),(25,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:29:15'),(26,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:29:25'),(27,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:29:28'),(28,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:29:30'),(29,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:29:55'),(30,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:29:57'),(31,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:30:05'),(32,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:30:06'),(33,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:30:17'),(34,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:30:20'),(35,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:33:03'),(36,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:33:05'),(37,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:33:24'),(38,'',0,'admin','','menu','?m=admin&c=menu&a=edit','',1,'admin','127.0.0.1','2017-04-19 17:33:27'),(39,'',0,'content','','create_html','?m=content&c=create_html&a=category','',1,'admin','127.0.0.1','2017-04-19 18:17:21'),(40,'',0,'content','','create_html','?m=content&c=create_html&a=category','',1,'admin','127.0.0.1','2017-04-19 18:17:31'),(41,'',0,'admin','','admin_manage','?m=admin&c=admin_manage&a=add','',1,'admin','127.0.0.1','2017-04-19 18:25:15'),(42,'',0,'admin','','admin_manage','?m=admin&c=admin_manage&a=add','',1,'admin','127.0.0.1','2017-04-19 18:25:47'),(43,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2017-04-19 18:25:54'),(44,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2017-04-19 18:26:03'),(45,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2017-04-19 18:28:29'),(46,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2017-04-19 18:28:39'),(47,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2017-04-19 18:28:51'),(48,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2017-04-19 18:29:08'),(49,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2018-12-19 18:08:28'),(50,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2018-12-19 18:08:35'),(51,'',0,'admin','','site','?m=admin&c=site&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:14:28'),(52,'',0,'admin','','site','?m=admin&c=site&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:14:57'),(53,'',0,'admin','','site','?m=admin&c=site&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:15:26'),(54,'',0,'admin','','site','?m=admin&c=site&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:16:19'),(55,'',0,'admin','','site','?m=admin&c=site&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:16:24'),(56,'',0,'poster','','space','?m=poster&c=space&a=delete','',1,'admin','127.0.0.1','2018-12-19 18:18:01'),(57,'',0,'poster','','space','?m=poster&c=space&a=add','',1,'admin','127.0.0.1','2018-12-19 18:18:05'),(58,'',0,'poster','','space','?m=poster&c=space&a=add','',1,'admin','127.0.0.1','2018-12-19 18:18:24'),(59,'',0,'poster','','poster','?m=poster&c=poster&a=add','',1,'admin','127.0.0.1','2018-12-19 18:18:31'),(60,'',0,'poster','','poster','?m=poster&c=poster&a=add','',1,'admin','127.0.0.1','2018-12-19 18:18:55'),(61,'',0,'poster','','poster','?m=poster&c=poster&a=add','',1,'admin','127.0.0.1','2018-12-19 18:19:26'),(62,'',0,'poster','','poster','?m=poster&c=poster&a=add','',1,'admin','127.0.0.1','2018-12-19 18:19:29'),(63,'',0,'poster','','poster','?m=poster&c=poster&a=add','',1,'admin','127.0.0.1','2018-12-19 18:19:39'),(64,'',0,'poster','','poster','?m=poster&c=poster&a=add','',1,'admin','127.0.0.1','2018-12-19 18:19:42'),(65,'',0,'poster','','poster','?m=poster&c=poster&a=add','',1,'admin','127.0.0.1','2018-12-19 18:19:50'),(66,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-19 18:20:35'),(67,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-19 18:20:38'),(68,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-19 18:20:41'),(69,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-19 18:20:44'),(70,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:20:47'),(71,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-19 18:21:05'),(72,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-19 18:21:07'),(73,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-19 18:21:10'),(74,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-19 18:21:13'),(75,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-19 18:21:16'),(76,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-19 18:21:23'),(77,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-19 18:21:29'),(78,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:21:45'),(79,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:25:38'),(80,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=add','',1,'admin','127.0.0.1','2018-12-19 18:26:03'),(81,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=add','',1,'admin','127.0.0.1','2018-12-19 18:26:23'),(82,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=listorder','',1,'admin','127.0.0.1','2018-12-19 18:26:30'),(83,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:49:32'),(84,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:49:55'),(85,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:50:13'),(86,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:50:16'),(87,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:50:29'),(88,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:50:43'),(89,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:50:48'),(90,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:51:11'),(91,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:51:58'),(92,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:52:57'),(93,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:53:02'),(94,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:53:27'),(95,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:53:41'),(96,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:54:00'),(97,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:54:04'),(98,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:54:50'),(99,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:55:06'),(100,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:55:31'),(101,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:55:43'),(102,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:55:45'),(103,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:56:11'),(104,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:56:22'),(105,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:56:24'),(106,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-19 18:56:40'),(107,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:57:00'),(108,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:57:21'),(109,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:57:30'),(110,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:57:38'),(111,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:57:45'),(112,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 18:57:57'),(113,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 18:59:42'),(114,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 18:59:57'),(115,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 18:59:58'),(116,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:00:31'),(117,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:00:32'),(118,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:00:32'),(119,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:01:08'),(120,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:01:17'),(121,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:01:22'),(122,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:01:32'),(123,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:04:10'),(124,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:04:40'),(125,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:17'),(126,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:17'),(127,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:18'),(128,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:18'),(129,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:18'),(130,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:19'),(131,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:19'),(132,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:19'),(133,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:19'),(134,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:20'),(135,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:20'),(136,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:20'),(137,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:20'),(138,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:20'),(139,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:20'),(140,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:20'),(141,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:21'),(142,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:21'),(143,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:21'),(144,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:05:21'),(145,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:09:32'),(146,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:24'),(147,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:25'),(148,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:25'),(149,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:25'),(150,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:26'),(151,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:26'),(152,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:26'),(153,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:26'),(154,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:26'),(155,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:26'),(156,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:27'),(157,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:27'),(158,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:27'),(159,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:27'),(160,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:27'),(161,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:27'),(162,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:10:28'),(163,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:12:21'),(164,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:12:31'),(165,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:12:36'),(166,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:12:44'),(167,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:12:49'),(168,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:12:57'),(169,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:16:03'),(170,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:16:40'),(171,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:16:41'),(172,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:16:41'),(173,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:16:42'),(174,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:21:10'),(175,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:29:09'),(176,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:29:10'),(177,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:29:14'),(178,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:29:46'),(179,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:29:47'),(180,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:29:49'),(181,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:29:50'),(182,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:50:19'),(183,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-19 19:50:23'),(184,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:51:12'),(185,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:51:40'),(186,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:51:42'),(187,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:51:46'),(188,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:01'),(189,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:11'),(190,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:12'),(191,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:12'),(192,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:12'),(193,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:13'),(194,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:13'),(195,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:13'),(196,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:13'),(197,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:13'),(198,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:13'),(199,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:14'),(200,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:14'),(201,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:14'),(202,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:55:15'),(203,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:29'),(204,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:54'),(205,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:54'),(206,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:54'),(207,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:54'),(208,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:54'),(209,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:55'),(210,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:55'),(211,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:55'),(212,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:55'),(213,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:55'),(214,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:56'),(215,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:56'),(216,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:56'),(217,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:56'),(218,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-19 19:56:56'),(219,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2018-12-19 22:54:36'),(220,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2018-12-19 22:54:40'),(221,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2018-12-19 22:54:41'),(222,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2018-12-19 22:54:42'),(223,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2018-12-19 22:54:46'),(224,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2018-12-19 22:54:47'),(225,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'','127.0.0.1','2018-12-19 22:54:54'),(226,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'admin','127.0.0.1','2018-12-20 13:09:23'),(227,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'admin','127.0.0.1','2018-12-20 13:09:24'),(228,'',0,'admin','','index','?m=admin&c=index&a=login','',0,'admin','127.0.0.1','2018-12-20 13:09:30'),(229,'',0,'admin','','site','?m=admin&c=site&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:09:40'),(230,'',0,'admin','','site','?m=admin&c=site&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:10:20'),(231,'',0,'admin','','site','?m=admin&c=site&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:10:25'),(232,'',0,'admin','','site','?m=admin&c=site&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:10:30'),(233,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-20 13:11:12'),(234,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-20 13:11:17'),(235,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-20 13:11:22'),(236,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-20 13:11:25'),(237,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-20 13:11:29'),(238,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-20 13:11:33'),(239,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-20 13:11:37'),(240,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-20 13:11:40'),(241,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-20 13:11:44'),(242,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:11:47'),(243,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:12:18'),(244,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:12:34'),(245,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:12:36'),(246,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:14:07'),(247,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:14:13'),(248,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:14:43'),(249,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:14:46'),(250,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:14:59'),(251,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:15:03'),(252,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:15:08'),(253,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:15:12'),(254,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:16:00'),(255,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:16:17'),(256,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:16:19'),(257,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:16:33'),(258,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:16:42'),(259,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:17:43'),(260,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:17:48'),(261,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:18:43'),(262,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:18:58'),(263,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:19:01'),(264,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:19:09'),(265,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:19:13'),(266,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:19:54'),(267,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:19:58'),(268,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:20:02'),(269,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:20:05'),(270,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:20:29'),(271,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:20:37'),(272,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:20:38'),(273,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:20:39'),(274,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:21:00'),(275,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:21:02'),(276,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:21:03'),(277,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:21:02'),(278,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:21:27'),(279,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:21:28'),(280,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:21:33'),(281,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:21:56'),(282,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:22:07'),(283,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:22:09'),(284,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:22:52'),(285,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:23:00'),(286,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:23:02'),(287,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:23:59'),(288,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:24:14'),(289,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:24:25'),(290,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:24:34'),(291,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:24:43'),(292,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:24:51'),(293,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:54:56'),(294,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:54:57'),(295,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:54:58'),(296,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-20 13:55:32'),(297,'',0,'admin','','category','?m=admin&c=category&a=delete','',1,'admin','127.0.0.1','2018-12-20 13:56:31'),(298,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:56:33'),(299,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:56:49'),(300,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:57:12'),(301,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:57:27'),(302,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:57:35'),(303,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 13:57:37'),(304,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:57:58'),(305,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:58:40'),(306,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 13:59:10'),(307,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:59:16'),(308,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:59:21'),(309,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:59:24'),(310,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:59:30'),(311,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 13:59:56'),(312,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 14:00:01'),(313,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:07'),(314,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:50'),(315,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:50'),(316,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:50'),(317,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:50'),(318,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:51'),(319,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:51'),(320,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:51'),(321,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:51'),(322,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:52'),(323,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:52'),(324,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:52'),(325,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:52'),(326,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:52'),(327,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:52'),(328,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:52'),(329,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:53'),(330,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:53'),(331,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:00:53'),(332,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 14:01:25'),(333,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 14:01:29'),(334,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 14:01:33'),(335,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 14:01:36'),(336,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:01:47'),(337,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:22'),(338,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:33'),(339,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:33'),(340,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:33'),(341,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:33'),(342,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:34'),(343,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:34'),(344,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:34'),(345,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:34'),(346,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:34'),(347,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:34'),(348,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:34'),(349,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:04:35'),(350,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:05:33'),(351,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:05:41'),(352,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 14:05:42'),(353,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:14:39'),(354,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:14:45'),(355,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:14:50'),(356,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:22:05'),(357,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:22:09'),(358,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:22:16'),(359,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:22:45'),(360,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:23:18'),(361,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:23:24'),(362,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:23:28'),(363,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:24:47'),(364,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:24:52'),(365,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:24:58'),(366,'',0,'admin','','category','?m=admin&c=category&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:25:04'),(367,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:27:49'),(368,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:27:53'),(369,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:31'),(370,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:31'),(371,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:31'),(372,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:31'),(373,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:31'),(374,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:32'),(375,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:32'),(376,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:32'),(377,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:32'),(378,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:32'),(379,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:32'),(380,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:33'),(381,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:33'),(382,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:28:32'),(383,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:13'),(384,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:24'),(385,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:24'),(386,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:25'),(387,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:25'),(388,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:25'),(389,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:25'),(390,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:25'),(391,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:25'),(392,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:25'),(393,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:26'),(394,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:26'),(395,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:26'),(396,'',0,'content','','sitemodel','?m=content&c=sitemodel&a=add','',1,'admin','127.0.0.1','2018-12-20 16:44:52'),(397,'',0,'content','','sitemodel','?m=content&c=sitemodel&a=add','',1,'admin','127.0.0.1','2018-12-20 16:45:09'),(398,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-20 16:45:20'),(399,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-20 16:45:23'),(400,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-20 16:45:28'),(401,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-20 16:45:32'),(402,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-20 16:45:35'),(403,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-20 16:45:37'),(404,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-20 16:45:40'),(405,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-20 16:45:43'),(406,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-20 16:45:46'),(407,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-20 16:45:53'),(408,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=disabled','',1,'admin','127.0.0.1','2018-12-20 16:45:56'),(409,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=add','',1,'admin','127.0.0.1','2018-12-20 16:45:58'),(410,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=add','',1,'admin','127.0.0.1','2018-12-20 16:47:17'),(411,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=add','',1,'admin','127.0.0.1','2018-12-20 16:47:37'),(412,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=add','',1,'admin','127.0.0.1','2018-12-20 16:47:58'),(413,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=edit','',1,'admin','127.0.0.1','2018-12-20 16:48:14'),(414,'',0,'content','','sitemodel_field','?m=content&c=sitemodel_field&a=listorder','',1,'admin','127.0.0.1','2018-12-20 16:48:28'),(415,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 16:53:24'),(416,'',0,'admin','','category','?m=admin&c=category&a=add','',1,'admin','127.0.0.1','2018-12-20 16:53:48'),(417,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:53:54'),(418,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 16:54:19'),(419,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 17:03:45'),(420,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 17:04:01'),(421,'',0,'content','','content','?m=content&c=content&a=add','',1,'admin','127.0.0.1','2018-12-20 17:04:03'),(422,'',0,'link','','link','?m=link&c=link&a=edit','',1,'admin','127.0.0.1','2018-12-20 17:07:57'),(423,'',0,'link','','link','?m=link&c=link&a=delete','',1,'admin','127.0.0.1','2018-12-20 17:08:01'),(424,'',0,'link','','link','?m=link&c=link&a=delete','',1,'admin','127.0.0.1','2018-12-20 17:08:07'),(425,'',0,'link','','link','?m=link&c=link&a=add','',1,'admin','127.0.0.1','2018-12-20 17:08:10'),(426,'',0,'link','','link','?m=link&c=link&a=add','',1,'admin','127.0.0.1','2018-12-20 17:08:59'),(427,'',0,'link','','link','?m=link&c=link&a=add','',1,'admin','127.0.0.1','2018-12-20 17:09:00'),(428,'',0,'link','','link','?m=link&c=link&a=add','',1,'admin','127.0.0.1','2018-12-20 17:09:14'),(429,'',0,'link','','link','?m=link&c=link&a=add','',1,'admin','127.0.0.1','2018-12-20 17:09:23'),(430,'',0,'link','','link','?m=link&c=link&a=add','',1,'admin','127.0.0.1','2018-12-20 17:09:27'),(431,'',0,'link','','link','?m=link&c=link&a=add','',1,'admin','127.0.0.1','2018-12-20 17:10:23'),(432,'',0,'link','','link','?m=link&c=link&a=add','',1,'admin','127.0.0.1','2018-12-20 17:10:27');
/*!40000 ALTER TABLE `v9_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_member`
--

DROP TABLE IF EXISTS `v9_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_member` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `phpssouid` mediumint(8) unsigned NOT NULL,
  `username` char(20) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `encrypt` char(6) NOT NULL,
  `nickname` char(20) NOT NULL,
  `regdate` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `regip` char(15) NOT NULL DEFAULT '',
  `lastip` char(15) NOT NULL DEFAULT '',
  `loginnum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `email` char(32) NOT NULL DEFAULT '',
  `groupid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `areaid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `amount` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `point` smallint(5) unsigned NOT NULL DEFAULT '0',
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `message` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `islock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vip` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `overduedate` int(10) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1',
  `connectid` char(40) NOT NULL DEFAULT '',
  `from` char(10) NOT NULL DEFAULT '',
  `mobile` char(11) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  KEY `email` (`email`(20)),
  KEY `phpssouid` (`phpssouid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_member`
--

LOCK TABLES `v9_member` WRITE;
/*!40000 ALTER TABLE `v9_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_member_detail`
--

DROP TABLE IF EXISTS `v9_member_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_member_detail` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `birthday` date DEFAULT NULL,
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_member_detail`
--

LOCK TABLES `v9_member_detail` WRITE;
/*!40000 ALTER TABLE `v9_member_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_member_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_member_group`
--

DROP TABLE IF EXISTS `v9_member_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_member_group` (
  `groupid` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(15) NOT NULL,
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `starnum` tinyint(2) unsigned NOT NULL,
  `point` smallint(6) unsigned NOT NULL,
  `allowmessage` smallint(5) unsigned NOT NULL DEFAULT '0',
  `allowvisit` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowpost` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowpostverify` tinyint(1) unsigned NOT NULL,
  `allowsearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowupgrade` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `allowsendmessage` tinyint(1) unsigned NOT NULL,
  `allowpostnum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `allowattachment` tinyint(1) NOT NULL,
  `price_y` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `price_m` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `price_d` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `icon` char(30) NOT NULL,
  `usernamecolor` char(7) NOT NULL,
  `description` char(100) NOT NULL,
  `sort` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`groupid`),
  KEY `disabled` (`disabled`),
  KEY `listorder` (`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_member_group`
--

LOCK TABLES `v9_member_group` WRITE;
/*!40000 ALTER TABLE `v9_member_group` DISABLE KEYS */;
INSERT INTO `v9_member_group` VALUES (8,'游客',1,0,0,0,0,0,0,1,0,0,0,0,0.00,0.00,0.00,'','','',0,0),(2,'新手上路',1,1,50,100,1,1,0,0,0,1,0,0,50.00,10.00,1.00,'','','',2,0),(6,'注册会员',1,2,100,150,0,1,0,0,1,1,0,0,300.00,30.00,1.00,'','','',6,0),(4,'中级会员',1,3,150,500,1,1,0,1,1,1,0,0,500.00,60.00,1.00,'','','',4,0),(5,'高级会员',1,5,300,999,1,1,0,1,1,1,0,0,360.00,90.00,5.00,'','','',5,0),(1,'禁止访问',1,0,0,0,1,1,0,1,0,0,0,0,0.00,0.00,0.00,'','','0',0,0),(7,'邮件认证',1,0,0,0,0,0,0,0,0,0,0,0,0.00,0.00,0.00,'images/group/vip.jpg','#000000','',7,0);
/*!40000 ALTER TABLE `v9_member_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_member_menu`
--

DROP TABLE IF EXISTS `v9_member_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_member_menu` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(40) NOT NULL DEFAULT '',
  `parentid` smallint(6) NOT NULL DEFAULT '0',
  `m` char(20) NOT NULL DEFAULT '',
  `c` char(20) NOT NULL DEFAULT '',
  `a` char(20) NOT NULL DEFAULT '',
  `data` char(100) NOT NULL DEFAULT '',
  `listorder` smallint(6) unsigned NOT NULL DEFAULT '0',
  `display` enum('1','0') NOT NULL DEFAULT '1',
  `isurl` enum('1','0') NOT NULL DEFAULT '0',
  `url` char(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `listorder` (`listorder`),
  KEY `parentid` (`parentid`),
  KEY `module` (`m`,`c`,`a`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_member_menu`
--

LOCK TABLES `v9_member_menu` WRITE;
/*!40000 ALTER TABLE `v9_member_menu` DISABLE KEYS */;
INSERT INTO `v9_member_menu` VALUES (1,'member_init',0,'member','index','init','t=0',0,'1','',''),(2,'account_manage',0,'member','index','account_manage','t=1',0,'1','',''),(3,'favorite',0,'member','index','favorite','t=2',0,'1','','');
/*!40000 ALTER TABLE `v9_member_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_member_verify`
--

DROP TABLE IF EXISTS `v9_member_verify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_member_verify` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL,
  `password` char(32) NOT NULL,
  `encrypt` char(6) NOT NULL,
  `nickname` char(20) NOT NULL,
  `regdate` int(10) unsigned NOT NULL,
  `regip` char(15) NOT NULL,
  `email` char(32) NOT NULL,
  `modelid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `point` smallint(5) unsigned NOT NULL DEFAULT '0',
  `amount` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `modelinfo` char(255) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `siteid` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `message` char(100) DEFAULT NULL,
  `mobile` char(11) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  KEY `email` (`email`(20))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_member_verify`
--

LOCK TABLES `v9_member_verify` WRITE;
/*!40000 ALTER TABLE `v9_member_verify` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_member_verify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_member_vip`
--

DROP TABLE IF EXISTS `v9_member_vip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_member_vip` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_member_vip`
--

LOCK TABLES `v9_member_vip` WRITE;
/*!40000 ALTER TABLE `v9_member_vip` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_member_vip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_menu`
--

DROP TABLE IF EXISTS `v9_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_menu` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(40) NOT NULL DEFAULT '',
  `parentid` smallint(6) NOT NULL DEFAULT '0',
  `m` char(20) NOT NULL DEFAULT '',
  `c` char(20) NOT NULL DEFAULT '',
  `a` char(20) NOT NULL DEFAULT '',
  `data` char(100) NOT NULL DEFAULT '',
  `listorder` smallint(6) unsigned NOT NULL DEFAULT '0',
  `display` enum('1','0') NOT NULL DEFAULT '1',
  `project1` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `project2` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `project3` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `project4` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `project5` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `listorder` (`listorder`),
  KEY `parentid` (`parentid`),
  KEY `module` (`m`,`c`,`a`)
) ENGINE=MyISAM AUTO_INCREMENT=1669 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_menu`
--

LOCK TABLES `v9_menu` WRITE;
/*!40000 ALTER TABLE `v9_menu` DISABLE KEYS */;
INSERT INTO `v9_menu` VALUES (1,'sys_setting',0,'admin','setting','init','',1,'1',0,1,1,1,1),(2,'module',0,'admin','module','init','',2,'1',1,1,1,1,1),(4,'content',0,'content','content','init','',4,'1',1,1,1,1,1),(5,'members',0,'member','member','init','',5,'0',1,1,1,1,1),(30,'correlative_setting',1,'admin','admin','admin','',0,'1',1,1,1,1,1),(31,'menu_manage',977,'admin','menu','init','',8,'1',1,1,1,1,1),(32,'posid_manage',975,'admin','position','init','',7,'1',1,1,1,1,1),(29,'module_list',2,'admin','module','','',0,'1',1,1,1,1,1),(82,'module_manage',2,'admin','module','','',0,'1',1,1,1,1,1),(10,'panel',0,'admin','index','public_main','',0,'1',0,1,1,1,1),(35,'menu_add',31,'admin','menu','add','',0,'1',1,1,1,1,1),(826,'template_manager',6,'','','','',0,'1',1,1,1,1,1),(54,'admin_manage',49,'admin','admin_manage','init','',0,'1',1,1,1,1,1),(43,'category_manage',975,'admin','category','init','module=admin',4,'1',1,1,1,1,1),(42,'add_category',43,'admin','category','add','s=0',1,'1',1,1,1,1,1),(44,'edit_category',43,'admin','category','edit','',0,'0',1,1,1,1,1),(46,'posid_add',32,'admin','position','add','',0,'0',1,1,1,1,1),(49,'admin_setting',1,'admin','','','',0,'1',1,1,1,1,1),(50,'role_manage',49,'admin','role','init','',0,'1',1,1,1,1,1),(51,'role_add',50,'admin','role','add','',0,'1',1,1,1,1,1),(52,'category_cache',43,'admin','category','public_cache','module=admin',4,'1',1,1,1,1,1),(55,'manage_member',5,'member','member','manage','',0,'1',1,1,1,1,1),(58,'admin_add',54,'admin','admin_manage','add','',0,'1',1,1,1,1,1),(59,'model_manage',975,'content','sitemodel','init','',5,'1',1,1,1,1,1),(64,'site_management',30,'admin','site','init','',2,'1',1,1,1,1,1),(81,'member_add',72,'member','member','add','',2,'0',1,1,1,1,1),(62,'add_model',59,'content','sitemodel','add','',0,'0',1,1,1,1,1),(65,'release_point_management',30,'admin','release_point','init','',3,'1',1,1,1,1,1),(66,'badword_export',45,'admin','badword','export','',0,'1',1,1,1,1,1),(67,'add_site',64,'admin','site','add','',0,'0',1,1,1,1,1),(68,'badword_import',45,'admin','badword','import','',0,'1',1,1,1,1,1),(812,'member_group_manage',76,'member','member_group','manage','',0,'1',1,1,1,1,1),(74,'member_verify',55,'member','member_verify','manage','s=0',3,'1',1,1,1,1,1),(76,'manage_member_group',5,'member','member_group','manage','',0,'1',1,1,1,1,1),(77,'manage_member_model',5,'member','member_model','manage','',0,'1',1,1,1,1,1),(78,'member_group_add',812,'member','member_group','add','',0,'0',1,1,1,1,1),(79,'member_model_add',813,'member','member_model','add','',1,'0',1,1,1,1,1),(80,'member_model_import',77,'member','member_model','import','',2,'0',1,1,1,1,1),(72,'member_manage',55,'member','member','manage','',1,'1',1,1,1,1,1),(813,'member_model_manage',77,'member','member_model','manage','',0,'1',1,1,1,1,1),(814,'site_edit',64,'admin','site','edit','',0,'0',1,1,1,1,1),(815,'site_del',64,'admin','site','del','',0,'0',1,1,1,1,1),(816,'release_point_add',65,'admin','release_point','add','',0,'0',1,1,1,1,1),(817,'release_point_del',65,'admin','release_point','del','',0,'0',1,1,1,1,1),(818,'release_point_edit',65,'admin','release_point','edit','',0,'0',1,1,1,1,1),(821,'content_publish',4,'content','content','init','',0,'1',1,1,1,1,1),(822,'content_manage',821,'content','content','init','',0,'1',1,1,1,1,1),(867,'linkage',977,'admin','linkage','init','',13,'1',1,1,1,1,1),(827,'template_style',826,'template','style','init','',0,'1',1,1,1,1,1),(828,'import_style',827,'template','style','import','',0,'0',1,1,1,1,1),(831,'template_export',827,'template','style','export','',0,'0',1,1,1,1,1),(830,'template_file',827,'template','file','init','',0,'0',1,1,1,1,1),(832,'template_onoff',827,'template','style','disable','',0,'0',1,1,1,1,1),(833,'template_updatename',827,'template','style','updatename','',0,'0',1,1,1,1,1),(834,'member_lock',72,'member','member','lock','',0,'0',1,1,1,1,1),(835,'member_unlock',72,'member','member','unlock','',0,'0',1,1,1,1,1),(836,'member_move',72,'member','member','move','',0,'0',1,1,1,1,1),(837,'member_delete',72,'member','member','delete','',0,'0',1,1,1,1,1),(842,'verify_ignore',74,'member','member_verify','manage','s=2',0,'1',1,1,1,1,1),(839,'member_setting',55,'member','member_setting','manage','',4,'1',1,1,1,1,1),(841,'verify_pass',74,'member','member_verify','manage','s=1',0,'1',1,1,1,1,1),(843,'verify_delete',74,'member','member_verify','manage','s=3',0,'0',1,1,1,1,1),(844,'verify_deny',74,'member','member_verify','manage','s=4',0,'1',1,1,1,1,1),(845,'never_pass',74,'member','member_verify','manage','s=5',0,'1',1,1,1,1,1),(846,'template_file_list',827,'template','file','init','',0,'0',1,1,1,1,1),(847,'template_file_edit',827,'template','file','edit_file','',0,'0',1,1,1,1,1),(848,'file_add_file',827,'template','file','add_file','',0,'0',1,1,1,1,1),(850,'listorder',76,'member','member_group','sort','',0,'0',1,1,1,1,1),(852,'priv_setting',50,'admin','role','priv_setting','',0,'0',1,1,1,1,1),(853,'role_priv',50,'admin','role','role_priv','',0,'0',1,1,1,1,1),(857,'attachment_manage',821,'attachment','manage','init','',0,'1',1,1,1,1,1),(869,'template_editor',827,'template','file','edit_file','',0,'0',1,1,1,1,1),(870,'template_visualization',827,'template','file','visualization','',0,'0',1,1,1,1,1),(871,'pc_tag_edit',827,'template','file','edit_pc_tag','',0,'0',1,1,1,1,1),(873,'release_manage',4,'release','html','init','',0,'1',1,1,1,1,1),(874,'type_manage',975,'content','type_manage','init','',6,'1',1,1,1,1,1),(875,'add_type',874,'content','type_manage','add','',0,'0',1,1,1,1,1),(876,'linkageadd',867,'admin','linkage','add','',0,'0',1,1,1,1,1),(877,'failure_list',872,'release','index','failed','',0,'1',1,1,1,1,1),(879,'member_search',72,'member','member','search','',0,'0',1,1,1,1,1),(880,'queue_del',872,'release','index','del','',0,'0',1,1,1,1,1),(881,'member_model_delete',813,'member','member_model','delete','',0,'0',1,1,1,1,1),(882,'member_model_edit',813,'member','member_model','edit','',0,'0',1,1,1,1,1),(885,'workflow',977,'content','workflow','init','',15,'1',1,1,1,1,1),(888,'add_workflow',885,'content','workflow','add','',0,'1',1,1,1,1,1),(889,'member_modelfield_add',813,'member','member_modelfield','add','',0,'0',1,1,1,1,1),(890,'member_modelfield_edit',813,'member','member_modelfield','edit','',0,'0',1,1,1,1,1),(891,'member_modelfield_delete',813,'member','member_modelfield','delete','',0,'0',1,1,1,1,1),(892,'member_modelfield_manage',813,'member','member_modelfield','manage','',0,'0',1,1,1,1,1),(895,'sitemodel_import',59,'content','sitemodel','import','',0,'1',1,1,1,1,1),(896,'pay',29,'pay','payment','pay_list','s=3',0,'0',1,1,1,1,1),(897,'payments',896,'pay','payment','init','',0,'1',1,1,1,1,1),(898,'paylist',896,'pay','payment','pay_list','',0,'1',1,1,1,1,1),(899,'add_content',822,'content','content','add','',0,'0',1,1,1,1,1),(900,'modify_deposit',896,'pay','payment','modify_deposit','s=1',0,'1',1,1,1,1,1),(901,'check_content',822,'content','content','pass','',0,'0',1,1,1,1,1),(905,'create_content_html',873,'content','create_html','show','',2,'1',1,1,1,1,1),(904,'external_data_sources',902,'dbsource','dbsource_admin','init','',0,'1',1,1,1,1,1),(906,'update_urls',873,'content','create_html','update_urls','',1,'1',1,1,1,1,1),(960,'node_add',957,'collection','node','add','',0,'1',1,1,1,1,1),(909,'fulltext_search',29,'search','search_type','init','',0,'0',1,1,1,1,1),(910,'manage_type',909,'search','search_type','init','',0,'0',1,1,1,1,1),(911,'search_setting',909,'search','search_admin','setting','',0,'1',1,1,1,1,1),(912,'createindex',909,'search','search_admin','createindex','',0,'1',1,1,1,1,1),(913,'add_search_type',909,'search','search_type','add','',0,'0',1,1,1,1,1),(914,'database_toos',977,'admin','database','export','',6,'1',1,1,1,1,1),(915,'database_export',914,'admin','database','export','',0,'1',1,1,1,1,1),(916,'database_import',914,'admin','database','import','',0,'1',1,1,1,1,1),(917,'dbsource_add',902,'dbsource','dbsource_admin','add','',0,'0',1,1,1,1,1),(918,'dbsource_edit',902,'dbsource','dbsource_admin','edit','',0,'0',1,1,1,1,1),(919,'dbsource_del',902,'dbsource','dbsource_admin','del','',0,'0',1,1,1,1,1),(920,'dbsource_data_add',902,'dbsource','data','add','',0,'0',1,1,1,1,1),(921,'dbsource_data_edit',902,'dbsource','data','edit','',0,'0',1,1,1,1,1),(922,'dbsource_data_del',902,'dbsource','data','del','',0,'0',1,1,1,1,1),(926,'add_special',868,'special','special','add','',0,'1',1,1,1,1,1),(927,'edit_special',868,'special','special','edit','',0,'0',1,1,1,1,1),(928,'special_list',868,'special','special','init','',0,'0',1,1,1,1,1),(929,'special_elite',868,'special','special','elite','',0,'0',1,1,1,1,1),(930,'delete_special',868,'special','special','delete','',0,'0',1,1,1,1,1),(931,'badword_add',45,'admin','badword','add','',0,'0',1,1,1,1,1),(932,'badword_edit',45,'admin','badword','edit','',0,'0',1,1,1,1,1),(933,'badword_delete',45,'admin','badword','delete','',0,'0',1,1,1,1,1),(934,'special_listorder',868,'special','special','listorder','',0,'0',1,1,1,1,1),(935,'special_content_list',868,'special','content','init','',0,'0',1,1,1,1,1),(936,'special_content_add',935,'special','content','add','',0,'0',1,1,1,1,1),(937,'special_content_list',935,'special','content','init','',0,'0',1,1,1,1,1),(938,'special_content_edit',935,'special','content','edit','',0,'0',1,1,1,1,1),(939,'special_content_delete',935,'special','content','delete','',0,'0',1,1,1,1,1),(940,'special_content_listorder',935,'special','content','listorder','',0,'0',1,1,1,1,1),(941,'special_content_import',935,'special','special','import','',0,'0',1,1,1,1,1),(942,'history_version',827,'template','template_bak','init','',0,'0',1,1,1,1,1),(943,'restore_version',827,'template','template_bak','restore','',0,'0',1,1,1,1,1),(944,'del_history_version',827,'template','template_bak','del','',0,'0',1,1,1,1,1),(946,'block_add',945,'block','block_admin','add','',0,'0',1,1,1,1,1),(950,'block_edit',945,'block','block_admin','edit','',0,'0',1,1,1,1,1),(951,'block_del',945,'block','block_admin','del','',0,'0',1,1,1,1,1),(952,'block_update',945,'block','block_admin','block_update','',0,'0',1,1,1,1,1),(953,'block_restore',945,'block','block_admin','history_restore','',0,'0',1,1,1,1,1),(954,'history_del',945,'block','block_admin','history_del','',0,'0',1,1,1,1,1),(978,'urlrule_manage',977,'admin','urlrule','init','',0,'1',1,1,1,1,1),(979,'safe_config',30,'admin','setting','init','&tab=2',11,'1',1,1,1,1,1),(959,'basic_config',30,'admin','setting','init','',10,'1',1,1,1,1,1),(961,'position_edit',32,'admin','position','edit','',0,'0',1,1,1,1,1),(962,'collection_node_edit',957,'collection','node','edit','',0,'0',1,1,1,1,1),(963,'collection_node_delete',957,'collection','node','del','',0,'0',1,1,1,1,1),(990,'col_url_list',957,'collection','node','col_url_list','',0,'0',1,1,1,1,1),(965,'collection_node_publish',957,'collection','node','publist','',0,'0',1,1,1,1,1),(966,'collection_node_import',957,'collection','node','node_import','',0,'0',1,1,1,1,1),(967,'collection_node_export',957,'collection','node','export','',0,'0',1,1,1,1,1),(968,'collection_node_collection_content',957,'collection','node','col_content','',0,'0',1,1,1,1,1),(970,'admininfo',10,'admin','admin_manage','init','',0,'1',1,1,1,1,1),(971,'editpwd',970,'admin','admin_manage','public_edit_pwd','',1,'1',1,1,1,1,1),(972,'editinfo',970,'admin','admin_manage','public_edit_info','',0,'1',1,1,1,1,1),(974,'add_keylink',973,'admin','keylink','add','',0,'0',1,1,1,1,1),(975,'content_settings',4,'content','content_settings','init','',0,'1',1,1,1,1,1),(7,'extend',0,'admin','extend','init_extend','',7,'1',0,1,1,1,1),(977,'extend_all',7,'admin','extend_all','init','',0,'1',1,1,1,1,1),(980,'sso_config',30,'admin','setting','init','&tab=3',12,'1',1,1,1,1,1),(981,'email_config',30,'admin','setting','init','&tab=4',13,'1',1,1,1,1,1),(982,'module_manage',82,'admin','module','init','',0,'1',1,1,1,1,1),(983,'ipbanned',977,'admin','ipbanned','init','',0,'1',1,1,1,1,1),(984,'add_ipbanned',983,'admin','ipbanned','add','',0,'0',1,1,1,1,1),(993,'collection_content_import',957,'collection','node','import','',0,'0',1,1,1,1,1),(991,'copy_node',957,'collection','node','copy','',0,'0',1,1,1,1,1),(992,'content_del',957,'collection','node','content_del','',0,'0',1,1,1,1,1),(994,'import_program_add',957,'collection','node','import_program_add','',0,'0',1,1,1,1,1),(995,'import_program_del',957,'collection','node','import_program_del','',0,'0',1,1,1,1,1),(996,'import_content',957,'collection','node','import_content','',0,'0',1,1,1,1,1),(997,'log',977,'admin','log','init','',0,'1',1,1,1,1,1),(998,'add_page',43,'admin','category','add','s=1',2,'1',1,1,1,1,1),(999,'add_cat_link',43,'admin','category','add','s=2',2,'1',1,1,1,1,1),(1000,'count_items',43,'admin','category','count_items','',5,'1',1,1,1,1,1),(1001,'cache_all',977,'admin','cache_all','init','',0,'1',1,1,1,1,1),(1002,'create_list_html',873,'content','create_html','category','',0,'1',1,1,1,1,1),(1003,'create_html_quick',10,'content','create_html_opt','index','',0,'1',1,1,1,1,1),(1004,'create_index',1003,'content','create_html','public_index','',0,'1',1,1,1,1,1),(1006,'scan_report',1005,'scan','index','scan_report','',0,'1',1,1,1,1,1),(1007,'md5_creat',1005,'scan','index','md5_creat','',0,'1',1,1,1,1,1),(1008,'album_import',868,'special','album','import','',0,'1',1,1,1,1,1),(8,'phpsso',0,'admin','phpsso','menu','',7,'0',0,1,1,1,1),(1011,'edit_content',822,'content','content','edit','',0,'0',1,1,1,1,1),(1012,'push_to_special',822,'content','push','init','',0,'0',1,1,1,1,1),(1023,'delete_log',997,'admin','log','delete','',0,'0',1,1,1,1,1),(1024,'delete_ip',983,'admin','ipbanned','delete','',0,'0',1,1,1,1,1),(1026,'delete_keylink',973,'admin','keylink','delete','',0,'0',1,1,1,1,1),(1027,'edit_keylink',973,'admin','keylink','edit','',0,'0',1,1,1,1,1),(1034,'operation_pass',74,'member','member_verify','pass','',0,'0',1,1,1,1,1),(1035,'operation_delete',74,'member','member_verify','delete','',0,'0',1,1,1,1,1),(1039,'operation_ignore',74,'member','member_verify','ignore','',0,'0',1,1,1,1,1),(1038,'settingsave',30,'admin','setting','save','',0,'0',1,1,1,1,1),(1040,'admin_edit',54,'admin','admin_manage','edit','',0,'0',1,1,1,1,1),(1041,'operation_reject',74,'member','member_verify','reject','',0,'0',1,1,1,1,1),(1042,'admin_delete',54,'admin','admin_manage','delete','',0,'0',1,1,1,1,1),(1043,'card',54,'admin','admin_manage','card','',0,'0',1,1,1,1,1),(1044,'creat_card',54,'admin','admin_manage','creat_card','',0,'0',1,1,1,1,1),(1045,'remove_card',54,'admin','admin_manage','remove_card','',0,'0',1,1,1,1,1),(1049,'member_group_edit',812,'member','member_group','edit','',0,'0',1,1,1,1,1),(1048,'member_edit',72,'member','member','edit','',0,'0',1,1,1,1,1),(1050,'role_edit',50,'admin','role','edit','',0,'0',1,1,1,1,1),(1051,'member_group_delete',812,'member','member_group','delete','',0,'0',1,1,1,1,1),(1052,'member_manage',50,'admin','role','member_manage','',0,'0',1,1,1,1,1),(1053,'role_delete',50,'admin','role','delete','',0,'0',1,1,1,1,1),(1054,'member_model_export',77,'member','member_model','export','',0,'0',1,1,1,1,1),(1055,'member_model_sort',77,'member','member_model','sort','',0,'0',1,1,1,1,1),(1056,'member_model_move',77,'member','member_model','move','',0,'0',1,1,1,1,1),(1057,'payment_add',897,'pay','payment','add','',0,'0',1,1,1,1,1),(1058,'payment_delete',897,'pay','payment','delete','',0,'0',1,1,1,1,1),(1059,'payment_edit',897,'pay','payment','edit','',0,'0',1,1,1,1,1),(1060,'spend_record',896,'pay','spend','init','',0,'1',1,1,1,1,1),(1061,'pay_stat',896,'pay','payment','pay_stat','',0,'1',1,1,1,1,1),(1062,'fields_manage',59,'content','sitemodel_field','init','',0,'0',1,1,1,1,1),(1063,'edit_model_content',59,'content','sitemodel','edit','',0,'0',1,1,1,1,1),(1064,'disabled_model',59,'content','sitemodel','disabled','',0,'0',1,1,1,1,1),(1065,'delete_model',59,'content','sitemodel','delete','',0,'0',1,1,1,1,1),(1066,'export_model',59,'content','sitemodel','export','',0,'0',1,1,1,1,1),(1067,'delete',874,'content','type_manage','delete','',0,'0',1,1,1,1,1),(1068,'edit',874,'content','type_manage','edit','',0,'0',1,1,1,1,1),(1069,'add_urlrule',978,'admin','urlrule','add','',0,'0',1,1,1,1,1),(1070,'edit_urlrule',978,'admin','urlrule','edit','',0,'0',1,1,1,1,1),(1071,'delete_urlrule',978,'admin','urlrule','delete','',0,'0',1,1,1,1,1),(1072,'edit_menu',31,'admin','menu','edit','',0,'0',1,1,1,1,1),(1073,'delete_menu',31,'admin','menu','delete','',0,'0',1,1,1,1,1),(1074,'edit_workflow',885,'content','workflow','edit','',0,'0',1,1,1,1,1),(1075,'delete_workflow',885,'content','workflow','delete','',0,'0',1,1,1,1,1),(1076,'creat_html',868,'special','special','html','',0,'1',1,1,1,1,1),(1093,'connect_config',30,'admin','setting','init','&tab=5',14,'1',1,1,1,1,1),(1102,'view_modelinfo',74,'member','member_verify','modelinfo','',0,'0',1,1,1,1,1),(1202,'create_special_list',868,'special','special','create_special_list','',0,'1',1,1,1,1,1),(1240,'view_memberlinfo',72,'member','member','memberinfo','',0,'0',1,1,1,1,1),(1241,'move_content',822,'content','content','remove','',0,'0',1,1,1,1,1),(1242,'poster_template',56,'poster','space','poster_template','',0,'1',1,1,1,1,1),(1243,'create_index',873,'content','create_html','public_index','',0,'1',1,1,1,1,1),(1244,'add_othors',822,'content','content','add_othors','',0,'1',1,1,1,1,1),(1295,'attachment_manager_dir',857,'attachment','manage','dir','',2,'1',1,1,1,1,1),(1296,'attachment_manager_db',857,'attachment','manage','init','',1,'1',1,1,1,1,1),(1346,'attachment_address_replace',857,'attachment','address','init','',3,'1',1,1,1,1,1),(1347,'attachment_address_update',857,'attachment','address','update','',0,'0',1,1,1,1,1),(1348,'delete_content',822,'content','content','delete','',0,'1',1,1,1,1,1),(1349,'member_menu_manage',977,'member','member_menu','manage','',0,'1',1,1,1,1,1),(1350,'member_menu_add',1349,'member','member_menu','add','',0,'1',1,1,1,1,1),(1351,'member_menu_edit',1349,'member','member_menu','edit','',0,'0',1,1,1,1,1),(1352,'member_menu_delete',1349,'member','member_menu','delete','',0,'0',1,1,1,1,1),(1353,'batch_show',822,'content','create_html','batch_show','',0,'1',1,1,1,1,1),(1354,'pay_delete',898,'pay','payment','pay_del','',0,'0',1,1,1,1,1),(1355,'pay_cancel',898,'pay','payment','pay_cancel','',0,'0',1,1,1,1,1),(1356,'discount',898,'pay','payment','discount','',0,'0',1,1,1,1,1),(1360,'category_batch_edit',43,'admin','category','batch_edit','',6,'1',1,1,1,1,1),(1500,'listorder',822,'content','content','listorder','',0,'0',1,1,1,1,1),(1501,'a_clean_data',873,'content','content','clear_data','',0,'0',0,0,0,0,0),(1589,'video',9,'video','video','init','',0,'1',1,1,1,1,1),(1583,'sub_delete',1589,'video','video','sub_del','',0,'0',1,1,1,1,1),(1582,'subscribe_manage',1589,'video','video','subscribe_list','',0,'1',1,1,1,1,1),(1581,'video_open',1589,'video','video','open','',0,'1',1,1,1,1,1),(1592,'complete_info',1581,'video','video','complete_info','',0,'1',1,1,1,1,1),(1591,'video_inputinfo',1581,'video','video','open','',0,'1',1,1,1,1,1),(1577,'video_manage',1589,'video','video','init','',0,'1',1,1,1,1,1),(1590,'player_manage',1589,'video','player','init','',0,'1',1,1,1,1,1),(1585,'import_ku6_video',1589,'video','video','import_ku6video','',0,'1',1,1,1,1,1),(1579,'video_edit',1589,'video','video','edit','',0,'0',1,1,1,1,1),(1580,'video_delete',1589,'video','video','delete','',0,'0',1,1,1,1,1),(1578,'video_upload',1589,'video','video','add','',0,'1',1,1,1,1,1),(1593,'video_stat',1589,'video','stat','init','',0,'1',1,1,1,1,1),(1586,'video_store',1589,'video','video','video2content','',0,'0',1,1,1,1,1),(1595,'announce_add',1594,'announce','admin_announce','add','',0,'0',1,1,1,1,1),(1596,'edit_announce',1594,'announce','admin_announce','edit','s=1',0,'0',1,1,1,1,1),(1597,'check_announce',1594,'announce','admin_announce','init','s=2',0,'1',1,1,1,1,1),(1598,'overdue',1594,'announce','admin_announce','init','s=3',0,'1',1,1,1,1,1),(1599,'del_announce',1594,'announce','admin_announce','delete','',0,'0',1,1,1,1,1),(1602,'comment_check',1601,'comment','check','checks','',0,'1',1,1,1,1,1),(1603,'comment_list',1600,'comment','comment_admin','lists','',0,'0',1,1,1,1,1),(1604,'link',29,'link','link','init','',0,'1',1,1,1,1,1),(1605,'add_link',1604,'link','link','add','',0,'0',1,1,1,1,1),(1606,'edit_link',1604,'link','link','edit','',0,'0',1,1,1,1,1),(1607,'delete_link',1604,'link','link','delete','',0,'0',1,1,1,1,1),(1608,'link_setting',1604,'link','link','setting','',0,'1',1,1,1,1,1),(1609,'add_type',1604,'link','link','add_type','',0,'1',1,1,1,1,1),(1610,'list_type',1604,'link','link','list_type','',0,'1',1,1,1,1,1),(1611,'check_register',1604,'link','link','check_register','',0,'1',1,1,1,1,1),(1613,'add_vote',1612,'vote','vote','add','',0,'0',1,1,1,1,1),(1614,'edit_vote',1612,'vote','vote','edit','',0,'0',1,1,1,1,1),(1615,'delete_vote',1612,'vote','vote','delete','',0,'0',1,1,1,1,1),(1616,'vote_setting',1612,'vote','vote','setting','',0,'1',1,1,1,1,1),(1617,'statistics_vote',1612,'vote','vote','statistics','',0,'0',1,1,1,1,1),(1618,'statistics_userlist',1612,'vote','vote','statistics_userlist','',0,'0',1,1,1,1,1),(1619,'create_js',1612,'vote','vote','create_js','',0,'1',1,1,1,1,1),(1621,'send_one',1620,'message','message','send_one','',0,'1',1,1,1,1,1),(1622,'delete_message',1620,'message','message','delete','',0,'0',1,1,1,1,1),(1623,'message_send',1620,'message','message','message_send','',0,'0',1,1,1,1,1),(1624,'message_group_manage',1620,'message','message','message_group_manage','',0,'1',1,1,1,1,1),(1626,'mood_setting',1625,'mood','mood_admin','setting','',0,'1',1,1,1,1,1),(1627,'poster',29,'poster','space','init','',0,'1',1,1,1,1,1),(1628,'add_space',1627,'poster','space','add','',0,'0',1,1,1,1,1),(1629,'edit_space',1627,'poster','space','edit','',0,'0',1,1,1,1,1),(1630,'del_space',1627,'poster','space','delete','',0,'0',1,1,1,1,1),(1631,'poster_list',1627,'poster','poster','init','',0,'0',1,1,1,1,1),(1632,'add_poster',1627,'poster','poster','add','',0,'0',1,1,1,1,1),(1633,'edit_poster',1627,'poster','poster','edit','',0,'0',1,1,1,1,1),(1634,'del_poster',1627,'poster','poster','delete','',0,'0',1,1,1,1,1),(1635,'poster_stat',1627,'poster','poster','stat','',0,'0',1,1,1,1,1),(1636,'poster_setting',1627,'poster','space','setting','',0,'0',1,1,1,1,1),(1637,'create_poster_js',1627,'poster','space','create_js','',0,'1',1,1,1,1,1),(1638,'poster_template',1627,'poster','space','poster_template','',0,'1',1,1,1,1,1),(1639,'formguide',29,'formguide','formguide','init','',0,'0',1,1,1,1,1),(1640,'formguide_add',1639,'formguide','formguide','add','',0,'0',1,1,1,1,1),(1641,'formguide_edit',1639,'formguide','formguide','edit','',0,'0',1,1,1,1,1),(1642,'form_info_list',1639,'formguide','formguide_info','init','',0,'0',1,1,1,1,1),(1643,'formguide_disabled',1639,'formguide','formguide','disabled','',0,'0',1,1,1,1,1),(1644,'formguide_delete',1639,'formguide','formguide','delete','',0,'0',1,1,1,1,1),(1645,'formguide_stat',1639,'formguide','formguide','stat','',0,'0',1,1,1,1,1),(1646,'add_public_field',1639,'formguide','formguide_field','add','',0,'1',1,1,1,1,1),(1647,'list_public_field',1639,'formguide','formguide_field','init','',0,'1',1,1,1,1,1),(1648,'module_setting',1639,'formguide','formguide','setting','',0,'0',1,1,1,1,1),(1649,'wap',29,'wap','wap_admin','init','',0,'0',1,1,1,1,1),(1650,'wap_add',1649,'wap','wap_admin','add','',0,'0',1,1,1,1,1),(1651,'wap_edit',1649,'wap','wap_admin','edit','',0,'0',1,1,1,1,1),(1652,'wap_delete',1649,'wap','wap_admin','delete','',0,'0',1,1,1,1,1),(1653,'wap_type_manage',1649,'wap','wap_admin','type_manage','',0,'0',1,1,1,1,1),(1654,'wap_type_edit',1649,'wap','wap_admin','type_edit','',0,'0',1,1,1,1,1),(1655,'wap_type_delete',1649,'wap','wap_admin','type_delete','',0,'0',1,1,1,1,1),(1656,'upgrade',977,'upgrade','index','init','',0,'1',1,1,1,1,1),(1657,'checkfile',1656,'upgrade','index','checkfile','',0,'1',1,1,1,1,1),(1658,'tag',826,'tag','tag','init','',0,'1',1,1,1,1,1),(1659,'add_tag',1658,'tag','tag','add','',0,'0',1,1,1,1,1),(1660,'edit_tag',1658,'tag','tag','edit','',0,'0',1,1,1,1,1),(1661,'delete_tag',1658,'tag','tag','del','',0,'0',1,1,1,1,1),(1662,'tag_lists',1658,'tag','tag','lists','',0,'0',1,1,1,1,1),(1664,'sms_setting',1663,'sms','sms','sms_setting','',0,'1',1,1,1,1,1),(1665,'sms_pay_history',1663,'sms','sms','sms_pay_history','',0,'1',1,1,1,1,1),(1666,'sms_buy_history',1663,'sms','sms','sms_buy_history','',0,'1',1,1,1,1,1),(1667,'sms_api',1663,'sms','sms','sms_api','',0,'1',1,1,1,1,1),(1668,'sms_sent',1663,'sms','sms','sms_sent','',0,'1',1,1,1,1,1);
/*!40000 ALTER TABLE `v9_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_message`
--

DROP TABLE IF EXISTS `v9_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_message` (
  `messageid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `send_from_id` char(30) NOT NULL DEFAULT '0',
  `send_to_id` char(30) NOT NULL DEFAULT '0',
  `folder` enum('all','inbox','outbox') NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `message_time` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` char(80) DEFAULT NULL,
  `content` text NOT NULL,
  `replyid` int(10) unsigned NOT NULL DEFAULT '0',
  `del_type` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`messageid`),
  KEY `msgtoid` (`send_to_id`,`folder`),
  KEY `replyid` (`replyid`),
  KEY `folder` (`send_from_id`,`folder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_message`
--

LOCK TABLES `v9_message` WRITE;
/*!40000 ALTER TABLE `v9_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_message_data`
--

DROP TABLE IF EXISTS `v9_message_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_message_data` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) NOT NULL,
  `group_message_id` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `message` (`userid`,`group_message_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_message_data`
--

LOCK TABLES `v9_message_data` WRITE;
/*!40000 ALTER TABLE `v9_message_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_message_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_message_group`
--

DROP TABLE IF EXISTS `v9_message_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_message_group` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `groupid` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '用户组id',
  `subject` char(80) DEFAULT NULL,
  `content` text NOT NULL COMMENT '内容',
  `inputtime` int(10) unsigned DEFAULT '0',
  `status` tinyint(2) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_message_group`
--

LOCK TABLES `v9_message_group` WRITE;
/*!40000 ALTER TABLE `v9_message_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_message_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_model`
--

DROP TABLE IF EXISTS `v9_model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_model` (
  `modelid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` char(30) NOT NULL,
  `description` char(100) NOT NULL,
  `tablename` char(20) NOT NULL,
  `setting` text NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `items` smallint(5) unsigned NOT NULL DEFAULT '0',
  `enablesearch` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `default_style` char(30) NOT NULL,
  `category_template` char(30) NOT NULL,
  `list_template` char(30) NOT NULL,
  `show_template` char(30) NOT NULL,
  `js_template` varchar(30) NOT NULL,
  `admin_list_template` char(30) NOT NULL,
  `member_add_template` varchar(30) NOT NULL,
  `member_list_template` varchar(30) NOT NULL,
  `sort` tinyint(3) NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`modelid`),
  KEY `type` (`type`,`siteid`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_model`
--

LOCK TABLES `v9_model` WRITE;
/*!40000 ALTER TABLE `v9_model` DISABLE KEYS */;
INSERT INTO `v9_model` VALUES (1,1,'文章模型','','news','',0,0,1,0,'default','category','list','show','','','','',0,0),(2,1,'下载模型','','download','',0,0,1,0,'default','category_download','list_download','show_download','','','','',0,0),(3,1,'图片模型','','picture','',0,0,1,0,'default','category_picture','list_picture','show_picture','','','','',0,0),(10,1,'普通会员','普通会员','member_detail','',0,0,1,0,'','','','','','','','',0,2),(11,1,'视频模型','','video','',0,0,1,0,'default','category_video','list_video','show_video','','','','',0,0),(12,1,'配置模型','','sys','',0,0,1,0,'','','','','','','','',0,0);
/*!40000 ALTER TABLE `v9_model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_model_field`
--

DROP TABLE IF EXISTS `v9_model_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_model_field` (
  `fieldid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `field` varchar(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `tips` text NOT NULL,
  `css` varchar(30) NOT NULL,
  `minlength` int(10) unsigned NOT NULL DEFAULT '0',
  `maxlength` int(10) unsigned NOT NULL DEFAULT '0',
  `pattern` varchar(255) NOT NULL,
  `errortips` varchar(255) NOT NULL,
  `formtype` varchar(20) NOT NULL,
  `setting` mediumtext NOT NULL,
  `formattribute` varchar(255) NOT NULL,
  `unsetgroupids` varchar(255) NOT NULL,
  `unsetroleids` varchar(255) NOT NULL,
  `iscore` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issystem` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isunique` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isbase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `issearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isadd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isfulltext` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isposition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `listorder` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isomnipotent` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`fieldid`),
  KEY `modelid` (`modelid`,`disabled`),
  KEY `field` (`field`,`modelid`)
) ENGINE=MyISAM AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_model_field`
--

LOCK TABLES `v9_model_field` WRITE;
/*!40000 ALTER TABLE `v9_model_field` DISABLE KEYS */;
INSERT INTO `v9_model_field` VALUES (1,1,1,'catid','栏目','','',1,6,'/^[0-9]{1,6}$/','请选择栏目','catid','array (\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,1,0,1,1,1,0,0,1,0,0),(2,1,1,'typeid','类别','','',0,0,'','','typeid','array (\n  \'minnumber\' => \'\',\n  \'defaultvalue\' => \'\',\n)','','','',0,1,0,1,1,1,0,0,2,0,0),(3,1,1,'title','标题','','inputtitle',1,80,'','请输入标题','title','','','','',0,1,0,1,1,1,1,1,4,0,0),(4,1,1,'thumb','缩略图','','',0,100,'','','image','array (\n  \'size\' => \'50\',\n  \'defaultvalue\' => \'\',\n  \'show_type\' => \'1\',\n  \'upload_maxsize\' => \'1024\',\n  \'upload_allowext\' => \'jpg|jpeg|gif|png|bmp\',\n  \'watermark\' => \'0\',\n  \'isselectimage\' => \'1\',\n  \'images_width\' => \'\',\n  \'images_height\' => \'\',\n)','','','',0,1,0,0,0,1,0,1,14,0,0),(5,1,1,'keywords','关键词','多关键词之间用空格或者“,”隔开','',0,40,'','','keyword','array (\r\n  \'size\' => \'100\',\r\n  \'defaultvalue\' => \'\',\r\n)','','-99','-99',0,1,0,1,1,1,1,0,7,0,0),(6,1,1,'description','摘要','','',0,255,'','','textarea','array (\r\n  \'width\' => \'98\',\r\n  \'height\' => \'46\',\r\n  \'defaultvalue\' => \'\',\r\n  \'enablehtml\' => \'0\',\r\n)','','','',0,1,0,1,0,1,1,1,10,0,0),(7,1,1,'updatetime','更新时间','','',0,0,'','','datetime','array (\r\n  \'dateformat\' => \'int\',\r\n  \'format\' => \'Y-m-d H:i:s\',\r\n  \'defaulttype\' => \'1\',\r\n  \'defaultvalue\' => \'\',\r\n)','','','',1,1,0,1,0,0,0,0,12,0,0),(8,1,1,'content','内容','<div class=\"content_attr\"><label><input name=\"add_introduce\" type=\"checkbox\"  value=\"1\" checked>是否截取内容</label><input type=\"text\" name=\"introcude_length\" value=\"200\" size=\"3\">字符至内容摘要\r\n<label><input type=\'checkbox\' name=\'auto_thumb\' value=\"1\" checked>是否获取内容第</label><input type=\"text\" name=\"auto_thumb_no\" value=\"1\" size=\"2\" class=\"\">张图片作为标题图片\r\n</div>','',1,999999,'','内容不能为空','editor','array (\n  \'toolbar\' => \'full\',\n  \'defaultvalue\' => \'\',\n  \'enablekeylink\' => \'1\',\n  \'replacenum\' => \'2\',\n  \'link_mode\' => \'0\',\n  \'enablesaveimage\' => \'1\',\n)','','','',0,0,0,1,0,1,1,0,13,0,0),(9,1,1,'voteid','添加投票','','',0,0,'','','omnipotent','array (\n  \'formtext\' => \'<input type=\\\'text\\\' name=\\\'info[voteid]\\\' id=\\\'voteid\\\' value=\\\'{FIELD_VALUE}\\\' size=\\\'3\\\'> \r\n<input type=\\\'button\\\' value=\"选择已有投票\" onclick=\"omnipotent(\\\'selectid\\\',\\\'?m=vote&c=vote&a=public_get_votelist&from_api=1\\\',\\\'选择已有投票\\\')\" class=\"button\">\r\n<input type=\\\'button\\\' value=\"新增投票\" onclick=\"omnipotent(\\\'addvote\\\',\\\'?m=vote&c=vote&a=add&from_api=1\\\',\\\'添加投票\\\',0)\" class=\"button\">\',\n  \'fieldtype\' => \'mediumint\',\n  \'minnumber\' => \'1\',\n)','','','',0,0,0,1,0,0,1,0,21,1,0),(10,1,1,'pages','分页方式','','',0,0,'','','pages','','','-99','-99',0,0,0,1,0,0,0,0,16,0,0),(11,1,1,'inputtime','发布时间','','',0,0,'','','datetime','array (\n  \'fieldtype\' => \'int\',\n  \'format\' => \'Y-m-d H:i:s\',\n  \'defaulttype\' => \'0\',\n)','','','',0,1,0,0,0,0,0,1,17,0,0),(12,1,1,'posids','推荐位','','',0,0,'','','posid','array (\n  \'cols\' => \'4\',\n  \'width\' => \'125\',\n)','','','',0,1,0,1,0,0,0,0,18,0,0),(13,1,1,'url','URL','','',0,100,'','','text','','','','',1,1,0,1,0,0,0,0,50,0,0),(14,1,1,'listorder','排序','','',0,6,'','','number','','','','',1,1,0,1,0,0,0,0,51,0,0),(15,1,1,'status','状态','','',0,2,'','','box','','','','',1,1,0,1,0,0,0,0,55,0,0),(16,1,1,'template','内容页模板','','',0,30,'','','template','array (\n  \'size\' => \'\',\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,0,0,0,0,0,0,0,53,0,0),(17,1,1,'groupids_view','阅读权限','','',0,0,'','','groupid','array (\n  \'groupids\' => \'\',\n)','','','',0,0,0,1,0,0,0,0,19,1,0),(18,1,1,'readpoint','阅读收费','','',0,5,'','','readpoint','array (\n  \'minnumber\' => \'1\',\n  \'maxnumber\' => \'99999\',\n  \'decimaldigits\' => \'0\',\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,0,0,0,0,0,0,0,55,1,0),(19,1,1,'relation','相关文章','','',0,0,'','','omnipotent','array (\n  \'formtext\' => \'<input type=\\\'hidden\\\' name=\\\'info[relation]\\\' id=\\\'relation\\\' value=\\\'{FIELD_VALUE}\\\' style=\\\'50\\\' >\r\n<ul class=\"list-dot\" id=\"relation_text\"></ul>\r\n<div>\r\n<input type=\\\'button\\\' value=\"添加相关\" onclick=\"omnipotent(\\\'selectid\\\',\\\'?m=content&c=content&a=public_relationlist&modelid={MODELID}\\\',\\\'添加相关文章\\\',1)\" class=\"button\" style=\"width:66px;\">\r\n<span class=\"edit_content\">\r\n<input type=\\\'button\\\' value=\"显示已有\" onclick=\"show_relation({MODELID},{ID})\" class=\"button\" style=\"width:66px;\">\r\n</span>\r\n</div>\',\n  \'fieldtype\' => \'varchar\',\n  \'minnumber\' => \'1\',\n)','','2,6,4,5,1,17,18,7','',0,0,0,0,0,0,1,0,15,1,0),(20,1,1,'allow_comment','允许评论','','',0,0,'','','box','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'boxtype\' => \'radio\',\n  \'fieldtype\' => \'tinyint\',\n  \'minnumber\' => \'1\',\n  \'width\' => \'88\',\n  \'size\' => \'1\',\n  \'defaultvalue\' => \'1\',\n  \'outputtype\' => \'1\',\n  \'filtertype\' => \'0\',\n)','','','',0,0,0,0,0,0,0,0,54,1,0),(21,1,1,'copyfrom','来源','','',0,100,'','','copyfrom','array (\n  \'defaultvalue\' => \'\',\n)','','','',0,0,0,1,0,1,0,0,8,1,0),(80,1,1,'username','用户名','','',0,20,'','','text','','','','',1,1,0,1,0,0,0,0,98,0,0),(22,2,1,'catid','栏目','','',1,6,'/^[0-9]{1,6}$/','请选择栏目','catid','array (\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,1,0,1,1,1,0,0,1,0,0),(23,2,1,'typeid','类别','','',0,0,'','','typeid','array (\n  \'minnumber\' => \'\',\n  \'defaultvalue\' => \'\',\n)','','','',0,1,0,1,1,1,0,0,2,1,0),(24,2,1,'title','标题','','inputtitle',1,80,'','请输入标题','title','','','','',0,1,0,1,1,1,1,1,4,0,0),(25,2,1,'keywords','关键词','多关键词之间用空格或者“,”隔开','',0,40,'','','keyword','array (\r\n  \'size\' => \'100\',\r\n  \'defaultvalue\' => \'\',\r\n)','','-99','-99',0,1,0,1,1,1,1,0,7,0,0),(26,2,1,'description','摘要','','',0,255,'','','textarea','array (\r\n  \'width\' => \'98\',\r\n  \'height\' => \'46\',\r\n  \'defaultvalue\' => \'\',\r\n  \'enablehtml\' => \'0\',\r\n)','','','',0,1,0,1,0,1,1,1,10,0,0),(27,2,1,'updatetime','更新时间','','',0,0,'','','datetime','array (\r\n  \'dateformat\' => \'int\',\r\n  \'format\' => \'Y-m-d H:i:s\',\r\n  \'defaulttype\' => \'1\',\r\n  \'defaultvalue\' => \'\',\r\n)','','','',1,1,0,1,0,0,0,0,12,0,0),(28,2,1,'content','内容','<div class=\"content_attr\"><label><input name=\"add_introduce\" type=\"checkbox\"  value=\"1\" checked>是否截取内容</label><input type=\"text\" name=\"introcude_length\" value=\"200\" size=\"3\">字符至内容摘要\r\n<label><input type=\'checkbox\' name=\'auto_thumb\' value=\"1\" checked>是否获取内容第</label><input type=\"text\" name=\"auto_thumb_no\" value=\"1\" size=\"2\" class=\"\">张图片作为标题图片\r\n</div>','',1,999999,'','内容不能为空','editor','array (\n  \'toolbar\' => \'full\',\n  \'defaultvalue\' => \'\',\n  \'enablekeylink\' => \'1\',\n  \'replacenum\' => \'2\',\n  \'link_mode\' => \'0\',\n  \'enablesaveimage\' => \'1\',\n  \'height\' => \'\',\n  \'disabled_page\' => \'1\',\n)','','','',0,0,0,1,0,1,1,0,13,0,0),(29,2,1,'thumb','缩略图','','',0,100,'','','image','array (\n  \'size\' => \'50\',\n  \'defaultvalue\' => \'\',\n  \'show_type\' => \'1\',\n  \'upload_maxsize\' => \'1024\',\n  \'upload_allowext\' => \'jpg|jpeg|gif|png|bmp\',\n  \'watermark\' => \'0\',\n  \'isselectimage\' => \'1\',\n  \'images_width\' => \'\',\n  \'images_height\' => \'\',\n)','','','',0,1,0,0,0,1,0,1,14,0,0),(30,2,1,'relation','相关文章','','',0,0,'','','omnipotent','array (\n  \'formtext\' => \'<input type=\\\'hidden\\\' name=\\\'info[relation]\\\' id=\\\'relation\\\' value=\\\'{FIELD_VALUE}\\\' style=\\\'50\\\' >\r\n<ul class=\"list-dot\" id=\"relation_text\"></ul>\r\n<div>\r\n<input type=\\\'button\\\' value=\"添加相关\" onclick=\"omnipotent(\\\'selectid\\\',\\\'?m=content&c=content&a=public_relationlist&modelid={MODELID}\\\',\\\'添加相关文章\\\',1)\" class=\"button\" style=\"width:66px;\">\r\n<span class=\"edit_content\">\r\n<input type=\\\'button\\\' value=\"显示已有\" onclick=\"show_relation({MODELID},{ID})\" class=\"button\" style=\"width:66px;\">\r\n</span>\r\n</div>\',\n  \'fieldtype\' => \'varchar\',\n  \'minnumber\' => \'1\',\n)','','2,6,4,5,1,17,18,7','',0,0,0,0,0,0,1,0,15,0,0),(31,2,1,'pages','分页方式','','',0,0,'','','pages','','','-99','-99',0,0,0,1,0,0,0,0,16,1,0),(32,2,1,'inputtime','发布时间','','',0,0,'','','datetime','array (\n  \'fieldtype\' => \'int\',\n  \'format\' => \'Y-m-d H:i:s\',\n  \'defaulttype\' => \'0\',\n)','','','',0,1,0,0,0,0,0,1,17,0,0),(33,2,1,'posids','推荐位','','',0,0,'','','posid','array (\n  \'cols\' => \'4\',\n  \'width\' => \'125\',\n)','','','',0,1,0,1,0,0,0,0,18,0,0),(34,2,1,'groupids_view','阅读权限','','',0,0,'','','groupid','array (\n  \'groupids\' => \'\',\n)','','','',0,0,0,1,0,0,0,0,19,0,0),(35,2,1,'url','URL','','',0,100,'','','text','','','','',1,1,0,1,0,0,0,0,50,0,0),(36,2,1,'listorder','排序','','',0,6,'','','number','','','','',1,1,0,1,0,0,0,0,51,0,0),(37,2,1,'template','内容页模板','','',0,30,'','','template','array (\n  \'size\' => \'\',\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,0,0,0,0,0,0,0,53,0,0),(38,2,1,'allow_comment','允许评论','','',0,0,'','','box','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'boxtype\' => \'radio\',\n  \'fieldtype\' => \'tinyint\',\n  \'minnumber\' => \'1\',\n  \'width\' => \'88\',\n  \'size\' => \'1\',\n  \'defaultvalue\' => \'1\',\n  \'outputtype\' => \'1\',\n  \'filtertype\' => \'0\',\n)','','','',0,0,0,0,0,0,0,0,54,0,0),(39,2,1,'status','状态','','',0,2,'','','box','','','','',1,1,0,1,0,0,0,0,55,0,0),(40,2,1,'readpoint','阅读收费','','',0,5,'','','readpoint','array (\n  \'minnumber\' => \'1\',\n  \'maxnumber\' => \'99999\',\n  \'decimaldigits\' => \'0\',\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,0,0,0,0,0,0,0,55,0,0),(41,2,1,'username','用户名','','',0,20,'','','text','','','','',1,1,0,1,0,0,0,0,98,0,0),(42,2,1,'downfiles','本地下载','','',0,0,'','','downfiles','array (\n  \'upload_allowext\' => \'rar|zip\',\n  \'isselectimage\' => \'0\',\n  \'upload_number\' => \'10\',\n  \'downloadlink\' => \'1\',\n  \'downloadtype\' => \'1\',\n)','','','',0,0,0,1,0,1,0,0,8,0,0),(43,2,1,'downfile','镜像下载','','',0,0,'','','downfile','array (\n  \'downloadlink\' => \'1\',\n  \'downloadtype\' => \'1\',\n  \'upload_allowext\' => \'rar|zip\',\n  \'isselectimage\' => \'0\',\n  \'upload_number\' => \'1\',\n)','','','',0,0,0,1,0,1,0,0,9,0,0),(44,2,1,'systems','软件平台','<select name=\'selectSystem\' onchange=\"ChangeInput(this,document.myform.systems,\'/\')\">\r\n	<option value=\'WinXP\'>WinXP</option>\r\n	<option value=\'Vista\'>Windows 7</option>\r\n	<option value=\'Win2000\'>Win2000</option>\r\n	<option value=\'Win2003\'>Win2003</option>\r\n	<option value=\'Unix\'>Unix</option>\r\n	<option value=\'Linux\'>Linux</option>\r\n	<option value=\'MacOS\'>MacOS</option>\r\n</select>','',0,100,'','','text','array (\n  \'size\' => \'50\',\n  \'defaultvalue\' => \'Win2000/WinXP/Win2003\',\n  \'ispassword\' => \'0\',\n)','','','',0,1,0,1,0,1,1,0,14,0,0),(45,2,1,'copytype','软件授权形式','','',0,15,'','','box','array (\n  \'options\' => \'免费版|免费版\r\n共享版|共享版\r\n试用版|试用版\r\n演示版|演示版\r\n注册版|注册版\r\n破解版|破解版\r\n零售版|零售版\r\nOEM版|OEM版\',\n  \'boxtype\' => \'select\',\n  \'fieldtype\' => \'varchar\',\n  \'minnumber\' => \'1\',\n  \'cols\' => \'5\',\n  \'width\' => \'80\',\n  \'size\' => \'1\',\n  \'default_select_value\' => \'免费版\',\n)','','','',0,1,0,1,0,1,0,0,12,0,0),(46,2,1,'language','软件语言','','',0,16,'','','box','array (\n  \'options\' => \'英文|英文\r\n简体中文|简体中文\r\n繁体中文|繁体中文\r\n简繁中文|简繁中文\r\n多国语言|多国语言\r\n其他语言|其他语言\',\n  \'boxtype\' => \'select\',\n  \'fieldtype\' => \'varchar\',\n  \'minnumber\' => \'1\',\n  \'cols\' => \'5\',\n  \'width\' => \'80\',\n  \'size\' => \'1\',\n  \'default_select_value\' => \'简体中文\',\n)','','','',0,1,0,1,0,1,0,0,13,0,0),(47,2,1,'classtype','软件类型','','',0,20,'','','box','array (\n  \'options\' => \'国产软件|国产软件\r\n国外软件|国外软件\r\n汉化补丁|汉化补丁\r\n程序源码|程序源码\r\n其他|其他\',\n  \'boxtype\' => \'radio\',\n  \'fieldtype\' => \'varchar\',\n  \'minnumber\' => \'1\',\n  \'cols\' => \'5\',\n  \'width\' => \'80\',\n  \'size\' => \'1\',\n  \'default_select_value\' => \'国产软件\',\n)','','','',0,1,0,1,0,1,0,0,17,0,0),(48,2,1,'version','版本号','','',0,20,'','','text','array (\n  \'size\' => \'10\',\n  \'defaultvalue\' => \'\',\n  \'ispassword\' => \'0\',\n)','','','',0,1,0,0,0,1,1,0,13,0,0),(49,2,1,'filesize','文件大小','','',0,10,'','','text','array (\n  \'size\' => \'10\',\n  \'defaultvalue\' => \'未知\',\n  \'ispassword\' => \'0\',\n)','','','',0,1,0,0,0,1,1,0,14,0,0),(50,2,1,'stars','评分等级','','',0,20,'','','box','array (\n  \'options\' => \'★☆☆☆☆|★☆☆☆☆\r\n★★☆☆☆|★★☆☆☆\r\n★★★☆☆|★★★☆☆\r\n★★★★☆|★★★★☆\r\n★★★★★|★★★★★\',\n  \'boxtype\' => \'radio\',\n  \'fieldtype\' => \'varchar\',\n  \'minnumber\' => \'1\',\n  \'cols\' => \'5\',\n  \'width\' => \'88\',\n  \'size\' => \'1\',\n  \'default_select_value\' => \'★★★☆☆\',\n)','','','',0,1,0,1,0,1,0,0,17,0,0),(51,3,1,'allow_comment','允许评论','','',0,0,'','','box','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'boxtype\' => \'radio\',\n  \'fieldtype\' => \'tinyint\',\n  \'minnumber\' => \'1\',\n  \'width\' => \'88\',\n  \'size\' => \'1\',\n  \'defaultvalue\' => \'1\',\n  \'outputtype\' => \'1\',\n  \'filtertype\' => \'0\',\n)','','','',0,0,0,0,0,0,0,0,54,0,0),(52,3,1,'template','内容页模板','','',0,30,'','','template','array (\n  \'size\' => \'\',\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,0,0,0,0,0,0,0,53,0,0),(53,3,1,'url','URL','','',0,100,'','','text','','','','',1,1,0,1,0,0,0,0,50,0,0),(54,3,1,'listorder','排序','','',0,6,'','','number','','','','',1,1,0,1,0,0,0,0,51,0,0),(55,3,1,'posids','推荐位','','',0,0,'','','posid','array (\n  \'cols\' => \'4\',\n  \'width\' => \'125\',\n)','','','',0,1,0,1,0,0,0,0,18,0,0),(56,3,1,'groupids_view','阅读权限','','',0,0,'','','groupid','array (\n  \'groupids\' => \'\',\n)','','','',0,0,0,1,0,0,0,0,19,0,0),(57,3,1,'inputtime','发布时间','','',0,0,'','','datetime','array (\n  \'fieldtype\' => \'int\',\n  \'format\' => \'Y-m-d H:i:s\',\n  \'defaulttype\' => \'0\',\n)','','','',0,1,0,0,0,0,0,1,17,0,0),(58,3,1,'pages','分页方式','','',0,0,'','','pages','','','-99','-99',0,0,0,1,0,0,0,0,16,0,0),(59,3,1,'relation','相关组图','','',0,0,'','','omnipotent','array (\n  \'formtext\' => \'<input type=\\\'hidden\\\' name=\\\'info[relation]\\\' id=\\\'relation\\\' value=\\\'{FIELD_VALUE}\\\' style=\\\'50\\\' >\r\n<ul class=\"list-dot\" id=\"relation_text\"></ul>\r\n<div>\r\n<input type=\\\'button\\\' value=\"添加相关\" onclick=\"omnipotent(\\\'selectid\\\',\\\'?m=content&c=content&a=public_relationlist&modelid={MODELID}\\\',\\\'添加相关文章\\\',1)\" class=\"button\" style=\"width:66px;\">\r\n<span class=\"edit_content\">\r\n<input type=\\\'button\\\' value=\"显示已有\" onclick=\"show_relation({MODELID},{ID})\" class=\"button\" style=\"width:66px;\">\r\n</span>\r\n</div>\',\n  \'fieldtype\' => \'varchar\',\n  \'minnumber\' => \'1\',\n)','','2,6,4,5,1,17,18,7','',0,0,0,0,0,0,1,0,15,0,0),(60,3,1,'thumb','缩略图','','',0,100,'','','image','array (\n  \'size\' => \'50\',\n  \'defaultvalue\' => \'\',\n  \'show_type\' => \'1\',\n  \'upload_maxsize\' => \'1024\',\n  \'upload_allowext\' => \'jpg|jpeg|gif|png|bmp\',\n  \'watermark\' => \'0\',\n  \'isselectimage\' => \'1\',\n  \'images_width\' => \'\',\n  \'images_height\' => \'\',\n)','','','',0,1,0,0,0,1,0,1,14,0,0),(61,3,1,'content','内容','<div class=\"content_attr\"><label><input name=\"add_introduce\" type=\"checkbox\"  value=\"1\" checked>是否截取内容</label><input type=\"text\" name=\"introcude_length\" value=\"200\" size=\"3\">字符至内容摘要\r\n<label><input type=\'checkbox\' name=\'auto_thumb\' value=\"1\" checked>是否获取内容第</label><input type=\"text\" name=\"auto_thumb_no\" value=\"1\" size=\"2\" class=\"\">张图片作为标题图片\r\n</div>','',0,999999,'','','editor','array (\n  \'toolbar\' => \'full\',\n  \'defaultvalue\' => \'\',\n  \'enablekeylink\' => \'1\',\n  \'replacenum\' => \'2\',\n  \'link_mode\' => \'0\',\n  \'enablesaveimage\' => \'1\',\n  \'height\' => \'\',\n  \'disabled_page\' => \'1\',\n)','','','',0,0,0,1,0,1,1,0,13,0,0),(62,3,1,'updatetime','更新时间','','',0,0,'','','datetime','array (\r\n  \'dateformat\' => \'int\',\r\n  \'format\' => \'Y-m-d H:i:s\',\r\n  \'defaulttype\' => \'1\',\r\n  \'defaultvalue\' => \'\',\r\n)','','','',1,1,0,1,0,0,0,0,12,0,0),(63,3,1,'description','摘要','','',0,255,'','','textarea','array (\r\n  \'width\' => \'98\',\r\n  \'height\' => \'46\',\r\n  \'defaultvalue\' => \'\',\r\n  \'enablehtml\' => \'0\',\r\n)','','','',0,1,0,1,0,1,1,1,10,0,0),(64,3,1,'title','标题','','inputtitle',1,80,'','请输入标题','title','','','','',0,1,0,1,1,1,1,1,4,0,0),(65,3,1,'keywords','关键词','多关键词之间用空格或者“,”隔开','',0,40,'','','keyword','array (\r\n  \'size\' => \'100\',\r\n  \'defaultvalue\' => \'\',\r\n)','','-99','-99',0,1,0,1,1,1,1,0,7,0,0),(66,3,1,'typeid','类别','','',0,0,'','','typeid','array (\n  \'minnumber\' => \'\',\n  \'defaultvalue\' => \'\',\n)','','','',0,1,0,1,1,1,0,0,2,0,0),(67,3,1,'catid','栏目','','',1,6,'/^[0-9]{1,6}$/','请选择栏目','catid','array (\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,1,0,1,1,1,0,0,1,0,0),(68,3,1,'status','状态','','',0,2,'','','box','','','','',1,1,0,1,0,0,0,0,55,0,0),(69,3,1,'readpoint','阅读收费','','',0,5,'','','readpoint','array (\n  \'minnumber\' => \'1\',\n  \'maxnumber\' => \'99999\',\n  \'decimaldigits\' => \'0\',\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,0,0,0,0,0,0,0,55,0,0),(70,3,1,'username','用户名','','',0,20,'','','text','','','','',1,1,0,1,0,0,0,0,98,0,0),(71,3,1,'pictureurls','组图','','',0,0,'','','images','array (\n  \'upload_allowext\' => \'gif|jpg|jpeg|png|bmp\',\n  \'isselectimage\' => \'1\',\n  \'upload_number\' => \'50\',\n)','','','',0,0,0,1,0,1,0,0,15,0,0),(72,3,1,'copyfrom','来源','','',0,0,'','','copyfrom','array (\n  \'defaultvalue\' => \'\',\n)','','','',0,0,0,1,0,1,0,0,8,0,0),(73,1,1,'islink','转向链接','','',0,0,'','','islink','','','','',0,1,0,0,0,1,0,0,30,1,0),(74,2,1,'islink','转向链接','','',0,0,'','','islink','','','','',0,1,0,0,0,1,0,0,30,0,0),(75,3,1,'islink','转向链接','','',0,0,'','','islink','','','','',0,1,0,0,0,1,0,0,30,0,0),(83,10,1,'birthday','生日','','',0,0,'','生日格式错误','datetime','array (\n  \'fieldtype\' => \'date\',\n  \'format\' => \'Y-m-d\',\n  \'defaulttype\' => \'0\',\n)','','','',0,0,0,0,0,1,1,0,0,0,0),(84,11,1,'catid','栏目','','',1,6,'/^[0-9]{1,6}$/','请选择栏目','catid','array (\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,1,0,1,1,1,0,0,1,0,0),(85,11,1,'typeid','类别','','',0,0,'','','typeid','array (\n  \'minnumber\' => \'\',\n  \'defaultvalue\' => \'\',\n)','','','',0,1,0,1,1,1,0,0,2,0,0),(86,11,1,'title','标题','','inputtitle',1,80,'','请输入标题','title','array (\n)','','','',0,1,0,1,1,1,1,1,4,0,0),(87,11,1,'keywords','关键词','多关键词之间用空格或者“,”隔开','',0,40,'','','keyword','array (\n  \'size\' => \'100\',\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,1,0,1,1,1,1,0,7,0,0),(88,11,1,'description','摘要','','',0,255,'','','textarea','array (\n  \'width\' => \'98\',\n  \'height\' => \'46\',\n  \'defaultvalue\' => \'\',\n  \'enablehtml\' => \'0\',\n)','','','',0,1,0,1,0,1,1,1,10,0,0),(89,11,1,'updatetime','更新时间','','',0,0,'','','datetime','array (\n  \'dateformat\' => \'int\',\n  \'format\' => \'Y-m-d H:i:s\',\n  \'defaulttype\' => \'1\',\n  \'defaultvalue\' => \'\',\n)','','','',1,1,0,1,0,0,0,0,12,0,0),(90,11,1,'content','内容','<div class=\"content_attr\"><label><input name=\"add_introduce\" type=\"checkbox\"  value=\"1\" checked>是否截取内容</label><input type=\"text\" name=\"introcude_length\" value=\"200\" size=\"3\">字符至内容摘要\r\n<label><input type=\'checkbox\' name=\'auto_thumb\' value=\"1\" checked>是否获取内容第</label><input type=\"text\" name=\"auto_thumb_no\" value=\"1\" size=\"2\" class=\"\">张图片作为标题图片\r\n</div>','',0,999999,'','内容不能为空','editor','array (\n  \'toolbar\' => \'full\',\n  \'defaultvalue\' => \'\',\n  \'enablekeylink\' => \'1\',\n  \'replacenum\' => \'2\',\n  \'link_mode\' => \'0\',\n  \'enablesaveimage\' => \'1\',\n  \'height\' => \'\',\n  \'disabled_page\' => \'0\',\n)','','','',0,0,0,1,0,1,1,0,13,0,0),(91,11,1,'thumb','缩略图','','',0,100,'','','image','array (\n  \'size\' => \'50\',\n  \'defaultvalue\' => \'\',\n  \'show_type\' => \'1\',\n  \'upload_maxsize\' => \'1024\',\n  \'upload_allowext\' => \'jpg|jpeg|gif|png|bmp\',\n  \'watermark\' => \'0\',\n  \'isselectimage\' => \'1\',\n  \'images_width\' => \'\',\n  \'images_height\' => \'\',\n)','','','',0,1,0,0,0,1,0,1,14,0,0),(92,11,1,'relation','相关文章','','',0,0,'','','omnipotent','array (\n  \'formtext\' => \'<input type=\\\'hidden\\\' name=\\\'info[relation]\\\' id=\\\'relation\\\' value=\\\'{FIELD_VALUE}\\\' style=\\\'50\\\' >\r\n<ul class=\"list-dot\" id=\"relation_text\"></ul>\r\n<div>\r\n<input type=\\\'button\\\' value=\"添加相关\" onclick=\"omnipotent(\\\'selectid\\\',\\\'?m=content&c=content&a=public_relationlist&modelid={MODELID}\\\',\\\'添加相关文章\\\',1)\" class=\"button\" style=\"width:66px;\">\r\n<span class=\"edit_content\">\r\n<input type=\\\'button\\\' value=\"显示已有\" onclick=\"show_relation({MODELID},{ID})\" class=\"button\" style=\"width:66px;\">\r\n</span>\r\n</div>\',\n  \'fieldtype\' => \'varchar\',\n  \'minnumber\' => \'1\',\n)','','2,6,4,5,1,17,18,7','',0,0,0,0,0,0,1,0,15,0,0),(93,11,1,'pages','分页方式','','',0,0,'','','pages','array (\n)','','-99','-99',0,0,0,1,0,0,0,0,16,0,0),(94,11,1,'inputtime','发布时间','','',0,0,'','','datetime','array (\n  \'fieldtype\' => \'int\',\n  \'format\' => \'Y-m-d H:i:s\',\n  \'defaulttype\' => \'0\',\n)','','','',0,1,0,0,0,0,0,1,17,0,0),(95,11,1,'posids','推荐位','','',0,0,'','','posid','array (\n  \'cols\' => \'4\',\n  \'width\' => \'125\',\n)','','','',0,1,0,1,0,0,0,0,18,0,0),(96,11,1,'groupids_view','阅读权限','','',0,100,'','','groupid','array (\n  \'groupids\' => \'\',\n)','','','',0,0,0,1,0,0,0,0,19,0,0),(97,11,1,'url','URL','','',0,100,'','','text','array (\n)','','','',1,1,0,1,0,0,0,0,50,0,0),(98,11,1,'listorder','排序','','',0,6,'','','number','array (\n)','','','',1,1,0,1,0,0,0,0,51,0,0),(99,11,1,'template','内容页模板','','',0,30,'','','template','array (\n  \'size\' => \'\',\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,0,0,0,0,0,0,0,53,0,0),(100,11,1,'allow_comment','允许评论','','',0,0,'','','box','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'boxtype\' => \'radio\',\n  \'fieldtype\' => \'tinyint\',\n  \'minnumber\' => \'1\',\n  \'width\' => \'88\',\n  \'size\' => \'1\',\n  \'defaultvalue\' => \'1\',\n  \'outputtype\' => \'0\',\n)','','','',0,0,0,0,0,0,0,0,54,0,0),(101,11,1,'status','状态','','',0,2,'','','box','array (\n)','','','',1,1,0,1,0,0,0,0,55,0,0),(102,11,1,'readpoint','阅读收费','','',0,5,'','','readpoint','array (\n  \'minnumber\' => \'1\',\n  \'maxnumber\' => \'99999\',\n  \'decimaldigits\' => \'0\',\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,0,0,0,0,0,0,0,55,0,0),(103,11,1,'username','用户名','','',0,20,'','','text','array (\n)','','','',1,1,0,1,0,0,0,0,98,0,0),(104,11,1,'islink','转向链接','','',0,0,'','','islink','array (\n)','','','',0,1,0,1,0,1,0,0,20,0,0),(105,11,1,'video','视频上传','','',0,0,'','','video','array (\n  \'upload_allowext\' => \'flv|rm|mp4|rmv\',\n)','','','',0,0,0,1,0,1,0,0,8,0,0),(106,11,1,'vision','画质','','',0,0,'','','box','array (\n  \'options\' => \'高清|1\r\n普通|2\',\n  \'boxtype\' => \'select\',\n  \'fieldtype\' => \'varchar\',\n  \'minnumber\' => \'1\',\n  \'width\' => \'80\',\n  \'size\' => \'1\',\n  \'defaultvalue\' => \'0\',\n  \'outputtype\' => \'1\',\n  \'filtertype\' => \'1\',\n)','','','',0,1,0,1,0,1,0,0,9,0,0),(107,11,1,'video_category','视频分类','','',0,0,'','','box','array (\n  \'options\' => \'喜剧|1\r\n爱情|2\r\n科幻|3\r\n剧情|4\r\n动作|5\r\n伦理|6\',\n  \'boxtype\' => \'select\',\n  \'fieldtype\' => \'varchar\',\n  \'minnumber\' => \'1\',\n  \'width\' => \'80\',\n  \'size\' => \'1\',\n  \'defaultvalue\' => \'1\',\n  \'outputtype\' => \'1\',\n  \'filtertype\' => \'1\',\n)','','','',0,1,0,1,0,1,0,0,9,0,0),(108,1,1,'author','作者','','',0,0,'','','text','{\"size\":\"50\",\"defaultvalue\":\"\\u7b51\\u57ce\\u878d\\u521b\",\"ispassword\":\"0\"}','','','',0,1,0,1,0,1,1,0,5,0,0),(109,12,1,'catid','栏目','','',1,6,'/^[0-9]{1,6}$/','请选择栏目','catid','array (\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,1,0,1,1,1,0,0,1,0,0),(110,12,1,'typeid','类别','','',0,0,'','','typeid','array (\n  \'minnumber\' => \'\',\n  \'defaultvalue\' => \'\',\n)','','','',0,1,0,1,1,1,0,0,2,1,0),(111,12,1,'title','标题','','inputtitle',1,80,'','请输入标题','title','','','','',0,1,0,1,1,1,1,1,4,0,0),(112,12,1,'keywords','关键词','多关键词之间用空格或者“,”隔开','',0,40,'','','keyword','array (\r\n  \'size\' => \'100\',\r\n  \'defaultvalue\' => \'\',\r\n)','','-99','-99',0,1,0,1,1,1,1,0,7,1,0),(113,12,1,'description','摘要','','',0,255,'','','textarea','array (\r\n  \'width\' => \'98\',\r\n  \'height\' => \'46\',\r\n  \'defaultvalue\' => \'\',\r\n  \'enablehtml\' => \'0\',\r\n)','','','',0,1,0,1,0,1,1,1,10,1,0),(114,12,1,'updatetime','更新时间','','',0,0,'','','datetime','array (\r\n  \'dateformat\' => \'int\',\r\n  \'format\' => \'Y-m-d H:i:s\',\r\n  \'defaulttype\' => \'1\',\r\n  \'defaultvalue\' => \'\',\r\n)','','','',1,1,0,1,0,0,0,0,12,0,0),(115,12,1,'content','内容','<div class=\"content_attr\"><label><input name=\"add_introduce\" type=\"checkbox\"  value=\"1\" checked>是否截取内容</label><input type=\"text\" name=\"introcude_length\" value=\"200\" size=\"3\">字符至内容摘要\r\n<label><input type=\'checkbox\' name=\'auto_thumb\' value=\"1\" checked>是否获取内容第</label><input type=\"text\" name=\"auto_thumb_no\" value=\"1\" size=\"2\" class=\"\">张图片作为标题图片\r\n</div>','',1,999999,'','内容不能为空','editor','array (\n  \'toolbar\' => \'full\',\n  \'defaultvalue\' => \'\',\n  \'enablekeylink\' => \'1\',\n  \'replacenum\' => \'2\',\n  \'link_mode\' => \'0\',\n  \'enablesaveimage\' => \'1\',\n)','','','',0,0,0,1,0,1,1,0,13,1,0),(116,12,1,'thumb','缩略图','','',0,100,'','','image','array (\n  \'size\' => \'50\',\n  \'defaultvalue\' => \'\',\n  \'show_type\' => \'1\',\n  \'upload_maxsize\' => \'1024\',\n  \'upload_allowext\' => \'jpg|jpeg|gif|png|bmp\',\n  \'watermark\' => \'0\',\n  \'isselectimage\' => \'1\',\n  \'images_width\' => \'\',\n  \'images_height\' => \'\',\n)','','','',0,1,0,0,0,1,0,1,14,1,0),(117,12,1,'relation','相关文章','','',0,0,'','','omnipotent','array (\n  \'formtext\' => \'<input type=\\\'hidden\\\' name=\\\'info[relation]\\\' id=\\\'relation\\\' value=\\\'{FIELD_VALUE}\\\' style=\\\'50\\\' >\r\n<ul class=\"list-dot\" id=\"relation_text\"></ul>\r\n<div>\r\n<input type=\\\'button\\\' value=\"添加相关\" onclick=\"omnipotent(\\\'selectid\\\',\\\'?m=content&c=content&a=public_relationlist&modelid={MODELID}\\\',\\\'添加相关文章\\\',1)\" class=\"button\" style=\"width:66px;\">\r\n<span class=\"edit_content\">\r\n<input type=\\\'button\\\' value=\"显示已有\" onclick=\"show_relation({MODELID},{ID})\" class=\"button\" style=\"width:66px;\">\r\n</span>\r\n</div>\',\n  \'fieldtype\' => \'varchar\',\n  \'minnumber\' => \'1\',\n)','','2,6,4,5,1,17,18,7','',0,0,0,0,0,0,1,0,15,1,0),(118,12,1,'pages','分页方式','','',0,0,'','','pages','','','-99','-99',0,0,0,1,0,0,0,0,16,0,0),(119,12,1,'inputtime','发布时间','','',0,0,'','','datetime','array (\n  \'fieldtype\' => \'int\',\n  \'format\' => \'Y-m-d H:i:s\',\n  \'defaulttype\' => \'0\',\n)','','','',0,1,0,0,0,0,0,1,17,0,0),(120,12,1,'posids','推荐位','','',0,0,'','','posid','array (\n  \'cols\' => \'4\',\n  \'width\' => \'125\',\n)','','','',0,1,0,1,0,0,0,0,18,1,0),(121,12,1,'groupids_view','阅读权限','','',0,100,'','','groupid','array (\n  \'groupids\' => \'\',\n)','','','',0,0,0,1,0,0,0,0,19,1,0),(122,12,1,'url','URL','','',0,100,'','','text','','','','',1,1,0,1,0,0,0,0,50,0,0),(123,12,1,'listorder','排序','','',0,6,'','','number','','','','',1,1,0,1,0,0,0,0,51,0,0),(124,12,1,'template','内容页模板','','',0,30,'','','template','array (\n  \'size\' => \'\',\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,0,0,0,0,0,0,0,53,0,0),(125,12,1,'allow_comment','允许评论','','',0,0,'','','box','array (\n  \'options\' => \'允许评论|1\r\n不允许评论|0\',\n  \'boxtype\' => \'radio\',\n  \'fieldtype\' => \'tinyint\',\n  \'minnumber\' => \'1\',\n  \'width\' => \'88\',\n  \'size\' => \'1\',\n  \'defaultvalue\' => \'1\',\n  \'outputtype\' => \'0\',\n)','','','',0,0,0,0,0,0,0,0,54,1,0),(126,12,1,'status','状态','','',0,2,'','','box','','','','',1,1,0,1,0,0,0,0,55,0,0),(127,12,1,'readpoint','阅读收费','','',0,5,'','','readpoint','array (\n  \'minnumber\' => \'1\',\n  \'maxnumber\' => \'99999\',\n  \'decimaldigits\' => \'0\',\n  \'defaultvalue\' => \'\',\n)','','-99','-99',0,0,0,0,0,0,0,0,55,1,0),(128,12,1,'username','用户名','','',0,20,'','','text','','','','',1,1,0,1,0,0,0,0,98,0,0),(129,12,1,'islink','转向链接','','',0,0,'','','islink','','','','',0,1,0,1,0,1,0,0,20,1,0),(130,12,1,'qrcode_a','筑城资本二维码','','',0,0,'','','image','{\"size\":\"\",\"defaultvalue\":\"\",\"show_type\":\"0\",\"upload_allowext\":\"gif|jpg|jpeg|png|bmp\",\"watermark\":\"0\",\"isselectimage\":\"1\",\"images_width\":\"\",\"images_height\":\"\"}','','','',0,1,0,1,0,1,0,0,5,0,0),(131,12,1,'qrcode_b','增益通二维码','','',0,0,'','','image','{\"size\":\"\",\"defaultvalue\":\"\",\"show_type\":\"0\",\"upload_allowext\":\"gif|jpg|jpeg|png|bmp\",\"watermark\":\"0\",\"isselectimage\":\"1\",\"images_width\":\"\",\"images_height\":\"\"}','','','',0,0,0,1,0,1,0,0,5,0,0);
/*!40000 ALTER TABLE `v9_model_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_module`
--

DROP TABLE IF EXISTS `v9_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_module` (
  `module` varchar(15) NOT NULL,
  `name` varchar(20) NOT NULL,
  `url` varchar(50) NOT NULL,
  `iscore` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `version` varchar(50) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL,
  `setting` mediumtext NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `installdate` date NOT NULL DEFAULT '0000-00-00',
  `updatedate` date NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_module`
--

LOCK TABLES `v9_module` WRITE;
/*!40000 ALTER TABLE `v9_module` DISABLE KEYS */;
INSERT INTO `v9_module` VALUES ('admin','admin','',1,'1.0','','array (\n  \'admin_email\' => \'phpcms@phpcms.cn\',\n  \'adminaccessip\' => \'0\',\n  \'maxloginfailedtimes\' => \'8\',\n  \'maxiplockedtime\' => \'15\',\n  \'minrefreshtime\' => \'2\',\n  \'mail_type\' => \'1\',\n  \'mail_server\' => \'smtp.qq.com\',\n  \'mail_port\' => \'25\',\n  \'mail_user\' => \'phpcms.cn@foxmail.com\',\n  \'mail_auth\' => \'1\',\n  \'mail_from\' => \'phpcms.cn@foxmail.com\',\n  \'mail_password\' => \'\',\n  \'errorlog_size\' => \'20\',\n)',0,0,'2010-10-18','2010-10-18'),('member','会员','',1,'1.0','','array (\n  \'allowregister\' => \'1\',\n  \'choosemodel\' => \'1\',\n  \'enablemailcheck\' => \'0\',\n  \'registerverify\' => \'0\',\n  \'showapppoint\' => \'0\',\n  \'rmb_point_rate\' => \'10\',\n  \'defualtpoint\' => \'0\',\n  \'defualtamount\' => \'0\',\n  \'showregprotocol\' => \'0\',\n  \'regprotocol\' => \'		 欢迎您注册成为phpcms用户\r\n请仔细阅读下面的协议，只有接受协议才能继续进行注册。 \r\n1．服务条款的确认和接纳\r\n　　phpcms用户服务的所有权和运作权归phpcms拥有。phpcms所提供的服务将按照有关章程、服务条款和操作规则严格执行。用户通过注册程序点击“我同意” 按钮，即表示用户与phpcms达成协议并接受所有的服务条款。\r\n2． phpcms服务简介\r\n　　phpcms通过国际互联网为用户提供新闻及文章浏览、图片浏览、软件下载、网上留言和BBS论坛等服务。\r\n　　用户必须： \r\n　　1)购置设备，包括个人电脑一台、调制解调器一个及配备上网装置。 \r\n　　2)个人上网和支付与此服务有关的电话费用、网络费用。\r\n　　用户同意： \r\n　　1)提供及时、详尽及准确的个人资料。 \r\n　　2)不断更新注册资料，符合及时、详尽、准确的要求。所有原始键入的资料将引用为注册资料。 \r\n　　3)用户同意遵守《中华人民共和国保守国家秘密法》、《中华人民共和国计算机信息系统安全保护条例》、《计算机软件保护条例》等有关计算机及互联网规定的法律和法规、实施办法。在任何情况下，phpcms合理地认为用户的行为可能违反上述法律、法规，phpcms可以在任何时候，不经事先通知终止向该用户提供服务。用户应了解国际互联网的无国界性，应特别注意遵守当地所有有关的法律和法规。\r\n3． 服务条款的修改\r\n　　phpcms会不定时地修改服务条款，服务条款一旦发生变动，将会在相关页面上提示修改内容。如果您同意改动，则再一次点击“我同意”按钮。 如果您不接受，则及时取消您的用户使用服务资格。\r\n4． 服务修订\r\n　　phpcms保留随时修改或中断服务而不需知照用户的权利。phpcms行使修改或中断服务的权利，不需对用户或第三方负责。\r\n5． 用户隐私制度\r\n　　尊重用户个人隐私是phpcms的 基本政策。phpcms不会公开、编辑或透露用户的注册信息，除非有法律许可要求，或phpcms在诚信的基础上认为透露这些信息在以下三种情况是必要的： \r\n　　1)遵守有关法律规定，遵从合法服务程序。 \r\n　　2)保持维护phpcms的商标所有权。 \r\n　　3)在紧急情况下竭力维护用户个人和社会大众的隐私安全。 \r\n　　4)符合其他相关的要求。 \r\n6．用户的帐号，密码和安全性\r\n　　一旦注册成功成为phpcms用户，您将得到一个密码和帐号。如果您不保管好自己的帐号和密码安全，将对因此产生的后果负全部责任。另外，每个用户都要对其帐户中的所有活动和事件负全责。您可随时根据指示改变您的密码，也可以结束旧的帐户重开一个新帐户。用户同意若发现任何非法使用用户帐号或安全漏洞的情况，立即通知phpcms。\r\n7． 免责条款\r\n　　用户明确同意网站服务的使用由用户个人承担风险。 　　 \r\n　　phpcms不作任何类型的担保，不担保服务一定能满足用户的要求，也不担保服务不会受中断，对服务的及时性，安全性，出错发生都不作担保。用户理解并接受：任何通过phpcms服务取得的信息资料的可靠性取决于用户自己，用户自己承担所有风险和责任。 \r\n8．有限责任\r\n　　phpcms对任何直接、间接、偶然、特殊及继起的损害不负责任。\r\n9． 不提供零售和商业性服务 \r\n　　用户使用网站服务的权利是个人的。用户只能是一个单独的个体而不能是一个公司或实体商业性组织。用户承诺不经phpcms同意，不能利用网站服务进行销售或其他商业用途。\r\n10．用户责任 \r\n　　用户单独承担传输内容的责任。用户必须遵循： \r\n　　1)从中国境内向外传输技术性资料时必须符合中国有关法规。 \r\n　　2)使用网站服务不作非法用途。 \r\n　　3)不干扰或混乱网络服务。 \r\n　　4)不在论坛BBS或留言簿发表任何与政治相关的信息。 \r\n　　5)遵守所有使用网站服务的网络协议、规定、程序和惯例。\r\n　　6)不得利用本站危害国家安全、泄露国家秘密，不得侵犯国家社会集体的和公民的合法权益。\r\n　　7)不得利用本站制作、复制和传播下列信息： \r\n　　　1、煽动抗拒、破坏宪法和法律、行政法规实施的；\r\n　　　2、煽动颠覆国家政权，推翻社会主义制度的；\r\n　　　3、煽动分裂国家、破坏国家统一的；\r\n　　　4、煽动民族仇恨、民族歧视，破坏民族团结的；\r\n　　　5、捏造或者歪曲事实，散布谣言，扰乱社会秩序的；\r\n　　　6、宣扬封建迷信、淫秽、色情、赌博、暴力、凶杀、恐怖、教唆犯罪的；\r\n　　　7、公然侮辱他人或者捏造事实诽谤他人的，或者进行其他恶意攻击的；\r\n　　　8、损害国家机关信誉的；\r\n　　　9、其他违反宪法和法律行政法规的；\r\n　　　10、进行商业广告行为的。\r\n　　用户不能传输任何教唆他人构成犯罪行为的资料；不能传输长国内不利条件和涉及国家安全的资料；不能传输任何不符合当地法规、国家法律和国际法 律的资料。未经许可而非法进入其它电脑系统是禁止的。若用户的行为不符合以上的条款，phpcms将取消用户服务帐号。\r\n11．网站内容的所有权\r\n　　phpcms定义的内容包括：文字、软件、声音、相片、录象、图表；在广告中全部内容；电子邮件的全部内容；phpcms为用户提供的商业信息。所有这些内容受版权、商标、标签和其它财产所有权法律的保护。所以，用户只能在phpcms和广告商授权下才能使用这些内容，而不能擅自复制、篡改这些内容、或创造与内容有关的派生产品。\r\n12．附加信息服务\r\n　　用户在享用phpcms提供的免费服务的同时，同意接受phpcms提供的各类附加信息服务。\r\n13．解释权\r\n　　本注册协议的解释权归phpcms所有。如果其中有任何条款与国家的有关法律相抵触，则以国家法律的明文规定为准。 \',\n  \'registerverifymessage\' => \' 欢迎您注册成为phpcms用户，您的账号需要邮箱认证，点击下面链接进行认证：{click}\r\n或者将网址复制到浏览器：{url}\',\n  \'forgetpassword\' => \' phpcms密码找回，请在一小时内点击下面链接进行操作：{click}\r\n或者将网址复制到浏览器：{url}\',\n)',0,0,'2010-09-06','2010-09-06'),('pay','支付','',1,'1.0','','',0,0,'2010-09-06','2010-09-06'),('digg','顶一下','',0,'1.0','','',0,0,'2010-09-06','2010-09-06'),('special','专题','',0,'1.0','','',0,0,'2010-09-06','2010-09-06'),('content','内容模块','',1,'1.0','','',0,0,'2010-09-06','2010-09-06'),('search','全站搜索','',0,'1.0','','array (\n  \'fulltextenble\' => \'1\',\n  \'relationenble\' => \'1\',\n  \'suggestenable\' => \'1\',\n  \'sphinxenable\' => \'0\',\n  \'sphinxhost\' => \'10.228.134.102\',\n  \'sphinxport\' => \'9312\',\n)',0,0,'2010-09-06','2010-09-06'),('scan','木马扫描','scan',0,'1.0','','',0,0,'2010-09-01','2010-09-06'),('attachment','附件','attachment',1,'1.0','','',0,0,'2010-09-01','2010-09-06'),('block','碎片','',1,'1.0','','',0,0,'2010-09-01','2010-09-06'),('collection','采集模块','collection',1,'1.0','','',0,0,'2010-09-01','2010-09-06'),('dbsource','数据源','',1,'','','',0,0,'2010-09-01','2010-09-06'),('template','模板风格','',1,'1.0','','',0,0,'2010-09-01','2010-09-06'),('release','发布点','',1,'1.0','','',0,0,'2010-09-01','2010-09-06'),('video','视频库','',0,'1.0','','',0,0,'2012-09-28','2012-09-28'),('announce','公告','announce/',0,'1.0','公告','',0,0,'2017-04-19','2017-04-19'),('comment','评论','comment/',0,'1.0','评论','',0,0,'2017-04-19','2017-04-19'),('link','友情链接','',0,'1.0','','array (\n  1 => \n  array (\n    \'is_post\' => \'1\',\n    \'enablecheckcode\' => \'0\',\n  ),\n)',0,0,'2010-09-06','2010-09-06'),('vote','投票','',0,'1.0','','array (\r\n  1 => \r\n  array (\r\n    \'default_style\' => \'default\',\r\n    \'vote_tp_template\' => \'vote_tp\',\r\n    \'allowguest\' => \'1\',\r\n    \'enabled\' => \'1\',\r\n    \'interval\' => \'1\',\r\n    \'credit\' => \'1\',\r\n  ),\r\n)',0,0,'2010-09-06','2010-09-06'),('message','短消息','',0,'1.0','','',0,0,'2010-09-06','2010-09-06'),('mood','新闻心情','mood/',0,'1.0','新闻心情','',0,0,'2017-04-19','2017-04-19'),('poster','广告模块','poster/',0,'1.0','广告模块','',0,0,'2017-04-19','2017-04-19'),('formguide','表单向导','formguide/',0,'1.0','formguide','array (\n  \'allowmultisubmit\' => \'1\',\n  \'interval\' => \'30\',\n  \'allowunreg\' => \'0\',\n  \'mailmessage\' => \'用户向我们提交了表单数据，赶快去看看吧。\',\n)',0,0,'2010-10-20','2010-10-20'),('wap','手机门户','wap/',0,'1.0','手机门户','',0,0,'2017-04-19','2017-04-19'),('upgrade','在线升级','',0,'1.0','','',0,0,'2011-05-18','2011-05-18'),('tag','标签向导','tag/',0,'1.0','标签向导','',0,0,'2017-04-19','2017-04-19'),('sms','短信平台','sms/',0,'1.0','短信平台','',0,0,'2011-09-02','2011-09-02');
/*!40000 ALTER TABLE `v9_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_mood`
--

DROP TABLE IF EXISTS `v9_mood`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_mood` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '栏目id',
  `siteid` mediumint(6) unsigned NOT NULL DEFAULT '0' COMMENT '站点ID',
  `contentid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文章id',
  `total` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总数',
  `n1` int(10) unsigned NOT NULL DEFAULT '0',
  `n2` int(10) unsigned NOT NULL DEFAULT '0',
  `n3` int(10) unsigned NOT NULL DEFAULT '0',
  `n4` int(10) unsigned NOT NULL DEFAULT '0',
  `n5` int(10) unsigned NOT NULL DEFAULT '0',
  `n6` int(10) unsigned NOT NULL DEFAULT '0',
  `n7` int(10) unsigned NOT NULL DEFAULT '0',
  `n8` int(10) unsigned NOT NULL DEFAULT '0',
  `n9` int(10) unsigned NOT NULL DEFAULT '0',
  `n10` int(10) unsigned NOT NULL DEFAULT '0',
  `lastupdate` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后更新时间',
  PRIMARY KEY (`id`),
  KEY `total` (`total`),
  KEY `lastupdate` (`lastupdate`),
  KEY `catid` (`catid`,`siteid`,`contentid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_mood`
--

LOCK TABLES `v9_mood` WRITE;
/*!40000 ALTER TABLE `v9_mood` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_mood` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_news`
--

DROP TABLE IF EXISTS `v9_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_news` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(5) unsigned NOT NULL,
  `title` varchar(80) NOT NULL DEFAULT '',
  `style` char(24) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `keywords` char(40) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `posids` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` char(100) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `sysadd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `author` varchar(255) NOT NULL DEFAULT '筑城融创',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`,`id`),
  KEY `listorder` (`catid`,`status`,`listorder`,`id`),
  KEY `catid` (`catid`,`status`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=127 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_news`
--

LOCK TABLES `v9_news` WRITE;
/*!40000 ALTER TABLE `v9_news` DISABLE KEYS */;
INSERT INTO `v9_news` VALUES (109,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=109',0,99,1,0,'admin',1545294473,1545294512,'筑城融创'),(108,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=108',0,99,1,0,'admin',1545294473,1545294512,'筑城融创'),(107,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=107',0,99,1,0,'admin',1545294473,1545294512,'筑城融创'),(106,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=106',0,99,1,0,'admin',1545294473,1545294512,'筑城融创'),(105,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=105',0,99,1,0,'admin',1545294473,1545294511,'筑城融创'),(104,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=104',0,99,1,0,'admin',1545294473,1545294511,'筑城融创'),(103,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=103',0,99,1,0,'admin',1545294473,1545294511,'筑城融创'),(102,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=102',0,99,1,0,'admin',1545294473,1545294511,'筑城融创'),(101,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=101',0,99,1,0,'admin',1545294473,1545294511,'筑城融创'),(100,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=100',0,99,1,0,'admin',1545285862,1545285875,'筑城融创'),(99,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=99',0,99,1,0,'admin',1545285862,1545285874,'筑城融创'),(98,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=98',0,99,1,0,'admin',1545285862,1545285874,'筑城融创'),(97,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=97',0,99,1,0,'admin',1545285862,1545285874,'筑城融创'),(96,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=96',0,99,1,0,'admin',1545285862,1545285874,'筑城融创'),(95,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=95',0,99,1,0,'admin',1545285862,1545285874,'筑城融创'),(94,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=94',0,99,1,0,'admin',1545285862,1545285874,'筑城融创'),(93,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=93',0,99,1,0,'admin',1545285862,1545285874,'筑城融创'),(92,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=92',0,99,1,0,'admin',1545285862,1545285873,'筑城融创'),(91,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=91',0,99,1,0,'admin',1545285862,1545285873,'筑城融创'),(90,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=90',0,99,1,0,'admin',1545285862,1545285873,'筑城融创'),(89,27,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=27&id=89',0,99,1,0,'admin',1545285862,1545285873,'筑城融创'),(88,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=88',0,99,1,0,'admin',1545285607,1545285653,'筑城融创'),(87,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=87',0,99,1,0,'admin',1545285607,1545285653,'筑城融创'),(71,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=71',0,99,1,0,'admin',1545285607,1545285650,'筑城融创'),(72,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=72',0,99,1,0,'admin',1545285607,1545285650,'筑城融创'),(73,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=73',0,99,1,0,'admin',1545285607,1545285650,'筑城融创'),(74,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=74',0,99,1,0,'admin',1545285607,1545285650,'筑城融创'),(75,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=75',0,99,1,0,'admin',1545285607,1545285651,'筑城融创'),(76,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=76',0,99,1,0,'admin',1545285607,1545285651,'筑城融创'),(77,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=77',0,99,1,0,'admin',1545285607,1545285651,'筑城融创'),(78,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=78',0,99,1,0,'admin',1545285607,1545285651,'筑城融创'),(79,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=79',0,99,1,0,'admin',1545285607,1545285652,'筑城融创'),(80,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=80',0,99,1,0,'admin',1545285607,1545285652,'筑城融创'),(81,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=81',0,99,1,0,'admin',1545285607,1545285652,'筑城融创'),(82,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=82',0,99,1,0,'admin',1545285607,1545285652,'筑城融创'),(83,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=83',0,99,1,0,'admin',1545285607,1545285652,'筑城融创'),(84,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=84',0,99,1,0,'admin',1545285607,1545285652,'筑城融创'),(85,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=85',0,99,1,0,'admin',1545285607,1545285652,'筑城融创'),(86,36,0,'关于规范金融机构资产管理业务的指导意见','','','','关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构   ',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=36&id=86',0,99,1,0,'admin',1545285607,1545285653,'筑城融创'),(56,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=56',0,99,1,0,'admin',1545220589,1545220614,'小虎名品'),(57,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=57',0,99,1,0,'admin',1545220589,1545220614,'小虎名品'),(58,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=58',0,99,1,0,'admin',1545220589,1545220614,'小虎名品'),(59,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=59',0,99,1,0,'admin',1545220589,1545220614,'小虎名品'),(60,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=60',0,99,1,0,'admin',1545220589,1545220614,'小虎名品'),(61,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=61',0,99,1,0,'admin',1545220589,1545220615,'小虎名品'),(62,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=62',0,99,1,0,'admin',1545220589,1545220615,'小虎名品'),(63,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=63',0,99,1,0,'admin',1545220589,1545220615,'小虎名品'),(64,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=64',0,99,1,0,'admin',1545220589,1545220615,'小虎名品'),(65,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=65',0,99,1,0,'admin',1545220589,1545220615,'小虎名品'),(66,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=66',0,99,1,0,'admin',1545220589,1545220616,'小虎名品'),(67,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=67',0,99,1,0,'admin',1545220589,1545220616,'小虎名品'),(68,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=68',0,99,1,0,'admin',1545220589,1545220616,'小虎名品'),(69,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=69',0,99,1,0,'admin',1545220589,1545220616,'小虎名品'),(70,15,0,'高价回收手表','','http://tiger.gitlay.com/uploadfile/2018/1219/20181219075649725.jpg','','高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'http://tiger.gitlay.com/index.php?m=content&c=index&a=show&catid=15&id=70',0,99,1,0,'admin',1545220589,1545220616,'小虎名品'),(110,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=110',0,99,1,0,'admin',1545294473,1545294512,'筑城融创'),(111,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=111',0,99,1,0,'admin',1545294473,1545294512,'筑城融创'),(112,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=112',0,99,1,0,'admin',1545294473,1545294513,'筑城融创'),(113,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=113',0,99,1,0,'admin',1545294473,1545294513,'筑城融创'),(114,25,0,'资质荣誉','','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220042821698.jpg','','资质荣誉资质荣誉资质荣誉',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=25&id=114',0,99,1,0,'admin',1545294473,1545294512,'筑城融创'),(115,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=115',0,99,1,0,'admin',1545295453,1545295464,'筑城融创'),(116,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=116',0,99,1,0,'admin',1545295453,1545295464,'筑城融创'),(117,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=117',0,99,1,0,'admin',1545295453,1545295465,'筑城融创'),(118,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=118',0,99,1,0,'admin',1545295453,1545295465,'筑城融创'),(119,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=119',0,99,1,0,'admin',1545295453,1545295465,'筑城融创'),(120,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=120',0,99,1,0,'admin',1545295453,1545295465,'筑城融创'),(121,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=121',0,99,1,0,'admin',1545295453,1545295465,'筑城融创'),(122,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=122',0,99,1,0,'admin',1545295453,1545295465,'筑城融创'),(123,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=123',0,99,1,0,'admin',1545295453,1545295465,'筑城融创'),(124,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=124',0,99,1,0,'admin',1545295453,1545295466,'筑城融创'),(125,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=125',0,99,1,0,'admin',1545295453,1545295466,'筑城融创'),(126,37,0,'支部活动','','','','支部活动支部活动支部活动支部活动支部活动',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=37&id=126',0,99,1,0,'admin',1545295453,1545295466,'筑城融创');
/*!40000 ALTER TABLE `v9_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_news_data`
--

DROP TABLE IF EXISTS `v9_news_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_news_data` (
  `id` mediumint(8) unsigned DEFAULT '0',
  `content` mediumtext NOT NULL,
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0',
  `groupids_view` varchar(100) NOT NULL,
  `paginationtype` tinyint(1) NOT NULL,
  `maxcharperpage` mediumint(6) NOT NULL,
  `template` varchar(30) NOT NULL,
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `relation` varchar(255) NOT NULL DEFAULT '',
  `voteid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `allow_comment` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `copyfrom` varchar(100) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_news_data`
--

LOCK TABLES `v9_news_data` WRITE;
/*!40000 ALTER TABLE `v9_news_data` DISABLE KEYS */;
INSERT INTO `v9_news_data` VALUES (71,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(72,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(73,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(74,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(75,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(76,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(77,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(78,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(79,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(80,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(81,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(82,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(83,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(84,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(86,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(85,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(87,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(88,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(89,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(90,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(91,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(56,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(57,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(58,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(59,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(60,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(61,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(62,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(63,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(64,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(65,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(66,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(67,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(68,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(69,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(70,'高价回收手表高价回收手表高价回收手表高价回收手表高价回收手表',0,'',0,10000,'',0,'',0,1,''),(92,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(93,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(94,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(95,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(96,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(97,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(98,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(99,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(100,'关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见关于规范金融机构资产管理业务的指导意见',0,'',0,10000,'',0,'',0,1,''),(101,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(103,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(102,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(104,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(105,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(106,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(107,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(108,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(109,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(110,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(111,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(112,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(113,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(114,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">资质荣誉</span>',0,'',0,10000,'',0,'',0,1,''),(115,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,''),(116,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,''),(117,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,''),(118,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,''),(119,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,''),(120,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,''),(121,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,''),(122,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,''),(123,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,''),(124,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,''),(125,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,''),(126,'<span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span><span style=\"color: rgb(68, 68, 68); font-family: tahoma, arial, 宋体, sans-serif;\">支部活动</span>',0,'',0,10000,'',0,'',0,1,'');
/*!40000 ALTER TABLE `v9_news_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_page`
--

DROP TABLE IF EXISTS `v9_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_page` (
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(160) NOT NULL,
  `style` varchar(24) NOT NULL,
  `keywords` varchar(40) NOT NULL,
  `content` text NOT NULL,
  `template` varchar(30) NOT NULL,
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_page`
--

LOCK TABLES `v9_page` WRITE;
/*!40000 ALTER TABLE `v9_page` DISABLE KEYS */;
INSERT INTO `v9_page` VALUES (11,'公司简介',';','','<span>小虎名品自2015年成立以来，致力服务于广大高端客户群体，一单生意交一个朋友，诚信第一原则服务好每一位客户！</span>\r\n<p>奢饰品回收 名表 钻石 名包</p>\r\n<p>寄卖</p>\r\n<p>鉴定</p>\r\n','',0),(10,'小虎名品',';','','<div>小虎名品自2015年成立以来，致力服务于广大高端客户群 体，一单生意交一个朋友，诚信第一原则服务好每一位客 户！ 奢饰品【回收】【寄卖】【鉴定】 名表 钻石 名包&nbsp;</div>\r\n<div>联系电话：13602133933(微信同号) 李经理</div>\r\n','',0),(10,'小虎名品',';','','<div>小虎名品自2015年成立以来，致力服务于广大高端客户群 体，一单生意交一个朋友，诚信第一原则服务好每一位客 户！ 奢饰品【回收】【寄卖】【鉴定】 名表 钻石 名包&nbsp;</div>\r\n<div>联系电话：13602133933(微信同号) 李经理</div>\r\n','',0),(19,'维修保养流程',';','','<div class=\"Repair_bt fix\">\r\n<h3>维修保养流程</h3>\r\n</div>\r\n<div class=\"Repair_nr fix\"><img src=\"/template/images/Repair_tp1.jpg\" /> <img src=\"/template/images/Repair_tp2.jpg\" /></div>\r\n<div class=\"Repair_tm fix\">\r\n<h3>详细流程</h3>\r\n</div>\r\n<div class=\"Repair_nr1 fix\">\r\n<h3>外壳</h3>\r\n<img src=\"/template/images/Repair_tp3.jpg\" />\r\n<p>外壳的清洗通常用超声波清洗的方法，去除肉眼看不到的残留污渍；另外确保可活动外圈转动的灵活。对于按扣、把头、底盖消耗的硅脂，适量添加，更换老化的防水胶圈，以保证防水效果。</p>\r\n<h3>机芯拆洗和装配</h3>\r\n<img src=\"/template/images/Repair_tp4.jpg\" />\r\n<p>机芯的处理是维修中的重中之重，可以分为拆、洗、装三个模块。 &ldquo;拆&rdquo;，就是检查有问题的零件，更换磨损配件和残缺变形的螺丝。 &ldquo;洗&rdquo;的时候，需要使用120#溶剂汽油，经过两洗一漂的步骤，再 通过10倍寸镜仔细查看有无残留污渍，检查宝石轴眼是否明亮，轴 榫是否光亮无磨损，最后放到烘炉以50度中温烘干，此时机芯就会 变得光洁如新。</p>\r\n<img src=\"/template/images/Repair_tp5.jpg\" />\r\n<h3>加油</h3>\r\n<img src=\"/template/images/Repair_tp6.jpg\" />\r\n<p>加油不是洗油，也不是只加单一的一种油。油量的多少，什么部 分加件油，先加后加都有严格的规定。加的&ldquo;油&rdquo;一般是以下4种： 油膏，稠油，稀油，马叉油。油量不能高于石碗1/2。碗边轴心不挂 油，零件除接触面外都不能有油，如此才能确保零部件的润滑和美 观。对于特殊的品牌要求，还得按品牌的要求来。</p>\r\n<h3>调校</h3>\r\n<p>对于维修来说，4个方位的调校就已经能够确保走时的准确度。 要求是手表面上、面下摆幅要达到280以上，3、6、12字向下时， 摆幅要在260以上。正10秒内，偏振0.2内，线条紧凑清晰。</p>\r\n<h3>字面、针</h3>\r\n<img src=\"/template/images/Repair_tp7.jpg\" />\r\n<p>字面不能发生偏移，三针与字面平行间距相等，时、分相差不大 于3分，45分~0分完成换历。整个字面的处理要做到：针无尘，无 新增划痕、指印。新表要做到无痕拆装。这些看似小事，但都要求 修表师需要具备高度的职业素养和耐心。</p>\r\n<h3>机芯装配检查</h3>\r\n<img src=\"/template/images/Repair_tp8.jpg\" />\r\n<p>在拧紧螺丝的时候，需要严格按照螺丝刀和螺丝钉的大小适应比 例使用，以确保螺丝孔不能有划痕，螺丝头不能刮花，夹板干净无 尘无印。</p>\r\n<h3>装壳</h3>\r\n<img src=\"/template/images/Repair_tp9.jpg\" />\r\n<p>来到装壳这一步，意味着即将完成硬件上的装配。在装壳时要保 证固定机壳的装置平稳有效，把芯对准把管，不能发生偏移，秒针 与面盖要有安全距离。自动陀不刮碰表壳底盖，底盖螺丝无污渍。 旋入顺滑无缝隙。</p>\r\n<h3>自传仪检查</h3>\r\n<img src=\"/template/images/Repair_tp10.jpg\" />\r\n<p>最后将手表置于自传仪上进行检查，观察手表是否可以在自转的 情况下保证36小时以上的完美运行。</p>\r\n<h3>整壳外观检查</h3>\r\n<img src=\"/template/images/Repair_tp11.jpg\" />\r\n<p>整壳外观检查是手表交回到客户手中的最后一步，虽然马上要大 功告成，但也必须做到确认手表表壳、表带的干净，再次查看底盖 是否紧实无缝，表耳盖是否紧贴表头，按扣开关是否安全容易操作， 把头上条拨针力度适中，不能有变形的生耳。检查完毕后，一枚带 2892机芯的手表就重新焕发新的活力了。</p>\r\n</div>\r\n<div class=\"Repair_tel fix\"><a href=\"tel:136021339\"><img src=\"/template/images/Repair_tb.png\" /> <span>联系电话：13602133933(微信同号)</span> </a></div>\r\n','',0),(22,'公司简介',';','','<p>筑城融创企业发展有限公司，是一家具有国有背景的混合所有制企业，简称&ldquo;筑城融创&rdquo;。</p>\r\n','',0),(23,'业务范围',';','','<p>&nbsp;&nbsp;&nbsp;&nbsp;主要涉及PE\\VC、基础设施建设、产业基金、互联网金融、新型物业服务等，是一家集金融、实业投资为一体的综合性创新、成长型企业。</p>\r\n','',0),(24,'价值理念',';','','<p>&nbsp;&nbsp;&nbsp;&nbsp;公司理念：筑造城乡产业，融创资本中国。<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;公司价值：筑城融创，创造财富，更创造梦想。</p>\r\n','',0),(30,'支部概况',';','','<p>&nbsp;&nbsp;&nbsp;&nbsp;党组织编码:01110092234<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;党组织名称:中共筑城(北京)资产管理有限公司支<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;部委员会支部书记:刘元伟<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;支部成员:刘元伟、凌昊平、徐超、张佳颖<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;支部地址:国投财富广场4号楼12A</p>\r\n','',0),(35,'招聘信息',';','','<p>&nbsp;&nbsp;<img alt=\"\" src=\"http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220050359395.jpg\" style=\"width: 360px; height: 225px;\" /><br />\r\n&nbsp;&nbsp;近年来，我国资产管理业务快速发展，在满足居民和企业投融资需求、改善社会融资结构等方面发挥了积极作用，但也存在部分业务发展不规范、多层嵌套、刚性兑付、规避金融监管和宏观调控等问题。按照党中央、国务院决策部署，为规范金融机构资产管理业务，统一同类资产管理产品监管标准，有效防控金融风险，引导社会资金流向实体经济，更好地支持经济结构调整和转型升级，<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;经国务院同意，现提出以下意见： 一、规范金融机构资产管理业务主要遵循以下原则： （一）坚持严控风险的底线思维。把防范和化解资产管理业务风险放到更加重要的位置，减少存量风险，严防增量风险。 （二）坚持服务实体经济的根本目标。既充分发挥资产管理业务功能，切实服务实体经济投融资需求，又严格规范引导，避免资金脱实向虚在金融体系内部自我循环，防止产品过于复杂，加剧风险跨行业、跨市场、跨区域传递。 （三）坚持宏观审慎管理与微观审慎监管相结合、机构监管与功能监管相结合的监管理念。实现对各类机构开展资产管理业务的全面、统一覆盖，采取有效监管措施，加强金融消费者权益保护。 （四）坚持有的放矢的问题导向。重点针对资产管理业务的多层嵌套、杠杆不清、套利严重、投机频繁等问题，设定统一的标准规制，同时对金融创新坚持趋利避害、一分为二，留出发展空间。 （五）坚持积极稳妥审慎推进。正确处理改革、发展、稳定关系，坚持防范风险与有序规范相结合，在下决心处置风险的同时，充分考虑市场承受能力，合理设置过渡期，把握好工作的次序、节奏、力度，加强市场沟通，有效引导市场预期。</p>\r\n','',0),(32,'支部概括',';','','<p>&nbsp;&nbsp;&nbsp;&nbsp;党组织编码:01110092234<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;党组织名称:中共筑城(北京)资产管理有限公司支<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;部委员会支部书记:刘元伟<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;支部成员:刘元伟、凌昊平、徐超、张佳颖<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;支部地址:国投财富广场4号楼12A</p>\r\n','',0),(34,'联系方式',';','','<h4>筑城(北京)资产管理有限公司</h4>\r\n<h3>北京</h3>\r\n<p>地址:北京市朝阳区双营路天溪园13号楼</p>\r\n<p>电话:01063366271</p>\r\n<p>邮 编：100020</p>\r\n<h3>河北</h3>\r\n<p>地址石家庄市中华北大街50号军创国际大厦802</p>\r\n<p>电话:0311-66567955</p>\r\n<p>邮 编：050000</p>\r\n','',0);
/*!40000 ALTER TABLE `v9_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_pay_account`
--

DROP TABLE IF EXISTS `v9_pay_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_pay_account` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `trade_sn` char(50) NOT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `contactname` char(50) NOT NULL,
  `email` char(40) NOT NULL,
  `telephone` char(20) NOT NULL,
  `discount` float(8,2) NOT NULL DEFAULT '0.00',
  `money` char(8) NOT NULL,
  `quantity` int(8) unsigned NOT NULL DEFAULT '1',
  `addtime` int(10) NOT NULL DEFAULT '0',
  `paytime` int(10) NOT NULL DEFAULT '0',
  `usernote` char(255) NOT NULL,
  `pay_id` tinyint(3) NOT NULL,
  `pay_type` enum('offline','recharge','selfincome','online') NOT NULL DEFAULT 'recharge',
  `payment` char(90) NOT NULL,
  `type` tinyint(3) NOT NULL DEFAULT '1',
  `ip` char(15) NOT NULL DEFAULT '0.0.0.0',
  `status` enum('succ','failed','error','progress','timeout','cancel','waitting','unpay') NOT NULL DEFAULT 'unpay',
  `adminnote` char(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `trade_sn` (`trade_sn`,`money`,`status`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_pay_account`
--

LOCK TABLES `v9_pay_account` WRITE;
/*!40000 ALTER TABLE `v9_pay_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_pay_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_pay_payment`
--

DROP TABLE IF EXISTS `v9_pay_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_pay_payment` (
  `pay_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `pay_name` varchar(120) NOT NULL,
  `pay_code` varchar(20) NOT NULL,
  `pay_desc` text NOT NULL,
  `pay_method` tinyint(1) DEFAULT NULL,
  `pay_fee` varchar(10) NOT NULL,
  `config` text NOT NULL,
  `is_cod` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_online` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pay_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `author` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `version` varchar(20) NOT NULL,
  PRIMARY KEY (`pay_id`),
  KEY `pay_code` (`pay_code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_pay_payment`
--

LOCK TABLES `v9_pay_payment` WRITE;
/*!40000 ALTER TABLE `v9_pay_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_pay_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_pay_spend`
--

DROP TABLE IF EXISTS `v9_pay_spend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_pay_spend` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `creat_at` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(20) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `logo` varchar(20) NOT NULL,
  `value` int(5) NOT NULL,
  `op_userid` int(10) unsigned NOT NULL DEFAULT '0',
  `op_username` char(20) NOT NULL,
  `msg` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `creat_at` (`creat_at`),
  KEY `logo` (`logo`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_pay_spend`
--

LOCK TABLES `v9_pay_spend` WRITE;
/*!40000 ALTER TABLE `v9_pay_spend` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_pay_spend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_picture`
--

DROP TABLE IF EXISTS `v9_picture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_picture` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(5) unsigned NOT NULL,
  `title` char(80) NOT NULL DEFAULT '',
  `style` char(24) NOT NULL DEFAULT '',
  `thumb` char(100) NOT NULL DEFAULT '',
  `keywords` char(40) NOT NULL DEFAULT '',
  `description` char(255) NOT NULL DEFAULT '',
  `posids` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` char(100) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `sysadd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`,`id`),
  KEY `listorder` (`catid`,`status`,`listorder`,`id`),
  KEY `catid` (`catid`,`status`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_picture`
--

LOCK TABLES `v9_picture` WRITE;
/*!40000 ALTER TABLE `v9_picture` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_picture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_picture_data`
--

DROP TABLE IF EXISTS `v9_picture_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_picture_data` (
  `id` mediumint(8) unsigned DEFAULT '0',
  `content` text NOT NULL,
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0',
  `groupids_view` varchar(100) NOT NULL,
  `paginationtype` tinyint(1) NOT NULL,
  `maxcharperpage` mediumint(6) NOT NULL,
  `template` varchar(30) NOT NULL,
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `relation` varchar(255) NOT NULL DEFAULT '',
  `pictureurls` mediumtext NOT NULL,
  `copyfrom` varchar(255) NOT NULL DEFAULT '',
  `allow_comment` tinyint(1) unsigned NOT NULL DEFAULT '1',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_picture_data`
--

LOCK TABLES `v9_picture_data` WRITE;
/*!40000 ALTER TABLE `v9_picture_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_picture_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_position`
--

DROP TABLE IF EXISTS `v9_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_position` (
  `posid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `modelid` smallint(5) unsigned DEFAULT '0',
  `catid` smallint(5) unsigned DEFAULT '0',
  `name` char(30) NOT NULL DEFAULT '',
  `maxnum` smallint(5) NOT NULL DEFAULT '20',
  `extention` char(100) DEFAULT NULL,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `thumb` varchar(150) NOT NULL DEFAULT '',
  PRIMARY KEY (`posid`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_position`
--

LOCK TABLES `v9_position` WRITE;
/*!40000 ALTER TABLE `v9_position` DISABLE KEYS */;
INSERT INTO `v9_position` VALUES (1,0,0,'首页焦点图推荐',20,NULL,1,1,''),(2,0,0,'首页头条推荐',20,NULL,4,1,''),(13,82,0,'栏目页焦点图',20,NULL,0,1,''),(5,69,0,'推荐下载',20,NULL,0,1,''),(8,30,54,'图片频道首页焦点图',20,NULL,0,1,''),(9,0,0,'网站顶部推荐',20,NULL,0,1,''),(10,0,0,'栏目首页推荐',20,NULL,0,1,''),(12,0,0,'首页图片推荐',20,NULL,0,1,''),(14,0,0,'视频首页焦点图',20,'',0,1,''),(15,0,0,'视频首页头条推荐',20,'',0,1,''),(16,0,0,'视频首页每日热点',20,'',0,1,''),(17,0,0,'视频栏目精彩推荐',20,'',0,1,'');
/*!40000 ALTER TABLE `v9_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_position_data`
--

DROP TABLE IF EXISTS `v9_position_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_position_data` (
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `posid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `module` char(20) DEFAULT NULL,
  `modelid` smallint(6) unsigned DEFAULT '0',
  `thumb` tinyint(1) NOT NULL DEFAULT '0',
  `data` mediumtext,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1',
  `listorder` mediumint(8) DEFAULT '0',
  `expiration` int(10) NOT NULL,
  `extention` char(30) DEFAULT NULL,
  `synedit` tinyint(1) DEFAULT '0',
  KEY `posid` (`posid`),
  KEY `listorder` (`listorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_position_data`
--

LOCK TABLES `v9_position_data` WRITE;
/*!40000 ALTER TABLE `v9_position_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_position_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_poster`
--

DROP TABLE IF EXISTS `v9_poster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_poster` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(40) NOT NULL,
  `spaceid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL,
  `setting` text NOT NULL,
  `startdate` int(10) unsigned NOT NULL DEFAULT '0',
  `enddate` int(10) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `clicks` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `spaceid` (`spaceid`,`siteid`,`disabled`,`listorder`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_poster`
--

LOCK TABLES `v9_poster` WRITE;
/*!40000 ALTER TABLE `v9_poster` DISABLE KEYS */;
INSERT INTO `v9_poster` VALUES (13,1,'第三张',11,'images','{\"1\":{\"linkurl\":\"\",\"imageurl\":\"http:\\/\\/tiger.gitlay.com\\/uploadfile\\/2018\\/1219\\/20181219061921570.jpg\",\"alt\":\"\"}}',1545214782,1547893182,1545214790,0,0,0,0),(11,1,'第一张',11,'images','{\"1\":{\"linkurl\":\"\",\"imageurl\":\"http:\\/\\/tiger.gitlay.com\\/uploadfile\\/2018\\/1219\\/20181219061921570.jpg\",\"alt\":\"\"}}',1545214735,1547893135,1545214766,0,0,0,0),(12,1,'第二张',11,'images','{\"1\":{\"linkurl\":\"\",\"imageurl\":\"http:\\/\\/tiger.gitlay.com\\/uploadfile\\/2018\\/1219\\/20181219061921570.jpg\",\"alt\":\"\"}}',1545214769,1547893169,1545214779,0,0,0,0);
/*!40000 ALTER TABLE `v9_poster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_poster_201704`
--

DROP TABLE IF EXISTS `v9_poster_201704`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_poster_201704` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `spaceid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `area` char(40) NOT NULL,
  `ip` char(15) NOT NULL,
  `referer` char(120) NOT NULL,
  `clicktime` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`,`type`,`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_poster_201704`
--

LOCK TABLES `v9_poster_201704` WRITE;
/*!40000 ALTER TABLE `v9_poster_201704` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_poster_201704` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_poster_space`
--

DROP TABLE IF EXISTS `v9_poster_space`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_poster_space` (
  `spaceid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` char(50) NOT NULL,
  `type` char(30) NOT NULL,
  `path` char(40) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `setting` char(100) NOT NULL,
  `description` char(100) NOT NULL,
  `items` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`spaceid`),
  KEY `disabled` (`disabled`,`siteid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_poster_space`
--

LOCK TABLES `v9_poster_space` WRITE;
/*!40000 ALTER TABLE `v9_poster_space` DISABLE KEYS */;
INSERT INTO `v9_poster_space` VALUES (11,1,'Banner','banner','poster_js/11.js',750,430,'{\"paddleft\":\"\",\"paddtop\":\"\"}','',3,0);
/*!40000 ALTER TABLE `v9_poster_space` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_queue`
--

DROP TABLE IF EXISTS `v9_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_queue` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type` char(5) DEFAULT NULL,
  `siteid` smallint(5) unsigned DEFAULT '0',
  `path` varchar(100) DEFAULT NULL,
  `status1` tinyint(1) DEFAULT '0',
  `status2` tinyint(1) DEFAULT '0',
  `status3` tinyint(1) DEFAULT '0',
  `status4` tinyint(1) DEFAULT '0',
  `times` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `siteid` (`siteid`),
  KEY `times` (`times`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_queue`
--

LOCK TABLES `v9_queue` WRITE;
/*!40000 ALTER TABLE `v9_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_release_point`
--

DROP TABLE IF EXISTS `v9_release_point`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_release_point` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `host` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `port` varchar(10) DEFAULT '21',
  `pasv` tinyint(1) DEFAULT '0',
  `ssl` tinyint(1) DEFAULT '0',
  `path` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_release_point`
--

LOCK TABLES `v9_release_point` WRITE;
/*!40000 ALTER TABLE `v9_release_point` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_release_point` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_search`
--

DROP TABLE IF EXISTS `v9_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_search` (
  `searchid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typeid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `adddate` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`searchid`),
  KEY `typeid` (`typeid`,`id`),
  KEY `siteid` (`siteid`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM AUTO_INCREMENT=128 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_search`
--

LOCK TABLES `v9_search` WRITE;
/*!40000 ALTER TABLE `v9_search` DISABLE KEYS */;
INSERT INTO `v9_search` VALUES (1,1,1,1545217480,'百达翡丽  ',1),(2,1,2,1545217480,'百达翡丽  ',1),(3,1,3,1545217480,'百达翡丽  ',1),(4,1,4,1545217480,'百达翡丽  ',1),(5,1,5,1545217480,'百达翡丽  ',1),(6,1,6,1545217480,'百达翡丽  ',1),(7,1,7,1545217480,'百达翡丽  ',1),(8,1,8,1545217480,'百达翡丽  ',1),(9,1,10,1545217480,'百达翡丽  ',1),(10,1,11,1545217480,'百达翡丽  ',1),(11,1,9,1545217480,'百达翡丽  ',1),(12,1,12,1545217480,'百达翡丽  ',1),(13,1,13,1545217480,'百达翡丽  ',1),(14,1,14,1545217480,'百达翡丽  ',1),(15,1,15,1545217480,'百达翡丽  ',1),(16,1,16,1545217480,'百达翡丽  ',1),(17,1,17,1545217480,'百达翡丽  ',1),(18,1,18,1545217480,'百达翡丽  ',1),(19,1,19,1545217480,'百达翡丽  ',1),(20,1,20,1545217480,'百达翡丽  ',1),(21,1,21,1545217772,'I DO  ',1),(22,1,22,1545217772,'I DO  ',1),(23,1,23,1545217772,'I DO  ',1),(24,1,24,1545217772,'I DO  ',1),(25,1,25,1545217772,'I DO  ',1),(26,1,26,1545217772,'I DO  ',1),(27,1,27,1545217772,'I DO  ',1),(28,1,28,1545217772,'I DO  ',1),(29,1,29,1545217772,'I DO  ',1),(30,1,30,1545217772,'I DO  ',1),(31,1,31,1545217772,'I DO  ',1),(32,1,32,1545217772,'I DO  ',1),(33,1,33,1545217772,'I DO  ',1),(34,1,34,1545217772,'I DO  ',1),(35,1,35,1545217772,'I DO  ',1),(36,1,36,1545217772,'I DO  ',1),(37,1,37,1545217772,'I DO  ',1),(38,1,38,1545218163,'教你如何保养我们的爱表赶快来学习吧！  学习 赶快 保养 如何',1),(39,1,39,1545218163,'教你如何保养我们的爱表赶快来学习吧！  学习 赶快 保养 如何',1),(40,1,40,1545218163,'教你如何保养我们的爱表赶快来学习吧！  学习 赶快 保养 如何',1),(41,1,41,1545218163,'教你如何保养我们的爱表赶快来学习吧！  学习 赶快 保养 如何',1),(42,1,42,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(43,1,43,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(44,1,44,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(45,1,45,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(46,1,46,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(47,1,47,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(48,1,48,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(49,1,49,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(50,1,50,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(51,1,51,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(52,1,52,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(53,1,53,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(54,1,54,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(55,1,55,1545220501,'教你如何保养我们的爱表赶快来学习吧！  如何 学习 赶快 保养',1),(56,1,56,1545220589,'高价回收手表  手表 回收 高价',1),(57,1,57,1545220589,'高价回收手表  手表 回收 高价',1),(58,1,58,1545220589,'高价回收手表  手表 回收 高价',1),(59,1,59,1545220589,'高价回收手表  手表 回收 高价',1),(60,1,60,1545220589,'高价回收手表  手表 回收 高价',1),(61,1,61,1545220589,'高价回收手表  手表 回收 高价',1),(62,1,62,1545220589,'高价回收手表  手表 回收 高价',1),(63,1,63,1545220589,'高价回收手表  手表 回收 高价',1),(64,1,64,1545220589,'高价回收手表  手表 回收 高价',1),(65,1,65,1545220589,'高价回收手表  手表 回收 高价',1),(66,1,66,1545220589,'高价回收手表  手表 回收 高价',1),(67,1,67,1545220589,'高价回收手表  手表 回收 高价',1),(68,1,68,1545220589,'高价回收手表  手表 回收 高价',1),(69,1,69,1545220589,'高价回收手表  手表 回收 高价',1),(70,1,70,1545220589,'高价回收手表  手表 回收 高价',1),(71,1,71,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(72,1,72,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(73,1,73,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(74,1,74,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(75,1,75,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(76,1,76,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(77,1,77,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(78,1,78,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(79,1,79,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(80,1,80,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(81,1,81,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(82,1,82,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(83,1,83,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(84,1,84,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(85,1,86,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(86,1,85,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(87,1,87,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(88,1,88,1545285607,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(89,1,89,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(90,1,90,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(91,1,91,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(92,1,92,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(93,1,93,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(94,1,94,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(95,1,95,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(96,1,96,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(97,1,97,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(98,1,98,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(99,1,99,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(100,1,100,1545285862,'关于规范金融机构资产管理业务的指导意见  关于 金融机构 规范 指导意见 资产管理 业务',1),(101,1,101,1545294473,'资质荣誉  资质 荣誉 宋体',1),(102,1,103,1545294473,'资质荣誉  资质 荣誉 宋体',1),(103,1,102,1545294473,'资质荣誉  资质 荣誉 宋体',1),(104,1,104,1545294473,'资质荣誉  资质 荣誉 宋体',1),(105,1,105,1545294473,'资质荣誉  资质 荣誉 宋体',1),(106,1,106,1545294473,'资质荣誉  资质 荣誉 宋体',1),(107,1,107,1545294473,'资质荣誉  资质 荣誉 宋体',1),(108,1,108,1545294473,'资质荣誉  资质 荣誉 宋体',1),(109,1,109,1545294473,'资质荣誉  资质 荣誉 宋体',1),(110,1,110,1545294473,'资质荣誉  资质 荣誉 宋体',1),(111,1,111,1545294473,'资质荣誉  资质 荣誉 宋体',1),(112,1,112,1545294473,'资质荣誉  资质 荣誉 宋体',1),(113,1,113,1545294473,'资质荣誉  资质 荣誉 宋体',1),(114,1,114,1545294473,'资质荣誉  资质 荣誉 宋体',1),(115,1,115,1545295453,'支部活动  活动 宋体',1),(116,1,116,1545295453,'支部活动  活动 宋体',1),(117,1,117,1545295453,'支部活动  活动 宋体',1),(118,1,118,1545295453,'支部活动  活动 宋体',1),(119,1,119,1545295453,'支部活动  活动 宋体',1),(120,1,120,1545295453,'支部活动  活动 宋体',1),(121,1,121,1545295453,'支部活动  活动 宋体',1),(122,1,122,1545295453,'支部活动  活动 宋体',1),(123,1,123,1545295453,'支部活动  活动 宋体',1),(124,1,124,1545295453,'支部活动  活动 宋体',1),(125,1,125,1545295453,'支部活动  活动 宋体',1),(126,1,126,1545295453,'支部活动  活动 宋体',1),(127,53,1,1545296034,'系统配置  配置 系统',1);
/*!40000 ALTER TABLE `v9_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_search_keyword`
--

DROP TABLE IF EXISTS `v9_search_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_search_keyword` (
  `keyword` char(20) NOT NULL,
  `pinyin` char(20) NOT NULL,
  `searchnums` int(10) unsigned NOT NULL,
  `data` char(20) NOT NULL,
  UNIQUE KEY `keyword` (`keyword`),
  UNIQUE KEY `pinyin` (`pinyin`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_search_keyword`
--

LOCK TABLES `v9_search_keyword` WRITE;
/*!40000 ALTER TABLE `v9_search_keyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_search_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_session`
--

DROP TABLE IF EXISTS `v9_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_session` (
  `sessionid` char(32) NOT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL,
  `lastvisit` int(10) unsigned NOT NULL DEFAULT '0',
  `roleid` tinyint(3) unsigned DEFAULT '0',
  `groupid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m` char(20) NOT NULL,
  `c` char(20) NOT NULL,
  `a` char(20) NOT NULL,
  `data` char(255) NOT NULL,
  PRIMARY KEY (`sessionid`),
  KEY `lastvisit` (`lastvisit`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_session`
--

LOCK TABLES `v9_session` WRITE;
/*!40000 ALTER TABLE `v9_session` DISABLE KEYS */;
INSERT INTO `v9_session` VALUES ('i3c6uhaa2j8o9a2upu2raqf787',1,'127.0.0.1',1545297295,1,0,'admin','index','public_session_life','code|s:0:\"\";userid|s:1:\"1\";roleid|s:1:\"1\";pc_hash|s:6:\"4lWEbW\";lock_screen|i:0;');
/*!40000 ALTER TABLE `v9_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_shop`
--

DROP TABLE IF EXISTS `v9_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_shop` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(5) unsigned NOT NULL,
  `title` char(80) NOT NULL DEFAULT '',
  `style` char(24) NOT NULL DEFAULT '',
  `thumb` char(100) NOT NULL DEFAULT '',
  `keywords` char(40) NOT NULL DEFAULT '',
  `description` char(255) NOT NULL DEFAULT '',
  `posids` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` char(100) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `sysadd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`,`id`),
  KEY `listorder` (`catid`,`status`,`listorder`,`id`),
  KEY `catid` (`catid`,`status`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_shop`
--

LOCK TABLES `v9_shop` WRITE;
/*!40000 ALTER TABLE `v9_shop` DISABLE KEYS */;
INSERT INTO `v9_shop` VALUES (2,58,0,'山西省','','http://luguang.com/uploadfile/2018/1027/20181027031934688.png','','',0,'http://luguang.com/index.php?m=content&c=index&a=show&catid=58&id=1',0,99,1,0,'admin',1540624708,1540624777),(3,58,0,'山西省','','http://luguang.com/uploadfile/2018/1027/20181027031934688.png','','',0,'http://luguang.com/index.php?m=content&c=index&a=show&catid=58&id=1',0,99,1,0,'admin',1540624708,1540624777),(4,58,0,'山西省','','http://luguang.com/uploadfile/2018/1027/20181027031934688.png','','',0,'http://luguang.com/index.php?m=content&c=index&a=show&catid=58&id=1',0,99,1,0,'admin',1540624708,1540624777),(5,58,0,'山西省','','http://luguang.com/uploadfile/2018/1027/20181027031934688.png','','',0,'http://luguang.com/index.php?m=content&c=index&a=show&catid=58&id=1',0,99,1,0,'admin',1540624708,1540624777),(6,58,0,'山西省','','http://luguang.com/uploadfile/2018/1027/20181027031934688.png','','',0,'http://luguang.com/index.php?m=content&c=index&a=show&catid=58&id=1',0,99,1,0,'admin',1540624708,1540624777),(7,58,0,'山西省','','http://luguang.com/uploadfile/2018/1027/20181027031934688.png','','',0,'http://luguang.com/index.php?m=content&c=index&a=show&catid=58&id=1',0,99,1,0,'admin',1540624708,1540624777),(8,58,0,'山西省','','http://luguang.com/uploadfile/2018/1027/20181027031934688.png','','',0,'http://luguang.com/index.php?m=content&c=index&a=show&catid=58&id=1',0,99,1,0,'admin',1540624708,1540624777),(9,58,0,'山西省','','http://luguang.com/uploadfile/2018/1027/20181027031934688.png','','',0,'http://luguang.com/index.php?m=content&c=index&a=show&catid=58&id=1',0,99,1,0,'admin',1540624708,1540624777),(10,58,0,'山西省','','http://luguang.com/uploadfile/2018/1027/20181027031934688.png','','',0,'http://luguang.com/index.php?m=content&c=index&a=show&catid=58&id=1',0,99,1,0,'admin',1540624708,1540624777);
/*!40000 ALTER TABLE `v9_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_shop_data`
--

DROP TABLE IF EXISTS `v9_shop_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_shop_data` (
  `id` mediumint(8) unsigned DEFAULT '0',
  `content` text NOT NULL,
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0',
  `groupids_view` varchar(100) NOT NULL,
  `paginationtype` tinyint(1) NOT NULL,
  `maxcharperpage` mediumint(6) NOT NULL,
  `template` varchar(30) NOT NULL,
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allow_comment` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `relation` varchar(255) NOT NULL DEFAULT '',
  `leader` varchar(255) NOT NULL DEFAULT '',
  `phone` varchar(255) NOT NULL DEFAULT '',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `fax` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_shop_data`
--

LOCK TABLES `v9_shop_data` WRITE;
/*!40000 ALTER TABLE `v9_shop_data` DISABLE KEYS */;
INSERT INTO `v9_shop_data` VALUES (2,'',0,'',0,0,'',0,1,'','某某某','400-006-7803','15155555555','0311－83327968','xuelongqiye@163.com'),(3,'',0,'',0,0,'',0,1,'','某某某','400-006-7803','15155555555','0311－83327968','xuelongqiye@163.com'),(4,'',0,'',0,0,'',0,1,'','某某某','400-006-7803','15155555555','0311－83327968','xuelongqiye@163.com'),(5,'',0,'',0,0,'',0,1,'','某某某','400-006-7803','15155555555','0311－83327968','xuelongqiye@163.com'),(6,'',0,'',0,0,'',0,1,'','某某某','400-006-7803','15155555555','0311－83327968','xuelongqiye@163.com'),(7,'',0,'',0,0,'',0,1,'','某某某','400-006-7803','15155555555','0311－83327968','xuelongqiye@163.com'),(8,'',0,'',0,0,'',0,1,'','某某某','400-006-7803','15155555555','0311－83327968','xuelongqiye@163.com'),(9,'',0,'',0,0,'',0,1,'','某某某','400-006-7803','15155555555','0311－83327968','xuelongqiye@163.com'),(10,'',0,'',0,0,'',0,1,'','某某某','400-006-7803','15155555555','0311－83327968','xuelongqiye@163.com');
/*!40000 ALTER TABLE `v9_shop_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_site`
--

DROP TABLE IF EXISTS `v9_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_site` (
  `siteid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` char(30) DEFAULT '',
  `dirname` char(255) DEFAULT '',
  `domain` char(255) DEFAULT '',
  `site_title` char(255) DEFAULT '',
  `keywords` char(255) DEFAULT '',
  `description` char(255) DEFAULT '',
  `release_point` text,
  `default_style` char(50) DEFAULT NULL,
  `template` text,
  `setting` mediumtext,
  `uuid` char(40) DEFAULT '',
  PRIMARY KEY (`siteid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_site`
--

LOCK TABLES `v9_site` WRITE;
/*!40000 ALTER TABLE `v9_site` DISABLE KEYS */;
INSERT INTO `v9_site` VALUES (1,'筑城融创','','http://zhucheng.gitlay.com/','筑城融创','筑城融创','筑城融创','','zhucheng','zhucheng','{\"upload_maxsize\":\"2048\",\"upload_allowext\":\"jpg|jpeg|gif|bmp|png|doc|docx|xls|xlsx|ppt|pptx|pdf|txt|rar|zip|swf\",\"watermark_enable\":\"1\",\"watermark_minwidth\":\"300\",\"watermark_minheight\":\"300\",\"watermark_img\":\"statics\\/images\\/water\\/\\/mark.png\",\"watermark_pct\":\"85\",\"watermark_quality\":\"80\",\"watermark_pos\":\"9\"}','c63c0957-24db-11e7-9d05-94de8058de48');
/*!40000 ALTER TABLE `v9_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_sms_report`
--

DROP TABLE IF EXISTS `v9_sms_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_sms_report` (
  `id` bigint(15) NOT NULL AUTO_INCREMENT,
  `mobile` varchar(11) NOT NULL,
  `posttime` int(10) unsigned NOT NULL DEFAULT '0',
  `id_code` varchar(10) NOT NULL,
  `msg` varchar(90) NOT NULL,
  `send_userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL DEFAULT '0',
  `return_id` varchar(30) NOT NULL,
  `ip` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mobile` (`mobile`,`posttime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_sms_report`
--

LOCK TABLES `v9_sms_report` WRITE;
/*!40000 ALTER TABLE `v9_sms_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_sms_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_special`
--

DROP TABLE IF EXISTS `v9_special`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_special` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `aid` int(10) unsigned NOT NULL DEFAULT '0',
  `title` char(60) NOT NULL,
  `typeids` char(100) NOT NULL,
  `thumb` char(100) NOT NULL,
  `banner` char(100) NOT NULL,
  `description` char(255) NOT NULL,
  `url` char(100) NOT NULL,
  `ishtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ispage` tinyint(1) unsigned NOT NULL,
  `filename` char(40) NOT NULL,
  `pics` char(100) NOT NULL,
  `voteid` char(60) NOT NULL,
  `style` char(20) NOT NULL,
  `index_template` char(40) NOT NULL,
  `list_template` char(40) NOT NULL,
  `show_template` char(60) NOT NULL,
  `css` text NOT NULL,
  `username` char(40) NOT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(5) unsigned NOT NULL,
  `elite` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isvideo` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `disabled` (`disabled`,`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_special`
--

LOCK TABLES `v9_special` WRITE;
/*!40000 ALTER TABLE `v9_special` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_special` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_special_c_data`
--

DROP TABLE IF EXISTS `v9_special_c_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_special_c_data` (
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(40) NOT NULL,
  `content` text NOT NULL,
  `paginationtype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `maxcharperpage` mediumint(6) unsigned NOT NULL DEFAULT '0',
  `style` char(20) NOT NULL,
  `show_template` varchar(30) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_special_c_data`
--

LOCK TABLES `v9_special_c_data` WRITE;
/*!40000 ALTER TABLE `v9_special_c_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_special_c_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_special_content`
--

DROP TABLE IF EXISTS `v9_special_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_special_content` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `specialid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` char(80) NOT NULL,
  `style` char(24) NOT NULL,
  `typeid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `thumb` char(100) NOT NULL,
  `keywords` char(40) NOT NULL,
  `description` char(255) NOT NULL,
  `url` char(100) NOT NULL,
  `curl` char(15) NOT NULL,
  `listorder` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `searchid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isdata` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `videoid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `specialid` (`specialid`,`typeid`,`isdata`),
  KEY `typeid` (`typeid`,`isdata`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_special_content`
--

LOCK TABLES `v9_special_content` WRITE;
/*!40000 ALTER TABLE `v9_special_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_special_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_sphinx_counter`
--

DROP TABLE IF EXISTS `v9_sphinx_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_sphinx_counter` (
  `counter_id` int(11) unsigned NOT NULL,
  `max_doc_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`counter_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_sphinx_counter`
--

LOCK TABLES `v9_sphinx_counter` WRITE;
/*!40000 ALTER TABLE `v9_sphinx_counter` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_sphinx_counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_sso_admin`
--

DROP TABLE IF EXISTS `v9_sso_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_sso_admin` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL,
  `password` char(32) NOT NULL,
  `encrypt` char(6) DEFAULT NULL,
  `issuper` tinyint(1) DEFAULT '0',
  `lastlogin` int(10) DEFAULT NULL,
  `ip` char(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_sso_admin`
--

LOCK TABLES `v9_sso_admin` WRITE;
/*!40000 ALTER TABLE `v9_sso_admin` DISABLE KEYS */;
INSERT INTO `v9_sso_admin` VALUES (1,'admin','28bf4b81f6dda0ca4ed84ff6ef389af6','fPz6HM',1,0,'');
/*!40000 ALTER TABLE `v9_sso_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_sso_applications`
--

DROP TABLE IF EXISTS `v9_sso_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_sso_applications` (
  `appid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `type` char(16) NOT NULL DEFAULT '',
  `name` char(20) NOT NULL DEFAULT '',
  `url` char(255) NOT NULL DEFAULT '',
  `authkey` char(255) NOT NULL DEFAULT '',
  `ip` char(15) NOT NULL DEFAULT '',
  `apifilename` char(30) NOT NULL DEFAULT 'phpsso.php',
  `charset` char(8) NOT NULL DEFAULT '',
  `synlogin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`appid`),
  KEY `synlogin` (`synlogin`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_sso_applications`
--

LOCK TABLES `v9_sso_applications` WRITE;
/*!40000 ALTER TABLE `v9_sso_applications` DISABLE KEYS */;
INSERT INTO `v9_sso_applications` VALUES (1,'phpcms_v9','phpcms v9','http://localhost/cms_v9.6.1/','DqFWaGxgPzit55kOAVrgFBgPWIuN4idm','','api.php?op=phpsso','utf-8',1);
/*!40000 ALTER TABLE `v9_sso_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_sso_members`
--

DROP TABLE IF EXISTS `v9_sso_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_sso_members` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `random` char(8) NOT NULL DEFAULT '',
  `email` char(32) NOT NULL DEFAULT '',
  `regip` char(15) NOT NULL DEFAULT '',
  `regdate` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` char(15) NOT NULL DEFAULT '0',
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `appname` char(15) NOT NULL,
  `type` enum('app','connect') DEFAULT NULL,
  `avatar` tinyint(1) NOT NULL DEFAULT '0',
  `ucuserid` mediumint(8) unsigned DEFAULT '0',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `ucuserid` (`ucuserid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_sso_members`
--

LOCK TABLES `v9_sso_members` WRITE;
/*!40000 ALTER TABLE `v9_sso_members` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_sso_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_sso_messagequeue`
--

DROP TABLE IF EXISTS `v9_sso_messagequeue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_sso_messagequeue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `operation` char(32) NOT NULL,
  `succeed` tinyint(1) NOT NULL DEFAULT '0',
  `totalnum` smallint(6) unsigned NOT NULL DEFAULT '0',
  `noticedata` mediumtext NOT NULL,
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `appstatus` mediumtext,
  PRIMARY KEY (`id`),
  KEY `dateline` (`dateline`),
  KEY `succeed` (`succeed`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_sso_messagequeue`
--

LOCK TABLES `v9_sso_messagequeue` WRITE;
/*!40000 ALTER TABLE `v9_sso_messagequeue` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_sso_messagequeue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_sso_session`
--

DROP TABLE IF EXISTS `v9_sso_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_sso_session` (
  `sessionid` char(32) NOT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL,
  `lastvisit` int(10) unsigned NOT NULL DEFAULT '0',
  `roleid` tinyint(3) unsigned DEFAULT '0',
  `groupid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m` char(20) NOT NULL,
  `c` char(20) NOT NULL,
  `a` char(20) NOT NULL,
  `data` char(255) NOT NULL,
  PRIMARY KEY (`sessionid`),
  KEY `lastvisit` (`lastvisit`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_sso_session`
--

LOCK TABLES `v9_sso_session` WRITE;
/*!40000 ALTER TABLE `v9_sso_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_sso_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_sso_settings`
--

DROP TABLE IF EXISTS `v9_sso_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_sso_settings` (
  `name` varchar(32) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_sso_settings`
--

LOCK TABLES `v9_sso_settings` WRITE;
/*!40000 ALTER TABLE `v9_sso_settings` DISABLE KEYS */;
INSERT INTO `v9_sso_settings` VALUES ('denyemail',''),('denyusername',''),('creditrate',''),('sp4',''),('ucenter','');
/*!40000 ALTER TABLE `v9_sso_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_sys`
--

DROP TABLE IF EXISTS `v9_sys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_sys` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(5) unsigned NOT NULL,
  `title` char(80) NOT NULL DEFAULT '',
  `style` char(24) NOT NULL DEFAULT '',
  `thumb` char(100) NOT NULL DEFAULT '',
  `keywords` char(40) NOT NULL DEFAULT '',
  `description` char(255) NOT NULL DEFAULT '',
  `posids` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` char(100) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `sysadd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `qrcode_a` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`,`id`),
  KEY `listorder` (`catid`,`status`,`listorder`,`id`),
  KEY `catid` (`catid`,`status`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_sys`
--

LOCK TABLES `v9_sys` WRITE;
/*!40000 ALTER TABLE `v9_sys` DISABLE KEYS */;
INSERT INTO `v9_sys` VALUES (1,38,0,'系统配置','','','','',0,'http://zhucheng.gitlay.com/index.php?m=content&c=index&a=show&catid=38&id=1',0,99,1,0,'admin',1545296034,1545296059,'http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220045403722.jpg');
/*!40000 ALTER TABLE `v9_sys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_sys_data`
--

DROP TABLE IF EXISTS `v9_sys_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_sys_data` (
  `id` mediumint(8) unsigned DEFAULT '0',
  `content` text NOT NULL,
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0',
  `groupids_view` varchar(100) NOT NULL,
  `paginationtype` tinyint(1) NOT NULL,
  `maxcharperpage` mediumint(6) NOT NULL,
  `template` varchar(30) NOT NULL,
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allow_comment` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `relation` varchar(255) NOT NULL DEFAULT '',
  `qrcode_b` varchar(255) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_sys_data`
--

LOCK TABLES `v9_sys_data` WRITE;
/*!40000 ALTER TABLE `v9_sys_data` DISABLE KEYS */;
INSERT INTO `v9_sys_data` VALUES (1,'',0,'',0,10000,'',0,1,'','http://zhucheng.gitlay.com/uploadfile/2018/1220/20181220045414168.jpg');
/*!40000 ALTER TABLE `v9_sys_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_tag`
--

DROP TABLE IF EXISTS `v9_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_tag` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `tag` text NOT NULL,
  `name` char(40) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `module` char(20) NOT NULL,
  `action` char(20) NOT NULL,
  `data` text NOT NULL,
  `page` char(15) NOT NULL,
  `return` char(20) NOT NULL,
  `cache` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_tag`
--

LOCK TABLES `v9_tag` WRITE;
/*!40000 ALTER TABLE `v9_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_template_bak`
--

DROP TABLE IF EXISTS `v9_template_bak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_template_bak` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `creat_at` int(10) unsigned DEFAULT '0',
  `fileid` char(50) DEFAULT NULL,
  `userid` mediumint(8) DEFAULT NULL,
  `username` char(20) DEFAULT NULL,
  `template` text,
  PRIMARY KEY (`id`),
  KEY `fileid` (`fileid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_template_bak`
--

LOCK TABLES `v9_template_bak` WRITE;
/*!40000 ALTER TABLE `v9_template_bak` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_template_bak` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_times`
--

DROP TABLE IF EXISTS `v9_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_times` (
  `username` char(40) NOT NULL,
  `ip` char(15) NOT NULL,
  `logintime` int(10) unsigned NOT NULL DEFAULT '0',
  `isadmin` tinyint(1) NOT NULL DEFAULT '0',
  `times` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`username`,`isadmin`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_times`
--

LOCK TABLES `v9_times` WRITE;
/*!40000 ALTER TABLE `v9_times` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_type`
--

DROP TABLE IF EXISTS `v9_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_type` (
  `typeid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `module` char(15) NOT NULL,
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` char(30) NOT NULL,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `typedir` char(20) NOT NULL,
  `url` char(100) NOT NULL,
  `template` char(30) NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`typeid`),
  KEY `module` (`module`,`parentid`,`siteid`,`listorder`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_type`
--

LOCK TABLES `v9_type` WRITE;
/*!40000 ALTER TABLE `v9_type` DISABLE KEYS */;
INSERT INTO `v9_type` VALUES (52,1,'search',0,'专题',0,'special','','',4,'专题'),(1,1,'search',1,'新闻',0,'','','',1,'新闻模型搜索'),(2,1,'search',2,'下载',0,'','','',3,'下载模型搜索'),(3,1,'search',3,'图片',0,'','','',2,'图片模型搜索'),(53,1,'search',12,'配置模型',0,'','','',0,'');
/*!40000 ALTER TABLE `v9_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_urlrule`
--

DROP TABLE IF EXISTS `v9_urlrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_urlrule` (
  `urlruleid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(15) NOT NULL,
  `file` varchar(20) NOT NULL,
  `ishtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `urlrule` varchar(255) NOT NULL,
  `example` varchar(255) NOT NULL,
  PRIMARY KEY (`urlruleid`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_urlrule`
--

LOCK TABLES `v9_urlrule` WRITE;
/*!40000 ALTER TABLE `v9_urlrule` DISABLE KEYS */;
INSERT INTO `v9_urlrule` VALUES (1,'content','category',1,'{$categorydir}{$catdir}/index.html|{$categorydir}{$catdir}/{$page}.html','news/china/1000.html'),(6,'content','category',0,'index.php?m=content&c=index&a=lists&catid={$catid}|index.php?m=content&c=index&a=lists&catid={$catid}&page={$page}','index.php?m=content&c=index&a=lists&catid=1&page=1'),(11,'content','show',1,'{$year}/{$catdir}_{$month}{$day}/{$id}.html|{$year}/{$catdir}_{$month}{$day}/{$id}_{$page}.html','2010/catdir_0720/1_2.html'),(12,'content','show',1,'{$categorydir}{$catdir}/{$year}/{$month}{$day}/{$id}.html|{$categorydir}{$catdir}/{$year}/{$month}{$day}/{$id}_{$page}.html','it/product/2010/0720/1_2.html'),(16,'content','show',0,'index.php?m=content&c=index&a=show&catid={$catid}&id={$id}|index.php?m=content&c=index&a=show&catid={$catid}&id={$id}&page={$page}','index.php?m=content&c=index&a=show&catid=1&id=1'),(17,'content','show',0,'show-{$catid}-{$id}-{$page}.html','show-1-2-1.html'),(18,'content','show',0,'content-{$catid}-{$id}-{$page}.html','content-1-2-1.html'),(30,'content','category',0,'list-{$catid}-{$page}.html','list-1-1.html');
/*!40000 ALTER TABLE `v9_urlrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_video`
--

DROP TABLE IF EXISTS `v9_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_video` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(5) unsigned NOT NULL,
  `title` char(80) NOT NULL DEFAULT '',
  `style` char(24) NOT NULL DEFAULT '',
  `thumb` char(100) NOT NULL DEFAULT '',
  `keywords` char(40) NOT NULL DEFAULT '',
  `description` char(255) NOT NULL DEFAULT '',
  `posids` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` char(100) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `sysadd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `islink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `vision` varchar(255) NOT NULL DEFAULT '',
  `video_category` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`,`id`),
  KEY `listorder` (`catid`,`status`,`listorder`,`id`),
  KEY `catid` (`catid`,`status`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_video`
--

LOCK TABLES `v9_video` WRITE;
/*!40000 ALTER TABLE `v9_video` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_video` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_video_content`
--

DROP TABLE IF EXISTS `v9_video_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_video_content` (
  `contentid` int(10) unsigned NOT NULL DEFAULT '0',
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `videoid` int(10) unsigned NOT NULL DEFAULT '0',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  KEY `videoid` (`videoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_video_content`
--

LOCK TABLES `v9_video_content` WRITE;
/*!40000 ALTER TABLE `v9_video_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_video_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_video_data`
--

DROP TABLE IF EXISTS `v9_video_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_video_data` (
  `id` mediumint(8) unsigned DEFAULT '0',
  `content` text NOT NULL,
  `readpoint` smallint(5) unsigned NOT NULL DEFAULT '0',
  `groupids_view` varchar(100) NOT NULL,
  `paginationtype` tinyint(1) NOT NULL,
  `maxcharperpage` mediumint(6) NOT NULL,
  `template` varchar(30) NOT NULL,
  `paytype` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allow_comment` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `relation` varchar(255) NOT NULL DEFAULT '',
  `video` tinyint(3) unsigned NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_video_data`
--

LOCK TABLES `v9_video_data` WRITE;
/*!40000 ALTER TABLE `v9_video_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_video_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_video_store`
--

DROP TABLE IF EXISTS `v9_video_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_video_store` (
  `videoid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(60) NOT NULL,
  `vid` char(40) NOT NULL,
  `keywords` char(40) NOT NULL,
  `description` char(255) NOT NULL,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `picpath` char(120) NOT NULL,
  `size` char(20) NOT NULL,
  `timelen` mediumint(9) NOT NULL DEFAULT '0',
  `userupload` tinyint(1) NOT NULL DEFAULT '0',
  `channelid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`videoid`),
  KEY `videoid` (`videoid`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_video_store`
--

LOCK TABLES `v9_video_store` WRITE;
/*!40000 ALTER TABLE `v9_video_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_video_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_vote_data`
--

DROP TABLE IF EXISTS `v9_vote_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_vote_data` (
  `userid` mediumint(8) unsigned DEFAULT '0',
  `username` char(20) NOT NULL,
  `subjectid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL,
  `data` text NOT NULL,
  `userinfo` text NOT NULL,
  KEY `subjectid` (`subjectid`),
  KEY `userid` (`userid`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_vote_data`
--

LOCK TABLES `v9_vote_data` WRITE;
/*!40000 ALTER TABLE `v9_vote_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_vote_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_vote_option`
--

DROP TABLE IF EXISTS `v9_vote_option`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_vote_option` (
  `optionid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned DEFAULT '0',
  `subjectid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `option` varchar(255) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `listorder` tinyint(2) unsigned DEFAULT '0',
  PRIMARY KEY (`optionid`),
  KEY `subjectid` (`subjectid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_vote_option`
--

LOCK TABLES `v9_vote_option` WRITE;
/*!40000 ALTER TABLE `v9_vote_option` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_vote_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_vote_subject`
--

DROP TABLE IF EXISTS `v9_vote_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_vote_subject` (
  `subjectid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned DEFAULT '0',
  `subject` char(255) NOT NULL,
  `ismultiple` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ischeckbox` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `credit` smallint(5) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `fromdate` date NOT NULL DEFAULT '0000-00-00',
  `todate` date NOT NULL DEFAULT '0000-00-00',
  `interval` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `template` char(20) NOT NULL,
  `description` text NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `allowguest` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `maxval` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `minval` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `allowview` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `optionnumber` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `votenumber` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`subjectid`),
  KEY `enabled` (`enabled`),
  KEY `fromdate` (`fromdate`,`todate`),
  KEY `todate` (`todate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_vote_subject`
--

LOCK TABLES `v9_vote_subject` WRITE;
/*!40000 ALTER TABLE `v9_vote_subject` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_vote_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_wap`
--

DROP TABLE IF EXISTS `v9_wap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_wap` (
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1',
  `sitename` char(30) NOT NULL,
  `logo` char(100) DEFAULT NULL,
  `domain` varchar(100) DEFAULT NULL,
  `setting` mediumtext,
  `status` tinyint(2) DEFAULT NULL,
  PRIMARY KEY (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_wap`
--

LOCK TABLES `v9_wap` WRITE;
/*!40000 ALTER TABLE `v9_wap` DISABLE KEYS */;
INSERT INTO `v9_wap` VALUES (1,'PHPCMS手机门户','/statics/images/wap/wlogo.gif','','array (\n  \'listnum\' => \'10\',\n  \'thumb_w\' => \'220\',\n  \'thumb_h\' => \'0\',\n  \'c_num\' => \'1000\',\n  \'index_template\' => \'index\',\n  \'category_template\' => \'category\',\n  \'list_template\' => \'list\',\n  \'show_template\' => \'show\',\n)',0);
/*!40000 ALTER TABLE `v9_wap` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_wap_type`
--

DROP TABLE IF EXISTS `v9_wap_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_wap_type` (
  `typeid` smallint(5) NOT NULL AUTO_INCREMENT,
  `cat` smallint(5) NOT NULL,
  `parentid` smallint(5) NOT NULL,
  `typename` varchar(30) NOT NULL,
  `siteid` smallint(5) NOT NULL,
  `listorder` smallint(5) DEFAULT '0',
  PRIMARY KEY (`typeid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_wap_type`
--

LOCK TABLES `v9_wap_type` WRITE;
/*!40000 ALTER TABLE `v9_wap_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `v9_wap_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `v9_workflow`
--

DROP TABLE IF EXISTS `v9_workflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `v9_workflow` (
  `workflowid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `steps` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `workname` varchar(20) NOT NULL,
  `description` varchar(255) NOT NULL,
  `setting` text NOT NULL,
  `flag` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`workflowid`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `v9_workflow`
--

LOCK TABLES `v9_workflow` WRITE;
/*!40000 ALTER TABLE `v9_workflow` DISABLE KEYS */;
INSERT INTO `v9_workflow` VALUES (1,1,1,'一级审核','审核一次','',0),(2,1,2,'二级审核','审核两次','',0),(3,1,3,'三级审核','审核三次','',0),(4,1,4,'四级审核','四级审核','',0);
/*!40000 ALTER TABLE `v9_workflow` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-23 14:14:51
